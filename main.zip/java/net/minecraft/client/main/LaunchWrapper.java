package net.minecraft.client.main;

public class LaunchWrapper {
}

