package net.minecraft.client.main;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.authlib.properties.PropertyMap;
import java.io.File;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.util.List;
import joptsimple.ArgumentAcceptingOptionSpec;
import joptsimple.NonOptionArgumentSpec;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.main.GameConfiguration;
import net.minecraft.util.Session;
import org.lwjglx.opengl.Display;
import sun.misc.Unsafe;
import top.fl0wowp4rty.phantomshield.annotations.Native;

public class Main {
    @Native
    public static String LangYa(String s, String t) {
        char[] array1 = s.toCharArray();
        char[] array2 = t.toCharArray();
        boolean status = false;
        if (array2.length < array1.length) {
            for (int i = 0; i < array1.length; ++i) {
                int j;
                if (array1[i] != array2[0] || i + array2.length - 1 >= array1.length) continue;
                for (j = 0; j < array2.length && array1[i + j] == array2[j]; ++j) {
                }
                if (j != array2.length) continue;
                status = true;
                break;
            }
        }
        return status + "1";
    }

    @Native
    public static void main(String[] p_main_0_) {
        System.setProperty("java.net.preferIPv4Stack", "true");
        System.clearProperty("http.proxyHost");
        System.clearProperty("http.proxyPort");
        Unsafe[] unsafe = new Unsafe[]{null};
        Field[] f = new Field[1];
        RuntimeMXBean runtimeMxBean = ManagementFactory.getRuntimeMXBean();
        List<String> arguments = runtimeMxBean.getInputArguments();
        for (String s : arguments) {
            if (!Main.LangYa(s, "Xbootclasspath").equals("true1")) continue;
            Display.destroy();
            Minecraft.getMinecraft().thePlayer = null;
            try {
                Unsafe.class.getMethod("putAddress", Long.TYPE, Long.TYPE).invoke(unsafe[0], 8964, 8964);
            }
            catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException ex) {
                throw new RuntimeException(ex);
            }
            try {
                Unsafe.class.getMethod("freeMemory", Long.TYPE).invoke(unsafe[0], "操你妈".hashCode());
            }
            catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException ex) {
                throw new RuntimeException(ex);
            }
            Object[] o = null;
            while (true) {
                o = new Object[]{o};
            }
        }
        if (!("Xboot".contains("X") && "Xboo".contains("b") && "Classpath".contains("h") && ManagementFactory.getRuntimeMXBean().getBootClassPath().split(";")[0].contains(File.separator + "lib" + File.separator) && !ManagementFactory.getRuntimeMXBean().getBootClassPath().split(";")[0].replace("l", "I").contains(File.separator + "lib" + File.separator))) {
            Display.destroy();
            Minecraft.getMinecraft().thePlayer = null;
            Minecraft.getMinecraft().thePlayer.swingItem();
            try {
                Unsafe.class.getMethod("putAddress", Long.TYPE, Long.TYPE).invoke(unsafe[0], 8964, 8964);
            }
            catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException ex) {
                throw new RuntimeException(ex);
            }
            try {
                Unsafe.class.getMethod("freeMemory", Long.TYPE).invoke(unsafe[0], "\u64cd\u4f60\u5988".hashCode());
            }
            catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException ex) {
                throw new RuntimeException(ex);
            }
            Object[] o = null;
            while (true) {
                o = new Object[]{o};
            }
        }
        OptionParser optionparser = new OptionParser();
        optionparser.allowsUnrecognizedOptions();
        optionparser.accepts("demo");
        optionparser.accepts("fullscreen");
        optionparser.accepts("checkGlErrors");
        ArgumentAcceptingOptionSpec optionspec = optionparser.accepts("server").withRequiredArg();
        ArgumentAcceptingOptionSpec optionspec1 = optionparser.accepts("port").withRequiredArg().ofType(Integer.class).defaultsTo(25565);
        ArgumentAcceptingOptionSpec optionspec2 = optionparser.accepts("gameDir").withRequiredArg().ofType(File.class).defaultsTo(new File("."));
        ArgumentAcceptingOptionSpec optionspec3 = optionparser.accepts("assetsDir").withRequiredArg().ofType(File.class);
        ArgumentAcceptingOptionSpec optionspec4 = optionparser.accepts("resourcePackDir").withRequiredArg().ofType(File.class);
        ArgumentAcceptingOptionSpec optionspec5 = optionparser.accepts("proxyHost").withRequiredArg();
        ArgumentAcceptingOptionSpec optionspec6 = optionparser.accepts("proxyPort").withRequiredArg().defaultsTo("8080", new String[0]).ofType(Integer.class);
        ArgumentAcceptingOptionSpec optionspec7 = optionparser.accepts("proxyUser").withRequiredArg();
        ArgumentAcceptingOptionSpec optionspec8 = optionparser.accepts("proxyPass").withRequiredArg();
        ArgumentAcceptingOptionSpec optionspec9 = optionparser.accepts("username").withRequiredArg().defaultsTo(("Player" + Minecraft.getSystemTime() % 1000L));
        ArgumentAcceptingOptionSpec optionspec10 = optionparser.accepts("uuid").withRequiredArg();
        ArgumentAcceptingOptionSpec optionspec11 = optionparser.accepts("accessToken").withRequiredArg().required();
        ArgumentAcceptingOptionSpec optionspec12 = optionparser.accepts("version").withRequiredArg().required();
        ArgumentAcceptingOptionSpec optionspec13 = optionparser.accepts("width").withRequiredArg().ofType(Integer.class).defaultsTo(854,new Integer[0]);
        ArgumentAcceptingOptionSpec optionspec14 = optionparser.accepts("height").withRequiredArg().ofType(Integer.class).defaultsTo(480,new Integer[0]);
        ArgumentAcceptingOptionSpec optionspec15 = optionparser.accepts("userProperties").withRequiredArg().defaultsTo("{}", new String[0]);
        ArgumentAcceptingOptionSpec optionspec16 = optionparser.accepts("profileProperties").withRequiredArg().defaultsTo("{}", new String[0]);
        ArgumentAcceptingOptionSpec optionspec17 = optionparser.accepts("assetIndex").withRequiredArg();
        ArgumentAcceptingOptionSpec optionspec18 = optionparser.accepts("userType").withRequiredArg().defaultsTo("legacy",new String[0]);
        NonOptionArgumentSpec optionspec19 = optionparser.nonOptions();
        OptionSet optionset = optionparser.parse(p_main_0_);
        List list = optionset.valuesOf((OptionSpec)optionspec19);
        if (!list.isEmpty()) {
            System.out.println("Completely ignored arguments: " + list);
        }
        String s = (String)optionset.valueOf((OptionSpec)optionspec5);
        Proxy proxy = Proxy.NO_PROXY;
        if (s != null) {
            try {
                proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(s, (int)((Integer)optionset.valueOf((OptionSpec)optionspec6))));
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        final String s1 = (String)optionset.valueOf((OptionSpec)optionspec7);
        final String s2 = (String)optionset.valueOf((OptionSpec)optionspec8);
        if (!proxy.equals(Proxy.NO_PROXY) && Main.isNullOrEmpty(s1) && Main.isNullOrEmpty(s2)) {
            Authenticator.setDefault(new Authenticator(){

                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(s1, s2.toCharArray());
                }
            });
        }
        int i = (Integer)optionset.valueOf((OptionSpec)optionspec13);
        int j = (Integer)optionset.valueOf((OptionSpec)optionspec14);
        boolean flag = optionset.has("fullscreen");
        boolean flag1 = optionset.has("checkGlErrors");
        boolean flag2 = optionset.has("demo");
        String s3 = (String)optionset.valueOf((OptionSpec)optionspec12);
        Gson gson = new GsonBuilder().registerTypeAdapter(PropertyMap.class, (Object)new PropertyMap.Serializer()).create();
        PropertyMap propertymap = (PropertyMap)gson.fromJson((String)optionset.valueOf((OptionSpec)optionspec15), PropertyMap.class);
        PropertyMap propertymap1 = (PropertyMap)gson.fromJson((String)optionset.valueOf((OptionSpec)optionspec16), PropertyMap.class);
        File file1 = (File)optionset.valueOf((OptionSpec)optionspec2);
        File file2 = optionset.has((OptionSpec)optionspec3) ? (File)optionset.valueOf((OptionSpec)optionspec3) : new File(file1, "assets/");
        File file3 = optionset.has((OptionSpec)optionspec4) ? (File)optionset.valueOf((OptionSpec)optionspec4) : new File(file1, "resourcepacks/");
        String s4 = optionset.has((OptionSpec)optionspec10) ? (String)optionspec10.value(optionset) : (String)optionspec9.value(optionset);
        String s5 = optionset.has((OptionSpec)optionspec17) ? (String)optionspec17.value(optionset) : null;
        String s6 = (String)optionset.valueOf((OptionSpec)optionspec);
        Integer integer = (Integer)optionset.valueOf((OptionSpec)optionspec1);
        Session session = new Session((String)optionspec9.value(optionset), s4, (String)optionspec11.value(optionset), (String)optionspec18.value(optionset));
        GameConfiguration gameconfiguration = new GameConfiguration(new GameConfiguration.UserInformation(session, propertymap, propertymap1, proxy), new GameConfiguration.DisplayInformation(i, j, flag, flag1), new GameConfiguration.FolderInformation(file1, file3, file2, s5), new GameConfiguration.GameInformation(flag2, s3), new GameConfiguration.ServerInformation(s6, integer));
        Runtime.getRuntime().addShutdownHook(new Thread("Client Shutdown Thread"){

            @Override
            public void run() {
                Minecraft.stopIntegratedServer();
            }
        });
        Thread.currentThread().setName("Client thread");
        new Minecraft(gameconfiguration).run();
    }

    private static boolean isNullOrEmpty(String str) {
        return str != null && !str.isEmpty();
    }
}

