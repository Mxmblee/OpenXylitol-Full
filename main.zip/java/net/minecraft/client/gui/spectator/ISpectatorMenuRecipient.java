package net.minecraft.client.gui.spectator;

import net.minecraft.client.gui.spectator.SpectatorMenu;

public interface ISpectatorMenuRecipient {
    public void func_175257_a(SpectatorMenu var1);
}

