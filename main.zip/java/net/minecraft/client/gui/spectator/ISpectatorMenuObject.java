package net.minecraft.client.gui.spectator;

import net.minecraft.client.gui.spectator.SpectatorMenu;
import net.minecraft.util.IChatComponent;

public interface ISpectatorMenuObject {
    public void func_178661_a(SpectatorMenu var1);

    public IChatComponent getSpectatorName();

    public void func_178663_a(float var1, int var2);

    public boolean func_178662_A_();
}

