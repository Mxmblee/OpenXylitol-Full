package cc.xylitol.irc;

public enum ClientType {
    VAPU("Vapu", 0),
    XYLITOL("Xylitol", 1),
    UNKNOWN("Unknown", 255);

    public final int id;
    private final String name;

    ClientType(String name, int id) {
        this.name = name;
        this.id = id;
        LookupTable.lookupTable[id] = this;
    }

    public static ClientType getClientById(int id) {
        if (id < 256) {
            ClientType o = LookupTable.lookupTable[id];
            return o == null ? UNKNOWN : o;
        }
        return UNKNOWN;
    }

    public String getName() {
        return this.name;
    }

    static class LookupTable {
        static final ClientType[] lookupTable = new ClientType[256];

        LookupTable() {
        }
    }
}

