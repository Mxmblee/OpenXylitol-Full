package cc.xylitol.irc;

public enum MessageType {
    CHAT,
    SYSTEM_MESSAGE,
    JOIN_LEAVE_MESSAGE,
    ANNOUNCEMENT,
    OTHER;


    MessageType() {
        LookupTable.lookupTable[this.ordinal()] = this;
    }

    public static MessageType getMessageType(int id) {
        if (id > 16 || id < 0) {
            return OTHER;
        }
        return LookupTable.lookupTable[id];
    }

    static class LookupTable {
        static final MessageType[] lookupTable = new MessageType[16];

        LookupTable() {
        }

        static {
            for (int i = 0; i < lookupTable.length; ++i) {
                if (lookupTable[i] != null) continue;
                LookupTable.lookupTable[i] = OTHER;
            }
        }
    }
}

