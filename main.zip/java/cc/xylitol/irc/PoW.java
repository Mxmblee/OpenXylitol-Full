package cc.xylitol.irc;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.Random;

public class PoW {
    private final int complexity;
    private final int size;

    public PoW(int complexity, int size) {
        this.complexity = complexity;
        this.size = size;
    }

    public byte[] doPoW() {
        Random rand = new Random();
        byte[] data = new byte[this.size];
        ByteBuffer buf = ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN);
        byte[] prefix = "Proof of work".getBytes();
        do {
            rand.nextBytes(data);
            buf.clear();
            buf.putLong(System.currentTimeMillis());
            buf.put(prefix);
        } while (!this.verifyPoW(data));
        return data;
    }

    public boolean verifyPoW(byte[] data) {
        int i;
        if (data.length != this.size) {
            return false;
        }
        byte[] hash = PoW.sha256(data);
        int size = this.complexity >> 3;
        int mask = 255 >> (this.complexity & 7);
        for (i = 0; i < size; ++i) {
            if (hash[i] == 0) continue;
            return false;
        }
        return (hash[i] & mask) == (hash[i] & 0xFF);
    }

    static byte[] sha256(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.reset();
            return md.digest(data);
        }
        catch (Throwable t) {
            throw new Error(t);
        }
    }
}

