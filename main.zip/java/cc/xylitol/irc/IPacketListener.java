package cc.xylitol.irc;

import cc.xylitol.irc.packet.Packet;

public interface IPacketListener {
    void handlePacket(Packet var1);
}

