package cc.xylitol.irc.packet;

import cc.xylitol.irc.ClientType;
import cc.xylitol.irc.IRCUser;
import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet04ChangeUserList
extends Packet {
    private boolean add;
    private IRCUser user;

    @Override
    public void readPacket(DataInputStream input) throws IOException {
        int flag = input.readUnsignedByte();
        this.add = (flag & 0x80) == 0;
        boolean anonymous = (flag & 1) != 0;
        this.user = anonymous ? new IRCUser(this.readShortString(input), input.readLong(), ClientType.getClientById(input.read())) : new IRCUser(this.readShortString(input), this.readShortString(input), this.readShortString(input), input.readLong(), ClientType.getClientById(input.read()));
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleUserListChanged(this);
    }

    @Override
    public int getPacketId() {
        return 4;
    }

    public boolean isAdd() {
        return this.add;
    }

    public IRCUser getUser() {
        return this.user;
    }
}

