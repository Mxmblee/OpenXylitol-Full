package cc.xylitol.irc.packet;

import cc.xylitol.irc.MessageType;
import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class Packet02Chat
extends Packet {
    private String message;
    private MessageType msgType;
    private long auxData;

    public Packet02Chat() {
    }

    public Packet02Chat(String message) {
        if (message.getBytes(StandardCharsets.UTF_8).length >= 256) {
            throw new RuntimeException("String wide more than 1 byte!");
        }
        this.message = message;
    }

    @Override
    public void readPacket(DataInputStream input) throws IOException {
        this.msgType = MessageType.getMessageType(input.read());
        this.auxData = input.readLong();
        byte[] buf = new byte[input.readUnsignedShort()];
        input.readFully(buf);
        this.message = new String(buf, StandardCharsets.UTF_8);
        this.message = new String(buf, StandardCharsets.UTF_8);
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
        byte[] buf = this.message.getBytes(StandardCharsets.UTF_8);
        output.writeByte(buf.length);
        output.write(buf);
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleChat(this);
    }

    @Override
    public int getPacketId() {
        return 2;
    }

    public String getMessage() {
        return this.message;
    }

    public MessageType getMsgType() {
        return this.msgType;
    }

    public long getAuxData() {
        return this.auxData;
    }
}

