package cc.xylitol.irc.packet;

import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet06EncryptResponse
extends Packet {
    private final byte[] encryptedKey;

    public Packet06EncryptResponse(byte[] encryptedKey) {
        this.encryptedKey = encryptedKey;
    }

    @Override
    public void readPacket(DataInputStream input) throws IOException {
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
        output.writeInt(this.encryptedKey.length);
        output.write(this.encryptedKey);
    }

    @Override
    public void handlePacket(NetHandler handler) {
    }

    @Override
    public int getPacketId() {
        return 6;
    }
}

