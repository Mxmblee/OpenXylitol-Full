package cc.xylitol.irc.packet;

import cc.xylitol.irc.ClientType;
import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import cc.xylitol.module.impl.misc.IRC;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet08CustomPayload
extends Packet {
    private long targetUserid;
    private ClientType targetClient;
    private byte[] data;

    public Packet08CustomPayload(String username, byte[] data) {
        this.targetUserid = IRC.client.getOnlineUser(username).getUserid();
        this.targetClient = ClientType.XYLITOL;
        this.data = data;
    }

    @Override
    public void readPacket(DataInputStream input) throws IOException {
        this.targetUserid = input.readLong();
        this.targetClient = ClientType.getClientById(input.read());
        this.data = new byte[input.readUnsignedShort()];
        input.read(this.data);
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
        output.writeLong(this.targetUserid);
        output.write(this.targetClient.id);
        output.writeShort(this.data.length);
        output.write(this.data);
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleCustomPayload(this);
    }

    @Override
    public int getPacketId() {
        return 8;
    }

    public long getTargetUserid() {
        return this.targetUserid;
    }

    public ClientType getTargetClient() {
        return this.targetClient;
    }

    public byte[] getData() {
        return this.data;
    }
}

