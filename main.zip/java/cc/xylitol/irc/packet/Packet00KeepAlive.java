package cc.xylitol.irc.packet;

import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Packet00KeepAlive
extends Packet {
    @Override
    public void readPacket(DataInputStream input) {
    }

    @Override
    public void writePacket(DataOutputStream output) {
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleKeepAlive(this);
    }

    @Override
    public int getPacketId() {
        return 0;
    }
}

