package cc.xylitol.irc.packet;

import cc.xylitol.irc.ClientType;
import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.PoW;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet01Login
extends Packet {
    private String username;
    private String ign;
    private long userid;

    public Packet01Login() {
    }

    public Packet01Login(String username, String ign) {
        this.username = username;
        this.ign = ign;
    }

    @Override
    public void readPacket(DataInputStream input) throws IOException {
        this.username = this.readShortString(input);
        this.userid = input.readLong();
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
        output.writeInt(5 | ClientType.XYLITOL.id << 24);
        this.writeShortString(this.username, output);
        this.writeShortString(this.ign, output);
        byte[] nonce = new PoW(20, 64).doPoW();
        output.writeInt(nonce.length);
        output.write(nonce);
        byte[] junk = new byte[64];
        for (int i = 0; i < junk.length; ++i) {
            junk[i] = (byte)(97 + i % 26);
        }
        output.writeInt(junk.length);
        output.write(junk);
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleLogin(this);
    }

    @Override
    public int getPacketId() {
        return 1;
    }

    public long getUserid() {
        return this.userid;
    }
}

