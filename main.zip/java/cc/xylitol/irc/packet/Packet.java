package cc.xylitol.irc.packet;

import cc.xylitol.irc.NetHandler;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public abstract class Packet {
    public abstract void readPacket(DataInputStream var1) throws IOException;

    public abstract void writePacket(DataOutputStream var1) throws IOException;

    public abstract void handlePacket(NetHandler var1);

    public abstract int getPacketId();

    protected void writeShortString(String str, DataOutputStream output) throws IOException {
        byte[] buf = str.getBytes(StandardCharsets.UTF_8);
        if (buf.length >= 256) {
            throw new RuntimeException("String wide more than 1 byte!");
        }
        output.writeByte(buf.length);
        output.write(buf);
    }

    protected String readShortString(DataInputStream in) throws IOException {
        byte[] buf = new byte[in.readUnsignedByte()];
        in.readFully(buf);
        return new String(buf, StandardCharsets.UTF_8);
    }
}

