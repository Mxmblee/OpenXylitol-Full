package cc.xylitol.irc.packet;

import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class PacketFFDisconnect
extends Packet {
    private String reason;

    public PacketFFDisconnect() {
    }

    public PacketFFDisconnect(String reason) {
        this.reason = reason;
    }

    @Override
    public void readPacket(DataInputStream input) throws IOException {
        byte[] buf = new byte[input.available()];
        input.readFully(buf);
        this.reason = new String(buf, StandardCharsets.UTF_8);
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
        if (this.reason != null) {
            output.write(this.reason.getBytes(StandardCharsets.UTF_8));
        }
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleDisconnect(this);
    }

    @Override
    public int getPacketId() {
        return 255;
    }

    public String getReason() {
        return this.reason;
    }
}

