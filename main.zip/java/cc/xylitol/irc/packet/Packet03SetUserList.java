package cc.xylitol.irc.packet;

import cc.xylitol.irc.ClientType;
import cc.xylitol.irc.IRCUser;
import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class Packet03SetUserList
extends Packet {
    private IRCUser[] users = new IRCUser[0];

    @Override
    public void readPacket(DataInputStream input) throws IOException {
        byte[] bitmap = new byte[input.readInt()];
        ArrayList<IRCUser> users = new ArrayList<IRCUser>(bitmap.length);
        input.readFully(bitmap);
        for (int i = 0; i < bitmap.length; ++i) {
            int b = bitmap[i] & 0xFF;
            for (int j = 0; j < 8 && input.available() >= 1; ++j) {
                boolean anonymous = (b & 1 << 7 - j) != 0;
                IRCUser user = anonymous ? new IRCUser(this.readShortString(input), input.readLong(), ClientType.getClientById(input.read())) : new IRCUser(this.readShortString(input), this.readShortString(input), this.readShortString(input), input.readLong(), ClientType.getClientById(input.read()));
                users.add(user);
            }
        }
        this.users = users.toArray(this.users);
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleSetUser(this);
    }

    @Override
    public int getPacketId() {
        return 3;
    }

    public IRCUser[] getUsers() {
        return this.users;
    }
}

