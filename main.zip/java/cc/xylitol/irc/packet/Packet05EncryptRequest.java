package cc.xylitol.irc.packet;

import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet05EncryptRequest
extends Packet {
    private byte[] publicKey;
    private byte[] sign;

    @Override
    public void readPacket(DataInputStream input) throws IOException {
        this.publicKey = new byte[input.readInt()];
        input.readFully(this.publicKey);
        this.sign = new byte[input.readInt()];
        input.readFully(this.sign);
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleEncryptRequest(this);
    }

    @Override
    public int getPacketId() {
        return 5;
    }

    public byte[] getPublicKey() {
        return this.publicKey;
    }

    public byte[] getSign() {
        return this.sign;
    }
}

