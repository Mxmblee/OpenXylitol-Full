package cc.xylitol.irc.packet;

import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet07ChangeIGN
extends Packet {
    private long userid;
    private String ingameName;

    public Packet07ChangeIGN() {
    }

    public Packet07ChangeIGN(String ingameName) {
        this.ingameName = ingameName;
    }

    @Override
    public void readPacket(DataInputStream input) throws IOException {
        this.userid = input.readLong();
        this.ingameName = this.readShortString(input);
    }

    @Override
    public void writePacket(DataOutputStream output) throws IOException {
        this.writeShortString(this.ingameName, output);
    }

    @Override
    public void handlePacket(NetHandler handler) {
        handler.handleChangeIGN(this);
    }

    @Override
    public int getPacketId() {
        return 7;
    }

    public long getUserid() {
        return this.userid;
    }

    public String getIngameName() {
        return this.ingameName;
    }
}

