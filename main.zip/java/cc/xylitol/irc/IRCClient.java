package cc.xylitol.irc;

import cc.xylitol.irc.IPacketListener;
import cc.xylitol.irc.IRCUser;
import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.NetworkManager;
import cc.xylitol.irc.packet.Packet;
import cc.xylitol.utils.DebugUtil;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.function.Consumer;
import top.fl0wowp4rty.phantomshield.annotations.Native;

public class IRCClient
implements Runnable {
    private final SocketAddress address;
    private Socket socket;
    private NetworkManager networkManager;
    private final ArrayList<IPacketListener> listener = new ArrayList();
    private final ArrayList<IRCUser> onlineUsers = new ArrayList();
    private Consumer<String> disconnetHook;

    public IRCClient(SocketAddress address) {
        this.address = address;
    }

    @Native
    public void connect() throws IOException {
        this.socket = new Socket();
        this.socket.connect(this.address);
        this.networkManager = new NetworkManager(this.socket, this, new NetHandler(){

            @Override
            protected void unhandlePacket(Packet packet) {
                for (IPacketListener listener : IRCClient.this.listener) {
                    listener.handlePacket(packet);
                }
            }

            @Override
            protected void onConnectionClosed(String reason) {
                if (IRCClient.this.disconnetHook != null) {
                    IRCClient.this.disconnetHook.accept(reason);
                }
            }
        });
        new Thread(this, "IRC Thread").start();
    }

    public void disconnect() {
        this.networkManager.terminate();
    }

    public boolean isConnected() {
        return this.networkManager != null && !this.networkManager.isTerminated();
    }

    public NetworkManager getNetworkManager() {
        return this.networkManager;
    }

    public boolean addListener(IPacketListener l) {
        if (this.listener.contains(l)) {
            return false;
        }
        return this.listener.add(l);
    }

    public boolean removeListener(IPacketListener l) {
        return this.listener.remove(l);
    }

    @Override
    public void run() {
        while (!this.networkManager.isTerminated()) {
            this.runTick();
            try {
                Thread.sleep(50L);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void runTick() {
        this.networkManager.processReadPacket();
        this.networkManager.flush();
    }

    public void setOnlineUsers(IRCUser[] users) {
        this.onlineUsers.clear();
        this.onlineUsers.ensureCapacity(users.length);
        Collections.addAll(this.onlineUsers, users);
    }

    public IRCUser[] getOnlineUsers() {
        return this.onlineUsers.toArray(new IRCUser[0]);
    }

    public void sendMessage(String message) {
        message = "\u00a7e[IRC] \u00a7r" + message;
        DebugUtil.log(message);
        System.out.println(message);
    }

    public boolean addOnlineUser(IRCUser user) {
        return this.onlineUsers.add(user);
    }

    public boolean removeOnlineUser(IRCUser user) {
        return this.onlineUsers.remove(user);
    }

    public IRCUser getOnlineUser(long userid) {
        for (IRCUser ircUser : this.onlineUsers) {
            if (ircUser.getUserid() != userid) continue;
            return ircUser;
        }
        return null;
    }

    public IRCUser getOnlineUser(String username) {
        for (IRCUser ircUser : this.onlineUsers) {
            if (!ircUser.getUsername().equals(username)) continue;
            return ircUser;
        }
        return null;
    }

    public void setDisconnetHook(Consumer<String> disconnetHook) {
        this.disconnetHook = disconnetHook;
    }
}

