package cc.xylitol.irc;

import cc.xylitol.irc.IRCClient;
import cc.xylitol.irc.NetHandler;
import cc.xylitol.irc.packet.Packet;
import cc.xylitol.irc.packet.Packet00KeepAlive;
import cc.xylitol.irc.packet.Packet01Login;
import cc.xylitol.irc.packet.Packet02Chat;
import cc.xylitol.irc.packet.Packet03SetUserList;
import cc.xylitol.irc.packet.Packet04ChangeUserList;
import cc.xylitol.irc.packet.Packet05EncryptRequest;
import cc.xylitol.irc.packet.Packet06EncryptResponse;
import cc.xylitol.irc.packet.Packet07ChangeIGN;
import cc.xylitol.irc.packet.Packet08CustomPayload;
import cc.xylitol.irc.packet.PacketFFDisconnect;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.Socket;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import top.fl0wowp4rty.phantomshield.annotations.Native;

public class NetworkManager {
    private static final int MAX_PROCESS_COUNT = 100;
    private static final int MAX_WRITE_COUNT = 100;
    private static final Map<Integer, Class<? extends Packet>> MAPPING = new HashMap<Integer, Class<? extends Packet>>();
    private final LinkedList<Packet> incoming = new LinkedList();
    private final LinkedList<Packet> outgoing = new LinkedList();
    private final Socket socket;
    private final IRCClient ircClient;
    private final DataInputStream input;
    private final DataOutputStream output;
    private boolean terminated;
    private final NetHandler netHandler;
    private Cipher outgoingCipher;
    private Cipher incomingCipher;
    private SecretKey key;

    public NetworkManager(Socket socket, IRCClient ircClient, final NetHandler netHandler) throws IOException {
        this.socket = socket;
        this.ircClient = ircClient;
        this.input = new DataInputStream(socket.getInputStream());
        this.output = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
        this.netHandler = netHandler;
        netHandler.netMgr = this;
        new Thread("Network read thread"){

            @Override
            public void run() {
                try {
                    while (!NetworkManager.this.terminated) {
                        NetworkManager.this.readPacket();
                    }
                }
                catch (IOException e) {
                    if (NetworkManager.this.terminated) {
                        return;
                    }
                    e.printStackTrace();
                    netHandler.onConnectionClosed("Connection lost: " + e);
                    NetworkManager.this.terminate();
                }
            }
        }.start();
    }

    protected void sendPacket(Packet packet) {
        try {
            ByteArrayOutputStream bOut = new ByteArrayOutputStream();
            packet.writePacket(new DataOutputStream(bOut));
            byte[] data = bOut.toByteArray();
            if (this.outgoingCipher != null && data.length > 0) {
                int blockSize = this.outgoingCipher.getBlockSize();
                int mask = blockSize - 1;
                byte[] pad = new byte[data.length + mask & ~mask];
                System.arraycopy(data, 0, pad, 0, data.length);
                data = this.outgoingCipher.update(pad);
            }
            this.output.writeByte(packet.getPacketId());
            this.output.writeShort(data.length);
            this.output.write(data);
            this.output.flush();
        }
        catch (IOException e) {
            e.printStackTrace();
            if (!this.terminated) {
                this.netHandler.onConnectionClosed("Connection lost: " + e);
            }
            this.terminate();
        }
    }

    public void readPacket() throws IOException {
        Packet packet;
        int packetid = this.input.readUnsignedByte();
        if (!MAPPING.containsKey(packetid)) {
            throw new IOException("Unknown packet id: " + packetid);
        }
        int packetlength = this.input.readUnsignedShort();
        try {
            packet = MAPPING.get(packetid).getConstructor(new Class[0]).newInstance();
        }
        catch (IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
        byte[] buf = new byte[packetlength];
        this.input.readFully(buf);
        if (this.incomingCipher != null && packetlength > 0) {
            buf = this.incomingCipher.update(buf);
        }
        packet.readPacket(new DataInputStream(new ByteArrayInputStream(buf)));
        this.incoming.addLast(packet);
    }

    public synchronized boolean flush() {
        if (this.terminated) {
            return false;
        }
        for (int i = 0; i < 100 && !this.outgoing.isEmpty(); ++i) {
            this.sendPacket(this.outgoing.poll());
        }
        return !this.outgoing.isEmpty();
    }

    public boolean processReadPacket() {
        for (int i = 0; i < 100 && !this.incoming.isEmpty(); ++i) {
            this.incoming.poll().handlePacket(this.netHandler);
        }
        return !this.incoming.isEmpty();
    }

    public boolean addToSendQueue(Packet packet) {
        if (this.terminated) {
            return false;
        }
        return this.outgoing.add(packet);
    }

    public boolean isTerminated() {
        return this.terminated;
    }

    public void terminate() {
        this.terminated = true;
        try {
            this.socket.shutdownInput();
            this.socket.shutdownOutput();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void shutdown(String message) {
        this.sendPacket(new PacketFFDisconnect(message));
        this.terminate();
    }

    public IRCClient getClient() {
        return this.ircClient;
    }

    private static void addMapping(int id, Class<? extends Packet> clazz) {
        if (!MAPPING.containsKey(id)) {
            MAPPING.put(id, clazz);
        }
    }

    @Native
    public void setEncryption(SecretKey key) {
        this.key = key;
        try {
            byte[] iv = Arrays.copyOf(key.getEncoded(), 16);
            Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
            cipher.init(1, key, new IvParameterSpec(iv));
            this.outgoingCipher = cipher;
            cipher = Cipher.getInstance("AES/CFB8/NoPadding");
            cipher.init(2, key, new IvParameterSpec(iv));
            this.incomingCipher = cipher;
        }
        catch (Throwable t) {
            throw new Error(t);
        }
    }

    static {
        NetworkManager.addMapping(0, Packet00KeepAlive.class);
        NetworkManager.addMapping(1, Packet01Login.class);
        NetworkManager.addMapping(2, Packet02Chat.class);
        NetworkManager.addMapping(3, Packet03SetUserList.class);
        NetworkManager.addMapping(4, Packet04ChangeUserList.class);
        NetworkManager.addMapping(5, Packet05EncryptRequest.class);
        NetworkManager.addMapping(6, Packet06EncryptResponse.class);
        NetworkManager.addMapping(7, Packet07ChangeIGN.class);
        NetworkManager.addMapping(8, Packet08CustomPayload.class);
        NetworkManager.addMapping(255, PacketFFDisconnect.class);
    }
}

