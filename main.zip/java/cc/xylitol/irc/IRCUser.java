package cc.xylitol.irc;

import cc.xylitol.irc.ClientType;
import java.util.Objects;

public class IRCUser {
    private final boolean anonymous;
    private final String username;
    private final String rank;
    private final long userid;
    private String ingamename;
    private final ClientType clientType;

    public IRCUser(String ingamename, long userid, ClientType clientType) {
        this.anonymous = true;
        this.username = "Guest";
        this.setIngamename(ingamename);
        this.rank = null;
        this.userid = userid;
        this.clientType = clientType;
    }

    public IRCUser(String ingamename, String username, String rank, long userid, ClientType clientType) {
        this.anonymous = false;
        this.setIngamename(ingamename);
        this.username = username;
        this.rank = rank;
        this.userid = userid;
        this.clientType = clientType;
    }

    public int hashCode() {
        return Objects.hash(this.anonymous, this.ingamename, this.rank, this.userid, this.username);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof IRCUser)) {
            return false;
        }
        IRCUser other = (IRCUser)obj;
        return this.userid == other.userid;
    }

    public boolean isAnonymous() {
        return this.anonymous;
    }

    public String getUsername() {
        return this.username;
    }

    public String getRank() {
        return this.rank;
    }

    public long getUserid() {
        return this.userid;
    }

    public String getIngamename() {
        return this.ingamename;
    }

    public void setIngamename(String ingamename) {
        this.ingamename = ingamename;
    }
}

