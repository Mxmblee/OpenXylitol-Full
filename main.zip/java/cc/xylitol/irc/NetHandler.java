package cc.xylitol.irc;

import cc.xylitol.irc.IRCClient;
import cc.xylitol.irc.NetworkManager;
import cc.xylitol.irc.packet.Packet;
import cc.xylitol.irc.packet.Packet00KeepAlive;
import cc.xylitol.irc.packet.Packet01Login;
import cc.xylitol.irc.packet.Packet02Chat;
import cc.xylitol.irc.packet.Packet03SetUserList;
import cc.xylitol.irc.packet.Packet04ChangeUserList;
import cc.xylitol.irc.packet.Packet05EncryptRequest;
import cc.xylitol.irc.packet.Packet06EncryptResponse;
import cc.xylitol.irc.packet.Packet07ChangeIGN;
import cc.xylitol.irc.packet.Packet08CustomPayload;
import cc.xylitol.irc.packet.PacketFFDisconnect;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import top.fl0wowp4rty.phantomshield.annotations.Native;

public class NetHandler {
    protected NetworkManager netMgr;

    protected void unhandlePacket(Packet packet) {
    }

    public void handleKeepAlive(Packet00KeepAlive packet) {
        this.netMgr.addToSendQueue(packet);
    }

    public void handleLogin(Packet01Login packet) {
        this.unhandlePacket(packet);
    }

    public void handleChat(Packet02Chat packet) {
        this.unhandlePacket(packet);
    }

    public void handleSetUser(Packet03SetUserList packet) {
        this.netMgr.getClient().setOnlineUsers(packet.getUsers());
    }

    public void handleUserListChanged(Packet04ChangeUserList packet) {
        IRCClient client = this.netMgr.getClient();
        if (packet.isAdd()) {
            client.addOnlineUser(packet.getUser());
        } else {
            client.removeOnlineUser(packet.getUser());
        }
    }

    public void handleDisconnect(PacketFFDisconnect packet) {
        this.onConnectionClosed("Connection lost: " + packet.getReason());
        this.netMgr.terminate();
    }

    public void addToSendQueue(Packet packet) {
        this.netMgr.addToSendQueue(packet);
    }

    @Native
    public void handleEncryptRequest(Packet05EncryptRequest packet) {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey publicKey = keyFactory.generatePublic(new RSAPublicKeySpec(new BigInteger("0089D2485F09E6547AA3D1299FB3BB75200125C4D6D3F902496A7FECE2DE4EF49492830743C70A44944EF9BF0CB880382D7CCD1C055EAEA47DE5235643826800B5D9EC8F0EDEEACD465464805610DA8E63EC951B0374D628F7141B2633314294A5F0A1E2790C28AC4BEC0CB0DCC81B145A965BF0FF0E3DA6068236E8E54DE8021272A2424F72F47238D44F9B69F6C28B1AE6A6BF2AC252F1A187916F3C8BDD52B12B0C2E84A5BF576CE15C7E80E69D2D4144F213FD444986F559B8AE403656449343C8BCA9165B0A8CB0814DEBF9B86C1AFE04943849A982089E4A2CD54349D9E6CE9BA5B333698281B8C9D36724CE9F2562BBF527A5253FDB5ADBF1C8A89FCADF11687ABAE00AD39F19D3516229EF0900686706F09EF76B7FEDA49CCFE1722CAB9FE56A0FA201077DFF8CE26F0AB0B6D7FABCFB4460AF15796BABC8B1AE540AEB667C0AF8440FA65F1CF39D8DD48DCE3E0414AA900D20475938A5518FF7A468BFEC9CEF4EDBB9450141B89C29DEDD0FA41DB960869E120FFE6D49097BE6AF4A50C813FE03DF4430FC54475AB094CC55B927B33DECFBAF73AACB5F8423C25977B9A1C999814B415208496CD5C33A3EF4801140C8632A325F895A410F4B600E587B185F8A0EE8DFA119F8B64082124443384E662F26877AB63E9A9F4934581AA7DF997E1C24761F53A4640580982051D2250A97506FF44F0340A414B84163008B79", 16), BigInteger.valueOf(65537L)));
            Signature sign = Signature.getInstance("SHA256withRSA");
            sign.initVerify(publicKey);
            sign.update(packet.getPublicKey());
            boolean verify = sign.verify(packet.getSign());
            if (!verify) {
                this.onConnectionClosed("Not a trusted IRC server, disconnected.");
                this.netMgr.terminate();
                return;
            }
            this.completeEncryption(packet);
        }
        catch (Throwable e) {
            e.printStackTrace();
            this.netMgr.terminate();
        }
    }

    public void handleCustomPayload(Packet08CustomPayload packet) {
        this.unhandlePacket(packet);
    }

    public void handleChangeIGN(Packet07ChangeIGN packet) {
        IRCClient client = this.netMgr.getClient();
        client.getOnlineUser(packet.getUserid()).setIngamename(packet.getIngameName());
    }

    @Native
    private void completeEncryption(Packet05EncryptRequest packet) throws Throwable {
        byte[] encodedKey;
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256);
        SecretKey key = keyGenerator.generateKey();
        byte[] data = encodedKey = key.getEncoded();
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(new X509EncodedKeySpec(packet.getPublicKey()));
        Cipher rsa = Cipher.getInstance("RSA");
        rsa.init(1, publicKey);
        byte[] encryptedData = rsa.doFinal(data);
        this.addToSendQueue(new Packet06EncryptResponse(encryptedData));
        this.netMgr.flush();
        this.netMgr.setEncryption(key);
    }

    protected void onConnectionClosed(String reason) {
    }
}

