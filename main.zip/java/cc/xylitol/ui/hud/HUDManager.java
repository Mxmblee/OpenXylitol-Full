package cc.xylitol.ui.hud;

import cc.xylitol.Client;
import cc.xylitol.ui.hud.HUD;
import cc.xylitol.ui.hud.impl.Chest;
import cc.xylitol.ui.hud.impl.Effects;
import cc.xylitol.ui.hud.impl.Inventory;
import cc.xylitol.ui.hud.impl.ModuleList;
import cc.xylitol.ui.hud.impl.SessionInfo;
import cc.xylitol.ui.hud.impl.TargetHUD;
import cc.xylitol.ui.hud.impl.Watermark;
import cc.xylitol.value.Value;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class HUDManager {
    public Map<String, HUD> hudObjects = new HashMap<String, HUD>();

    public void init() {
        this.add(new ModuleList());
        this.add(new Watermark());
        this.add(new TargetHUD());
        this.add(new SessionInfo());
        this.add(new Effects());
        this.add(new Inventory());
        this.add(new Chest());
    }

    private void add(HUD hud) {
        this.hudObjects.put(hud.getClass().getSimpleName(), hud);
        for (Field field : hud.getClass().getDeclaredFields()) {
            try {
                field.setAccessible(true);
                Object obj = field.get(hud);
                if (!(obj instanceof Value)) continue;
                hud.m.getValues().add((Value)obj);
            }
            catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        Client.instance.moduleManager.getModuleMap().put(hud.getClass().getSimpleName(), hud.m);
    }
}

