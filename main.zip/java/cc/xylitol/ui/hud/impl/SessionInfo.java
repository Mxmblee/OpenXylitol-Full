package cc.xylitol.ui.hud.impl;

import cc.xylitol.Client;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.hud.HUD;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.shader.ShaderElement;
import java.awt.Color;
import top.fl0wowp4rty.phantomshield.api.User;

public class SessionInfo
extends HUD {
    public static int startTime;

    public SessionInfo() {
        super(150, 20, "SessionInfo");
    }

    @Override
    public void drawShader() {
    }

    @Override
    public void predrawhud() {
    }

    @Override
    public void drawHUD(int xPos, int yPos, float partialTicks) {
        this.setWidth(150);
        this.setHeight(60);
        float y = (float)yPos + 6.0f;
        float infoWidth = (float)(xPos + this.getWidth()) - 6.0f;
        RenderUtil.drawRectWH(xPos, yPos, this.getWidth(), 1.0, cc.xylitol.module.impl.render.HUD.color(1).getRGB());
        RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight() + 10, new Color(0, 0, 0, 100).getRGB());
        FontManager.tenacitybold.drawStringDynamic("INFO", (float)xPos + 6.0f, y, 1, 6);
        ShaderElement.addBlurTask(() -> RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight() + 10, new Color(0, 0, 0, 255).getRGB()));
        ShaderElement.addBloomTask(() -> RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight() + 10, new Color(0, 0, 0, 255).getRGB()));
        FontManager.font16.drawString("User", (float)xPos + 6.0f, (y += (float)FontManager.font22.getHeight() + 1.0f) - 3.0f, -1);
        FontManager.font16.drawString(User.INSTANCE.getUsername("Insane1337"), infoWidth - (float)FontManager.font16.getStringWidth(User.INSTANCE.getUsername("Insane1337")), y - 3.0f, -1);
        FontManager.font16.drawString("SessionName", (float)xPos + 6.0f, y + 10.0f, -1);
        String name = SessionInfo.mc.thePlayer.getNameClear();
        FontManager.font16.drawString(name, infoWidth - (float)FontManager.font16.getStringWidth(name), y + 10.0f, -1);
        FontManager.font16.drawString("SessionTime", (float)xPos + 6.0f, (y += (float)FontManager.font16.getHeight() + 2.0f) + 10.0f, -1);
        String timeString = SessionInfo.sessionTime();
        FontManager.font16.drawString(timeString, infoWidth - (float)FontManager.font16.getStringWidth(timeString) + 3.0f, y + 10.0f, -1);
        FontManager.font16.drawString("Bans", (float)xPos + 6.0f, (y += (float)FontManager.font16.getHeight() + 2.0f) + 10.0f, -1);
        String bans = String.valueOf(Client.instance.banManager.bans);
        FontManager.font16.drawString(bans, infoWidth - (float)FontManager.font16.getStringWidth(bans), y + 10.0f, -1);
        y += (float)FontManager.font16.getHeight() + 2.0f;
    }

    public static String sessionTime() {
        int elapsedTime = ((int)System.currentTimeMillis() - startTime) / 1000;
        String days = elapsedTime > 86400 ? elapsedTime / 86400 + "d " : "";
        elapsedTime = !days.equals("") ? elapsedTime % 86400 : elapsedTime;
        String hours = elapsedTime > 3600 ? elapsedTime / 3600 + "h " : "";
        elapsedTime = !hours.equals("") ? elapsedTime % 3600 : elapsedTime;
        String minutes = elapsedTime > 60 ? elapsedTime / 60 + "m " : "";
        elapsedTime = !minutes.equals("") ? elapsedTime % 60 : elapsedTime;
        String seconds = elapsedTime > 0 ? elapsedTime + "s " : "";
        return days + hours + minutes + seconds;
    }
}

