package cc.xylitol.ui.hud.impl;

import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.hud.HUD;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.RoundedUtil;
import cc.xylitol.utils.render.animation.Direction;
import cc.xylitol.utils.render.animation.impl.ContinualAnimation;
import cc.xylitol.utils.render.animation.impl.EaseBackIn;
import cc.xylitol.utils.render.shader.ShaderElement;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;

public class Effects
extends HUD {
    private final Map<Integer, Integer> potionMaxDurations = new HashMap<Integer, Integer>();
    private final ContinualAnimation widthanimation = new ContinualAnimation();
    private final ContinualAnimation heightanimation = new ContinualAnimation();
    private final EaseBackIn animation = new EaseBackIn(200, 1.0, 1.3f);
    List<PotionEffect> effects = new ArrayList<PotionEffect>();
    private int maxString = 0;

    public Effects() {
        super(150, 100, "Effects");
    }

    @Override
    public void drawShader() {
    }

    @Override
    public void drawHUD(int x, int y, float partialTicks) {
        this.effects = Effects.mc.thePlayer.getActivePotionEffects().stream().sorted(Comparator.comparingInt(it -> FontManager.font16.getStringWidth(this.get(it)))).collect(Collectors.toList());
        int offsetX = 21;
        int offsetY = 14;
        int i2 = 16;
        ArrayList<Integer> needRemove = new ArrayList<Integer>();
        for (Map.Entry<Integer, Integer> entry : this.potionMaxDurations.entrySet()) {
            if (Effects.mc.thePlayer.getActivePotionEffect(Potion.potionTypes[entry.getKey()]) != null) continue;
            needRemove.add(entry.getKey());
        }
        Iterator iterator = needRemove.iterator();
        while (iterator.hasNext()) {
            int id = (Integer) iterator.next();
            this.potionMaxDurations.remove(id);
        }
        for (PotionEffect effect : this.effects) {
            if (this.potionMaxDurations.containsKey(effect.getPotionID()) && this.potionMaxDurations.get(effect.getPotionID()) >= effect.getDuration()) continue;
            this.potionMaxDurations.put(effect.getPotionID(), effect.getDuration());
        }
        float width = !this.effects.isEmpty() ? (float)Math.max(50 + FontManager.font16.getStringWidth(this.get(this.effects.get(this.effects.size() - 1))), 60 + FontManager.font16.getStringWidth(this.get(this.effects.get(this.effects.size() - 1)))) : 0.0f;
        float height = this.effects.size() * 25;
        this.widthanimation.animate(width, 20);
        this.heightanimation.animate(height, 20);
        if (Effects.mc.currentScreen instanceof GuiChat && this.effects.isEmpty()) {
            this.animation.setDirection(Direction.FORWARDS);
        } else if (!(Effects.mc.currentScreen instanceof GuiChat)) {
            this.animation.setDirection(Direction.BACKWARDS);
        }
        RenderUtil.scaleStart(x + 50, y + 15, (float)this.animation.getOutput());
        FontManager.font16.drawStringWithShadow("Potion Example", (float)x + 50.0f - (float)(FontManager.font16.getStringWidth("Potion Example") / 2), y + 15 - FontManager.font16.getHeight() / 2, new Color(255, 255, 255, 60).getRGB());
        RenderUtil.scaleEnd();
        if (this.effects.isEmpty()) {
            this.maxString = 0;
        }
        if (!this.effects.isEmpty()) {
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.disableLighting();
            int l = 24;
            RenderUtil.drawRectWH(x, y - 18, this.getWidth(), 1.0, cc.xylitol.module.impl.render.HUD.color(1).getRGB());
            RenderUtil.drawRectWH(x, y - 17, this.widthanimation.getOutput(), 17.0, new Color(0, 0, 0, 100).getRGB());
            ShaderElement.addBlurTask(() -> RenderUtil.drawRectWH(x, y, (int)this.widthanimation.getOutput(), (int)this.heightanimation.getOutput(), new Color(0, 0, 0, 255).getRGB()));
            ShaderElement.addBlurTask(() -> RenderUtil.drawRectWH(x, y - 17, this.widthanimation.getOutput(), 17.0, new Color(0, 0, 0, 255).getRGB()));
            ShaderElement.addBloomTask(() -> RenderUtil.drawRectWH(x, y, (int)this.widthanimation.getOutput(), (int)this.heightanimation.getOutput(), new Color(0, 0, 0, 255).getRGB()));
            ShaderElement.addBloomTask(() -> RenderUtil.drawRectWH(x, y - 17, this.widthanimation.getOutput(), 17.0, new Color(0, 0, 0, 255).getRGB()));
            RenderUtil.drawRectWH(x, y, (int)this.widthanimation.getOutput(), (int)this.heightanimation.getOutput(), new Color(0, 0, 0, 100).getRGB());
            FontManager.tenacitybold.drawStringDynamic("Potion", (float)x + 6.0f, y - 17 + 8, 1, 6);
            RenderUtil.startGlScissor(x, y, (int)this.widthanimation.getOutput(), (int)this.heightanimation.getOutput());
            for (PotionEffect potioneffect : this.effects) {
                Potion potion = Potion.potionTypes[potioneffect.getPotionID()];
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                if (potion.hasStatusIcon()) {
                    mc.getTextureManager().bindTexture(new ResourceLocation("textures/gui/container/inventory.png"));
                    int i1 = potion.getStatusIconIndex();
                    GlStateManager.enableBlend();
                    RenderUtil.drawImage(new ResourceLocation("xylitol/images/" + (potioneffect.getIsPotionDurationMax() ? "infinite" : "potions/" + potioneffect.getPotionID()) + ".png"), x + offsetX - 15, y + i2 - offsetY + 2, 10.0, 10.0, new Color(Potion.potionTypes[potioneffect.getPotionID()].getLiquidColor()).getRGB());
                }
                String s = Potion.getDurationString(potioneffect);
                String s1 = this.get(potioneffect);
                FontManager.font18.drawString(s1, (float)(x + offsetX) - 2.0f, y + i2 - offsetY + 4, -1);
                RoundedUtil.drawGradientHorizontal(x + 6, y + i2 - offsetY + 16, (float)potioneffect.getDuration() / ((float) this.potionMaxDurations.get(potioneffect.getPotionID()).intValue()) * (this.widthanimation.getOutput() - 12.0f), 2.0f, 1.5f, cc.xylitol.module.impl.render.HUD.color(1), cc.xylitol.module.impl.render.HUD.color(6));
                i2 += l;
                if (this.maxString >= Effects.mc.fontRendererObj.getStringWidth(s1)) continue;
                this.maxString = Effects.mc.fontRendererObj.getStringWidth(s1);
            }
            RenderUtil.stopGlScissor();
        }
        if (Effects.mc.currentScreen instanceof GuiChat && this.effects.isEmpty()) {
            this.setWidth(100);
            this.setHeight(30);
        } else {
            this.setWidth((int)this.widthanimation.getOutput());
            this.setHeight((int)this.heightanimation.getOutput());
        }
    }

    @Override
    public void predrawhud() {
    }

    private String get(PotionEffect potioneffect) {
        Potion potion = Potion.potionTypes[potioneffect.getPotionID()];
        String s1 = I18n.format(potion.getName());
        s1 = s1 + " " + this.intToRomanByGreedy(potioneffect.getAmplifier() + 1);
        return s1;
    }

    private String intToRomanByGreedy(int num) {
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] symbols = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < values.length && num >= 0; ++i) {
            while (values[i] <= num) {
                num -= values[i];
                stringBuilder.append(symbols[i]);
            }
        }
        return stringBuilder.toString();
    }
}

