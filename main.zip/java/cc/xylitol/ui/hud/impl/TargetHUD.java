package cc.xylitol.ui.hud.impl;

import cc.xylitol.Client;
import cc.xylitol.module.impl.combat.KillAura;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.hud.HUD;
import cc.xylitol.utils.math.MathUtils;
import cc.xylitol.utils.render.ColorUtil;
import cc.xylitol.utils.render.GLUtil;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.RoundedUtil;
import cc.xylitol.utils.render.StencilUtil;
import cc.xylitol.utils.render.animation.Animation;
import cc.xylitol.utils.render.animation.Direction;
import cc.xylitol.utils.render.animation.impl.ContinualAnimation;
import cc.xylitol.utils.render.animation.impl.DecelerateAnimation;
import cc.xylitol.utils.render.shader.ShaderElement;
import cc.xylitol.value.impl.ModeValue;
import cc.xylitol.value.impl.NumberValue;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

public class TargetHUD
extends HUD {
    public ModeValue mode = new ModeValue("Mode", new String[]{"Xylitol", "Exire", "Exhibition", "Tenacity", "Akrien"}, "Xylitol");
    private final NumberValue bgAlpha = new NumberValue("Background Alpha", 100.0, 0.0, 255.0, 1.0, () -> this.mode.is("Novoline Fky"));
    private final ContinualAnimation animation2 = new ContinualAnimation();
    private final Animation openAnimation = new DecelerateAnimation(175, 0.5);
    private final DecimalFormat DF_1 = new DecimalFormat("0.0");
    private EntityLivingBase target;

    public TargetHUD() {
        super(150, 100, "TargetHUD");
    }

    @Override
    public void drawShader() {
    }

    @Override
    public void drawHUD(int xPos, int yPos, float partialTicks) {
        GlStateManager.pushMatrix();
        RenderUtil.scaleStart((float)xPos + (float)this.getWidth() / 2.0f, (float)yPos + (float)this.getHeight() / 2.0f, (float)(0.5 + this.openAnimation.getOutput()));
        float alpha = (float)Math.min(1.0, this.openAnimation.getOutput() * 2.0);
        if (this.target != null) {
            this.render(xPos, yPos, alpha, this.target, false);
        }
        RenderUtil.scaleEnd();
        GlStateManager.popMatrix();
    }

    @Override
    public void predrawhud() {
        KillAura killAura = Client.instance.moduleManager.getModule(KillAura.class);
        if (!(TargetHUD.mc.currentScreen instanceof GuiChat)) {
            if (!killAura.getState()) {
                this.openAnimation.setDirection(Direction.BACKWARDS);
            }
            if (this.target == null && KillAura.target != null) {
                this.target = KillAura.target;
                this.openAnimation.setDirection(Direction.FORWARDS);
            } else if (KillAura.target == null || this.target != KillAura.target) {
                this.openAnimation.setDirection(Direction.BACKWARDS);
            }
            if (this.openAnimation.finished(Direction.BACKWARDS)) {
                this.target = null;
            }
        } else {
            this.openAnimation.setDirection(Direction.FORWARDS);
            this.target = TargetHUD.mc.thePlayer;
        }
    }

    public void render(float x, float y, float alpha, EntityLivingBase target, boolean blur) {
        GlStateManager.pushMatrix();
        switch (this.mode.getValue().toLowerCase()) {
            case "xylitol": {
                this.setWidth(Math.max(120, FontManager.font18.getStringWidth(target.getName()) + 70));
                this.setHeight(39);
                double healthPercentage = MathHelper.clamp_float((target.animatedHealthBar + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0.0f, 1.0f);
                Color bg = new Color(0, 0, 0, (int)(100.0f * alpha));
                float hurtPercent = (float)target.hurtTime / 10.0f;
                float scale = hurtPercent == 0.0f ? 1.0f : (hurtPercent < 0.5f ? 1.0f - 0.1f * hurtPercent * 2.0f : 0.9f + 0.1f * (hurtPercent - 0.5f) * 2.0f);
                RoundedUtil.drawRound((int)x, (int)y, this.getWidth(), 39, 4.0f, bg);
                float finalX = x;
                if (this.openAnimation.isDone()) {
                    ShaderElement.addBlurTask(() -> RoundedUtil.drawRound((int)finalX, (int)y, this.getWidth(), 39, 4.0f, Color.BLACK));
                    ShaderElement.addBloomTask(() -> RoundedUtil.drawRound((int)finalX, (int)y, this.getWidth(), 39, 4.0f, Color.BLACK));
                }
                float endWidth = (float)Math.max(0.0, (double)(this.getWidth() - 44) * healthPercentage);
                this.animation2.animate(endWidth, 18);
                if (this.animation2.getOutput() > 0.0f) {
                    RoundedUtil.drawGradientHorizontal((float)((double)(x + 32.0f) + 2.5), y + 29.0f, 1.5f + this.animation2.getOutput(), 2.5f, 2.0f, cc.xylitol.module.impl.render.HUD.color(1), cc.xylitol.module.impl.render.HUD.color(6));
                }
                GlStateManager.pushMatrix();
                RenderUtil.setAlphaLimit(0.0f);
                int textColor = ColorUtil.applyOpacity(-1, alpha);
                if (target instanceof AbstractClientPlayer) {
                    RenderUtil.color(textColor);
                    float f = 0.8125f;
                    GlStateManager.scale(f, f, f);
                    RenderUtil.scaleStart(x / f + 6.0f + 16.0f, y / f + 8.0f + 16.0f, scale);
                    GL11.glColor4f(1.0f, 1.0f - hurtPercent, 1.0f - hurtPercent, 1.0f);
                    RenderUtil.drawBigHeadRound(x / f + 6.0f, y / f + 8.0f, 32.0f, 32.0f, (AbstractClientPlayer)target);
                    RenderUtil.scaleEnd();
                }
                GlStateManager.popMatrix();
                if (this.openAnimation.getDirection() != Direction.BACKWARDS) {
                    FontManager.font18.drawStringDynamic("name: ", x + 32.0f + 2.0f, y + 7.0f, 1, 6);
                    FontManager.font18.drawString(target.getName(), x + 32.0f + 2.0f + (float)FontManager.font18.getStringWidth("name: "), y + 7.0f, textColor);
                    FontManager.font18.drawStringDynamic("health: ", x + 32.0f + 2.0f, y + 18.0f, 1, 6);
                    FontManager.font18.drawString(this.DF_1.format(target.animatedHealthBar) + "hp", x + 32.0f + 2.0f + (float)FontManager.font18.getStringWidth("health: "), y + 18.0f, textColor);
                }
                float delta = RenderUtil.deltaTime;
                target.animatedHealthBar = (float)((double)target.animatedHealthBar + (double)(target.getHealth() - target.animatedHealthBar) / Math.pow(2.0, 6.0) * (double)delta);
                break;
            }
            case "exhibition": {
                GlStateManager.pushMatrix();
                this.width = (int)((float)FontManager.font18.getStringWidth(target.getName()) > 70.0f ? (double)(125.0f + (float)FontManager.font18.getStringWidth(target.getName()) - 70.0f) : 125.0);
                this.height = 45;
                GlStateManager.translate(x, y + 6.0f, 0.0f);
                RenderUtil.skeetRect(0.0, -2.0, (float)FontManager.font18.getStringWidth(target.getName()) > 70.0f ? (double)(124.0f + (float)FontManager.font18.getStringWidth(target.getName()) - 70.0f) : 124.0, 38.0, 1.0);
                RenderUtil.skeetRectSmall(0.0, -2.0, 124.0, 38.0, 1.0);
                FontManager.font18.drawStringWithShadow(target.getName(), 41.0f, 0.3f, -1);
                float health = target.getHealth();
                float healthWithAbsorption = target.getHealth() + target.getAbsorptionAmount();
                float progress = health / target.getMaxHealth();
                Color healthColor = health >= 0.0f ? ColorUtil.getBlendColor(target.getHealth(), target.getMaxHealth()).brighter() : Color.RED;
                double cockWidth = 0.0;
                cockWidth = MathUtils.round(cockWidth, 5);
                if (cockWidth < 50.0) {
                    cockWidth = 50.0;
                }
                double healthBarPos = cockWidth * (double)progress;
                Gui.drawRect(42.5, 10.3, 53.0 + healthBarPos + 0.5, 13.5, healthColor.getRGB());
                if (target.getAbsorptionAmount() > 0.0f) {
                    Gui.drawRect(97.5 - (double)target.getAbsorptionAmount(), 10.3, 103.5, 13.5, new Color(137, 112, 9).getRGB());
                }
                RenderUtil.drawBorderedRect2(42.0, 9.8f, 54.0 + cockWidth, 14.0, 0.5, 0, Color.BLACK.getRGB());
                for (int dist = 1; dist < 10; ++dist) {
                    double cock = cockWidth / 8.5 * (double)dist;
                    Gui.drawRect(43.5 + cock, 9.8, 43.5 + cock + 0.5, 14.0, Color.BLACK.getRGB());
                }
                GlStateManager.scale(0.5, 0.5, 0.5);
                int distance = (int)TargetHUD.mc.thePlayer.getDistanceToEntity(target);
                String nice = "HP: " + (int)healthWithAbsorption + " | Dist: " + distance;
                TargetHUD.mc.fontRendererObj.drawString(nice, 85.3f, 32.3f, -1, true);
                GlStateManager.scale(2.0, 2.0, 2.0);
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.enableAlpha();
                GlStateManager.enableBlend();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                if (target != null) {
                    TargetHUD.drawEquippedShit(28, 20, target);
                }
                GlStateManager.disableAlpha();
                GlStateManager.disableBlend();
                GlStateManager.scale(0.31, 0.31, 0.31);
                GlStateManager.translate(73.0f, 102.0f, 40.0f);
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                this.drawModel(target.rotationYaw, target.rotationPitch, target);
                GlStateManager.popMatrix();
                break;
            }
            case "exire": {
                Color firstColor = cc.xylitol.module.impl.render.HUD.color(1);
                Color secondColor = cc.xylitol.module.impl.render.HUD.color(6);
                float hurtPercent = (float)target.hurtTime / 10.0f;
                this.setWidth((int)Math.max(70.0f, (float)(FontManager.font18.getStringWidth(target.getName()) + 64)));
                this.setHeight(32);
                RenderUtil.drawRectWH(x, y, this.getWidth(), this.getHeight(), new Color(19, 19, 19, (int)(220.0f * alpha)).getRGB());
                if (this.openAnimation.getDirection() != Direction.BACKWARDS) {
                    FontManager.font24.drawStringWithShadow(target.getName(), x + 32.0f, y + 6.0f, Color.WHITE.getRGB());
                    RenderUtil.drawRectWH(x + 33.0f, y + 22.0f, (float)this.getWidth() - 38.0f, 6.0, new Color(0, 0, 0, (int)(230.0f * alpha)).getRGB());
                    RoundedUtil.drawGradientCornerLR(x + 33.0f, y + 23.0f, target.animatedHealthBar / target.getMaxHealth() * ((float)this.getWidth() - 38.0f), 4.0f, 0.0f, firstColor, secondColor);
                }
                int textColor = ColorUtil.applyOpacity(-1, alpha);
                if (target instanceof AbstractClientPlayer && this.openAnimation.getDirection() != Direction.BACKWARDS) {
                    GlStateManager.pushMatrix();
                    RenderUtil.color(textColor);
                    float f = 0.8125f;
                    GlStateManager.scale(f, f, f);
                    GL11.glColor4f(1.0f, 1.0f - hurtPercent, 1.0f - hurtPercent, 1.0f);
                    RenderUtil.drawBigHead(x / f + 3.0f, y / f + 3.5f, 32.0f, 32.0f, (AbstractClientPlayer)target);
                    GlStateManager.popMatrix();
                    GlStateManager.resetColor();
                }
                target.animatedHealthBar = (float)((double)target.animatedHealthBar + (double)(target.getHealth() - target.animatedHealthBar) / Math.pow(2.0, 6.0) * (double)RenderUtil.deltaTime);
                break;
            }
            case "tenacity": {
                this.setWidth(Math.max(145, FontManager.font20.getStringWidth(target.getName()) + 40));
                this.setHeight(37);
                Color c1 = ColorUtil.applyOpacity(cc.xylitol.module.impl.render.HUD.color(1), alpha);
                Color c2 = ColorUtil.applyOpacity(cc.xylitol.module.impl.render.HUD.color(6), alpha);
                Color color = new Color(20, 18, 18, (int)(90.0f * alpha));
                int textColor = ColorUtil.applyOpacity(-1, alpha);
                RoundedUtil.drawRound(x, y, (float)this.getWidth(), (float)this.getHeight(), 4.0f, color);
                float finalX2 = x;
                if (this.openAnimation.getDirection() != Direction.BACKWARDS) {
                    ShaderElement.addBlurTask(() -> RoundedUtil.drawRound(finalX2, y, (float)this.getWidth(), (float)this.getHeight(), 4.0f, Color.BLACK));
                    ShaderElement.addBloomTask(() -> RoundedUtil.drawRound(finalX2, y, (float)this.getWidth(), (float)this.getHeight(), 4.0f, Color.BLACK));
                }
                if (target instanceof AbstractClientPlayer) {
                    StencilUtil.write(false);
                    RenderUtil.renderRoundedRect(x + 3.0f, y + 3.0f, 31.0f, 31.0f, 4.0f, -1);
                    StencilUtil.erase(true);
                    RenderUtil.color(-1, alpha);
                    this.renderPlayer2D(x + 3.0f, y + 3.0f, 31.0f, 31.0f, (AbstractClientPlayer)target);
                    StencilUtil.dispose();
                } else if (this.openAnimation.getDirection() != Direction.BACKWARDS) {
                    FontManager.bold32.drawCenteredStringWithShadow("?", x + 19.0f, y + 20.0f - (float)FontManager.bold32.getHeight() / 2.0f, textColor);
                }
                if (this.openAnimation.getDirection() != Direction.BACKWARDS) {
                    FontManager.font20.drawStringWithShadow(target.getName(), x + 39.0f, y + 7.0f, textColor);
                }
                float healthPercent = MathHelper.clamp_float((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0.0f, 1.0f);
                float realHealthWidth = this.getWidth() - 44;
                float realHealthHeight = 3.0f;
                this.animation2.animate(realHealthWidth * healthPercent, 18);
                Color backgroundHealthColor = new Color(0, 0, 0, (int)alpha * 110);
                float healthWidth = this.animation2.getOutput();
                RoundedUtil.drawRound(x + 39.0f, y + (float)this.getHeight() - 12.0f, 98.0f, realHealthHeight, 1.5f, backgroundHealthColor);
                RoundedUtil.drawGradientHorizontal(x + 39.0f, y + (float)this.getHeight() - 12.0f, healthWidth, realHealthHeight, 1.5f, c1, c2);
                String healthText = (int)MathUtils.round(healthPercent * 100.0f, 0.01) + "%";
                if (this.openAnimation.getDirection() == Direction.BACKWARDS) break;
                FontManager.font16.drawStringWithShadow(healthText, x + 34.0f + Math.min(Math.max(1.0f, healthWidth), realHealthWidth - 11.0f), y + (float)this.getHeight() - (float)(10 + FontManager.font16.getHeight()), textColor);
                break;
            }
            case "akrien": {
                double armorValue;
                this.setWidth(Math.max(100, FontManager.font20.getStringWidth(target.getName()) + 45));
                this.setHeight(39);
                double healthPercentage = MathHelper.clamp_float((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0.0f, 1.0f);
                int bg = new Color(0.0f, 0.0f, 0.0f, 0.4f * alpha).getRGB();
                Gui.drawRect(x, y, x + (float)this.getWidth(), y + 39.5f, bg);
                if (this.openAnimation.isDone()) {
                    ShaderElement.addBlurTask(() -> Gui.drawRect(x, y, x + (float)this.getWidth(), y + 39.5f, Color.BLACK.getRGB()));
                    ShaderElement.addBloomTask(() -> Gui.drawRect(x, y, x + (float)this.getWidth(), y + 39.5f, Color.BLACK.getRGB()));
                }
                Gui.drawRect2((double)x + 2.5, y + 31.0f, (double)this.getWidth() - 4.5, 2.5, bg);
                Gui.drawRect2((double)x + 2.5, (double)y + 34.5, (double)this.getWidth() - 4.5, 2.5, bg);
                float endWidth = (float)Math.max(0.0, ((double)this.getWidth() - 3.5) * healthPercentage);
                this.animation2.animate(endWidth, 18);
                if (this.animation2.getOutput() > 0.0f) {
                    RenderUtil.drawGradientRectBordered((double)x + 2.5, y + 31.0f, (double)x + 1.5 + (double)this.animation2.getOutput(), (double)y + 33.5, 0.74, ColorUtil.applyOpacity(-16737215, alpha), ColorUtil.applyOpacity(-7405631, alpha), bg, bg);
                }
                if ((armorValue = (double)target.getTotalArmorValue() / 20.0) > 0.0) {
                    RenderUtil.drawGradientRectBordered((double)x + 2.5, (double)y + 34.5, (double)x + 1.5 + ((double)this.getWidth() - 3.5) * armorValue, y + 37.0f, 0.74, ColorUtil.applyOpacity(-16750672, alpha), ColorUtil.applyOpacity(-12986881, alpha), bg, bg);
                }
                GlStateManager.pushMatrix();
                RenderUtil.setAlphaLimit(0.0f);
                int textColor = ColorUtil.applyOpacity(-1, alpha);
                if (target instanceof AbstractClientPlayer) {
                    RenderUtil.color(textColor);
                    float f = 0.8125f;
                    GlStateManager.scale(f, f, f);
                    RenderUtil.drawBigHead(x / f + 3.0f, y / f + 3.0f, 32.0f, 32.0f, (AbstractClientPlayer)target);
                } else if (this.openAnimation.getDirection() != Direction.BACKWARDS) {
                    Gui.drawRect2(x + 3.0f, y + 3.0f, 25.0, 25.0, bg);
                    GlStateManager.scale(2.0f, 2.0f, 2.0f);
                    FontManager.font20.drawStringWithShadow("?", (x + 11.0f) / 2.0f, (y + 11.0f) / 2.0f - 2.0f, textColor);
                }
                GlStateManager.popMatrix();
                if (this.openAnimation.getDirection() == Direction.BACKWARDS) break;
                FontManager.font20.drawString(target.getName(), x + 31.0f, y + 2.0f, textColor);
                FontManager.font16.drawString("Health: " + this.DF_1.format(target.getHealth()), x + 31.0f, y + 13.0f, textColor);
                FontManager.font16.drawString("Distance: " + this.DF_1.format(TargetHUD.mc.thePlayer.getDistanceToEntity(target)) + " m", x + 31.0f, y + 22.0f, textColor);
                break;
            }
        }
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawEquippedShit(int x, int y, EntityLivingBase target) {
        if (!(target instanceof EntityPlayer)) {
            return;
        }
        GL11.glPushMatrix();
        ArrayList<ItemStack> stuff = new ArrayList<ItemStack>();
        int cock = -2;
        for (int geraltOfNigeria = 3; geraltOfNigeria >= 0; --geraltOfNigeria) {
            ItemStack armor = target.getCurrentArmor(geraltOfNigeria);
            if (armor == null) continue;
            stuff.add(armor);
        }
        if (target.getHeldItem() != null) {
            stuff.add(target.getHeldItem());
        }
        for (ItemStack yes : stuff) {
            if (Minecraft.getMinecraft().theWorld != null) {
                RenderHelper.enableGUIStandardItemLighting();
                cock += 16;
            }
            GlStateManager.pushMatrix();
            GlStateManager.disableAlpha();
            GlStateManager.clear(256);
            GlStateManager.enableBlend();
            Minecraft.getMinecraft().getRenderItem().renderItemIntoGUI(yes, cock + x, y);
            Minecraft.getMinecraft().getRenderItem().renderItemOverlays(Minecraft.getMinecraft().fontRendererObj, yes, cock + x, y);
            GlStateManager.disableBlend();
            GlStateManager.scale(0.5, 0.5, 0.5);
            GlStateManager.disableDepth();
            GlStateManager.disableLighting();
            GlStateManager.enableDepth();
            GlStateManager.scale(2.0f, 2.0f, 2.0f);
            GlStateManager.enableAlpha();
            GlStateManager.popMatrix();
            yes.getEnchantmentTagList();
        }
        GL11.glPopMatrix();
    }

    protected void renderPlayer2D(float x, float y, float width, float height, AbstractClientPlayer player) {
        GLUtil.startBlend();
        mc.getTextureManager().bindTexture(player.getLocationSkin());
        Gui.drawScaledCustomSizeModalRect(x, y, 8.0f, 8.0f, 8, 8, width, height, 64.0f, 64.0f);
        GLUtil.endBlend();
    }

    public void drawModel(float yaw, float pitch, EntityLivingBase entityLivingBase) {
        GlStateManager.resetColor();
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate(0.0f, 0.0f, 50.0f);
        GlStateManager.scale(-50.0f, 50.0f, 50.0f);
        GlStateManager.rotate(180.0f, 0.0f, 0.0f, 1.0f);
        float renderYawOffset = entityLivingBase.renderYawOffset;
        float rotationYaw = entityLivingBase.rotationYaw;
        float rotationPitch = entityLivingBase.rotationPitch;
        float prevRotationYawHead = entityLivingBase.prevRotationYawHead;
        float rotationYawHead = entityLivingBase.rotationYawHead;
        GlStateManager.rotate(135.0f, 0.0f, 1.0f, 0.0f);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate((float)(-Math.atan(pitch / 40.0f) * 20.0), 1.0f, 0.0f, 0.0f);
        entityLivingBase.renderYawOffset = yaw - 0.4f;
        entityLivingBase.rotationYaw = yaw - 0.2f;
        entityLivingBase.rotationPitch = pitch;
        entityLivingBase.rotationYawHead = entityLivingBase.rotationYaw;
        entityLivingBase.prevRotationYawHead = entityLivingBase.rotationYaw;
        GlStateManager.translate(0.0f, 0.0f, 0.0f);
        RenderManager renderManager = mc.getRenderManager();
        renderManager.setPlayerViewY(180.0f);
        renderManager.setRenderShadow(false);
        renderManager.renderEntityWithPosYaw(entityLivingBase, 0.0, 0.0, 0.0, 0.0f, 1.0f);
        renderManager.setRenderShadow(true);
        entityLivingBase.renderYawOffset = renderYawOffset;
        entityLivingBase.rotationYaw = rotationYaw;
        entityLivingBase.rotationPitch = rotationPitch;
        entityLivingBase.prevRotationYawHead = prevRotationYawHead;
        entityLivingBase.rotationYawHead = rotationYawHead;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
        GlStateManager.resetColor();
    }
}

