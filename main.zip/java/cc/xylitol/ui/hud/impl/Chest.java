package cc.xylitol.ui.hud.impl;

import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.hud.HUD;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.shader.ShaderElement;
import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.Slot;

public class Chest
extends HUD {
    public Chest() {
        super(200, 100, "Chest");
    }

    @Override
    public void drawShader() {
    }

    @Override
    public void predrawhud() {
    }

    @Override
    public void drawHUD(int xPos, int yPos, float partialTicks) {
        if (!(Chest.mc.thePlayer.openContainer instanceof ContainerChest)) {
            return;
        }
        ContainerChest container = (ContainerChest)Chest.mc.thePlayer.openContainer;
        this.setWidth(174);
        this.setHeight(80);
        float y = (float)yPos + 6.0f;
        ShaderElement.addBlurTask(() -> RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight(), new Color(0, 0, 0, 255).getRGB()));
        ShaderElement.addBloomTask(() -> RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight(), new Color(0, 0, 0, 255).getRGB()));
        RenderUtil.drawRectWH(xPos, yPos, this.getWidth(), 1.0, cc.xylitol.module.impl.render.HUD.color(1).getRGB());
        RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight(), new Color(0, 0, 0, 100).getRGB());
        FontManager.tenacitybold.drawString("Chest", (float)xPos + 6.0f, y, cc.xylitol.module.impl.render.HUD.color(1).getRGB());
        GlStateManager.pushMatrix();
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.enableDepth();
        for (int i1 = 0; i1 < container.inventorySlots.size() - 36; ++i1) {
            Slot slot = container.inventorySlots.get(i1);
            int i = slot.xDisplayPosition;
            int j = slot.yDisplayPosition;
            mc.getRenderItem().renderItemAndEffectIntoGUI(slot.getStack(), (int)((float)xPos + 2.0f + (float)i - 4.0f), (int)(y + (float)j) - 3);
            mc.getRenderItem().renderItemOverlayIntoGUI(Chest.mc.fontRendererObj, slot.getStack(), xPos + 2 + i - 3, (int)(y + (float)j) - 3, null);
        }
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableDepth();
        GlStateManager.popMatrix();
    }
}

