package cc.xylitol.ui.hud.impl;

import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.hud.HUD;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.shader.ShaderElement;
import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.inventory.Slot;

public class Inventory
extends HUD {
    public Inventory() {
        super(200, 100, "Inventory");
    }

    @Override
    public void drawShader() {
    }

    @Override
    public void predrawhud() {
    }

    @Override
    public void drawHUD(int xPos, int yPos, float partialTicks) {
        this.setWidth(174);
        this.setHeight(80);
        boolean hasStacks = false;
        GlStateManager.pushMatrix();
        float y = (float)yPos + 6.0f;
        ShaderElement.addBlurTask(() -> RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight(), new Color(0, 0, 0, 255).getRGB()));
        ShaderElement.addBloomTask(() -> RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight(), new Color(0, 0, 0, 255).getRGB()));
        RenderUtil.drawRectWH(xPos, yPos, this.getWidth(), 1.0, cc.xylitol.module.impl.render.HUD.color(1).getRGB());
        RenderUtil.drawRectWH(xPos, (float)yPos + 1.0f, this.getWidth(), this.getHeight(), new Color(0, 0, 0, 100).getRGB());
        FontManager.tenacitybold.drawStringDynamic("Inventory", (float)xPos + 6.0f, y, 1, 6);
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.enableDepth();
        for (int i1 = 9; i1 < Inventory.mc.thePlayer.inventoryContainer.inventorySlots.size() - 9; ++i1) {
            Slot slot = Inventory.mc.thePlayer.inventoryContainer.inventorySlots.get(i1);
            if (slot.getHasStack()) {
                hasStacks = true;
            }
            int i = slot.xDisplayPosition;
            int j = slot.yDisplayPosition;
            mc.getRenderItem().renderItemAndEffectIntoGUI(slot.getStack(), (int)((float)xPos + 2.0f + (float)i - 4.0f), (int)(y + (float)j - 70.0f));
            mc.getRenderItem().renderItemOverlayIntoGUI(Inventory.mc.fontRendererObj, slot.getStack(), xPos + 2 + i - 4, (int)(y + (float)j - 70.0f), null);
        }
        if (!hasStacks) {
            FontManager.font20.drawString("Empty", xPos + this.width / 2 - FontManager.font20.getStringWidth("Empty") / 2, y + (float)(this.height / 2) - 5.0f, Color.WHITE.getRGB());
        }
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableDepth();
        GlStateManager.popMatrix();
    }
}

