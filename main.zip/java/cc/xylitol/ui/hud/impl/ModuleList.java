package cc.xylitol.ui.hud.impl;

import cc.xylitol.Client;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.font.RapeMasterFontManager;
import cc.xylitol.ui.hud.HUD;
import cc.xylitol.utils.render.ColorUtil;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.animation.Animation;
import cc.xylitol.utils.render.animation.Direction;
import cc.xylitol.utils.render.shader.ShaderElement;
import cc.xylitol.value.impl.BoolValue;
import cc.xylitol.value.impl.ModeValue;
import cc.xylitol.value.impl.NumberValue;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.EnumChatFormatting;

import static java.lang.Long.compare;

public class ModuleList
extends HUD {
    public static final BoolValue importantModules = new BoolValue("Important", false);
    public static final BoolValue hLine = new BoolValue("HLine", true);
    public static final NumberValue height = new NumberValue("Height", 11.0, 9.0, 20.0, 1.0);
    public static final ModeValue animation = new ModeValue("Animation", new String[]{"MoveIn", "ScaleIn"}, "ScaleIn");
    public static final ModeValue fontSize = new ModeValue("Font Size", new String[]{"16", "18", "20", "22"}, "18");
    public static final BoolValue background = new BoolValue("Background", true);
    public static final NumberValue backgroundAlpha = new NumberValue("Background Alpha", 0.35, 0.01, 1.0, 0.01);
    public List<Module> modules;

    public ModuleList() {
        super(100, ModuleList.mc.fontRendererObj.FONT_HEIGHT + 10, "ArrayList");
    }

    @Override
    public void drawShader() {
    }

    @Override
    public void predrawhud() {
    }

    private String formatModule(Module module) {
        String name = module.getName();
        name = name.replaceAll(" ", "");
        String formatText = "%s %s%s";
        String suffix = module.getSuffix();
        if (suffix == null || suffix.isEmpty()) {
            return name;
        }
        return String.format(formatText, name, EnumChatFormatting.GRAY, suffix);
    }

    @Override
    public void drawHUD(int xPos, int yPos, float partialTicks) {
        ArrayList<Module> moduleList = new ArrayList<Module>();
        modules = getModules().stream().filter(Module::getState).collect(Collectors.toList());

        double yOffset = 0.0;
        ScaledResolution sr = new ScaledResolution(mc);
        int count = 0;

        for (Module module2 : this.modules) {
            if (importantModules.getValue() && module2.getCategory() == Category.Render) continue;
            Animation moduleAnimation = module2.getAnimation();
            moduleAnimation.setDirection(module2.getState() ? Direction.FORWARDS : Direction.BACKWARDS);
            if (!module2.getState() && moduleAnimation.finished(Direction.BACKWARDS)) continue;
            String displayText = this.formatModule(module2);
            double textWidth = FontManager.font22.getStringWidth(displayText);
            double xValue = sr.getScaledWidth() - 10;
            boolean flip = xValue <= (double)((float)sr.getScaledWidth() / 2.0f);
            double x = flip ? xValue : (double)sr.getScaledWidth() - (textWidth + 3.0);
            float alphaAnimation = 1.0f;
            double y = yOffset + 4.0;
            double heightVal = height.getValue() + 1.0;
            switch (((animation.getValue()))) {
                case "MoveIn": {
                    if (flip) {
                        x -= Math.abs((moduleAnimation.getOutput() - 1.0) * ((double)sr.getScaledWidth() - (2.0 - textWidth)));
                        break;
                    }
                    x += Math.abs((moduleAnimation.getOutput() - 1.0) * (2.0 + textWidth));
                    break;
                }
                case "ScaleIn": {
                    RenderUtil.scaleStart((float)(x + (double)((float)FontManager.font22.getStringWidth(displayText) / 2.0f)), (float)(y + heightVal / 2.0 - (double)((float)FontManager.font26.getHeight() / 2.0f)), (float)moduleAnimation.getOutput());
                    alphaAnimation = (float)moduleAnimation.getOutput();
                }
            }
            if (background.getValue().booleanValue()) {
                Gui.drawRect3((float)(x - 2.0), (float)(y - 3.0), this.getFont().getStringWidth(displayText) + 5, (float)heightVal, ColorUtil.applyOpacity(new Color(20, 20, 20), backgroundAlpha.getValue().floatValue() * alphaAnimation).getRGB());
                float finalAlphaAnimation = alphaAnimation;
                double finalX = x;
                ShaderElement.addBlurTask(() -> {
                    RenderUtil.scaleStart((float)(finalX + (double)((float)this.getFont().getStringWidth(displayText) / 2.0f)), (float)(y + heightVal / 2.0 - (double)((float)this.getFont().getHeight() / 2.0f)), (float)moduleAnimation.getOutput());
                    Gui.drawRect3((float)(finalX - 2.0), (float)(y - 3.0), this.getFont().getStringWidth(displayText) + 5, (float)heightVal, Color.BLACK.getRGB());
                    RenderUtil.scaleEnd();
                });
                ShaderElement.addBloomTask(() -> {
                    RenderUtil.scaleStart((float)(finalX + (double)((float)this.getFont().getStringWidth(displayText) / 2.0f)), (float)(y + heightVal / 2.0 - (double)((float)this.getFont().getHeight() / 2.0f)), (float)moduleAnimation.getOutput());
                    Gui.drawRect3((float)(finalX - 2.0), (float)(y - 3.0), this.getFont().getStringWidth(displayText) + 5, (float)heightVal, Color.BLACK.getRGB());
                    RenderUtil.scaleEnd();
                });
            }
            if (hLine.getValue().booleanValue()) {
                Gui.drawRect3((float)RenderUtil.width() - 1.0f, (float)(y - 3.0), 1.0, (float)heightVal, cc.xylitol.module.impl.render.HUD.color(count).getRGB());
            }
            int textcolor = cc.xylitol.module.impl.render.HUD.color(count).getRGB();
            this.getFont().drawStringWithShadow(displayText, (float)x, (float)(y - 1.0 + (double)this.getFont().getMiddleOfBox((float)heightVal)), ColorUtil.applyOpacity(textcolor, alphaAnimation));
            if (animation.getValue().equals("ScaleIn")) {
                RenderUtil.scaleEnd();
            }
            yOffset += moduleAnimation.getOutput() * heightVal;
            ++count;
        }
    }
    public List<Module> getModules() {
        Stream<Module> stream = Client.instance.moduleManager.getModuleMap().values().stream();

        stream = stream.sorted((mod1, mod2) -> compare(FontManager.font26.getStringWidth(formatModule(mod2)),
                FontManager.font26.getStringWidth(formatModule(mod1))));

        return stream.collect(Collectors.toList());
    }
    private RapeMasterFontManager getFont() {
        RapeMasterFontManager font = FontManager.font18;
        switch (fontSize.getValue()) {
            case "16": {
                font = FontManager.font16;
                break;
            }
            case "18": {
                font = FontManager.font18;
                break;
            }
            case "20": {
                font = FontManager.font20;
                break;
            }
            case "22": {
                font = FontManager.font22;
            }
        }
        return font;
    }
}

