package cc.xylitol.ui.hud.impl;

import cc.xylitol.Client;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.hud.HUD;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.shader.ShaderElement;
import java.awt.Color;
import net.minecraft.client.Minecraft;

public class Watermark
extends HUD {
    public Watermark() {
        super(50, 20, "Watermark");
    }

    @Override
    public void drawShader() {
    }

    @Override
    public void predrawhud() {
    }

    @Override
    public void drawHUD(int xPos, int yPos, float partialTicks) {
        String mark = "\u5143\u6cfdPro";
        String title = String.format("  |  %s  |  fps:%s  |  %s", Client.instance.user, Minecraft.getDebugFPS(), Client.version);
        float width = FontManager.font18.getStringWidth(title) + FontManager.font18.getStringWidth(mark) + 8;
        RenderUtil.drawRectWH(4.0, 4.0, width + 6.0f, 1.0, cc.xylitol.module.impl.render.HUD.color(1).getRGB());
        RenderUtil.drawRect(4.0, 5.0, width + 11.0f, FontManager.font20.getHeight() + 8, new Color(0, 0, 0, 100).getRGB());
        ShaderElement.addBlurTask(() -> RenderUtil.drawRect(4.0, 5.0, width + 11.0f, FontManager.font18.getHeight() + 8, new Color(0, 0, 0, 255).getRGB()));
        ShaderElement.addBloomTask(() -> RenderUtil.drawRect(4.0, 5.0, width + 11.0f, FontManager.font18.getHeight() + 8, new Color(0, 0, 0, 255).getRGB()));
        FontManager.font20.drawStringDynamic(mark, 9.0, 9.0, 1, 6);
        FontManager.font18.drawString(title, 13 + FontManager.font18.getStringWidth(mark), 9.5f, -1);
    }
}

