package cc.xylitol.ui.hud.notification;

import cc.xylitol.module.impl.render.HUD;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.hud.notification.NotificationManager;
import cc.xylitol.ui.hud.notification.NotificationType;
import cc.xylitol.utils.TimerUtil;
import cc.xylitol.utils.render.ColorUtil;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.animation.Animation;
import cc.xylitol.utils.render.animation.impl.DecelerateAnimation;
import java.awt.Color;
import net.minecraft.client.gui.Gui;

public class Notification {
    private final NotificationType notificationType;
    private final String title;
    private final String description;
    private final float time;
    private final TimerUtil timerUtil;
    private final Animation animation;
    public String icon;

    public Notification(NotificationType type, String title, String description) {
        this(type, title, description, NotificationManager.getToggleTime());
    }

    public Notification(NotificationType type, String title, String description, float time) {
        this.title = title;
        this.description = description;
        this.time = (long)(time * 1000.0f);
        this.timerUtil = new TimerUtil();
        this.notificationType = type;
        this.animation = new DecelerateAnimation(300, 1.0);
        switch (type) {
            case DISABLE: {
                this.icon = "B";
                break;
            }
            case SUCCESS: {
                this.icon = "A";
                break;
            }
            case INFO: {
                this.icon = "C";
                break;
            }
            case WARNING: {
                this.icon = "D";
            }
        }
    }

    public void drawLettuce(float x, float y, float width, float height) {
        Color color = ColorUtil.applyOpacity(ColorUtil.interpolateColorC(Color.BLACK, this.getNotificationType().getColor(), 0.65f), 70.0f);
        float percentage = Math.min((float)this.timerUtil.getTime() / this.getTime(), 1.0f);
        Gui.drawRect(x, y, x + width, y + height, new Color(0, 0, 0, 70).getRGB());
        Gui.drawRect(x, y, x + width * percentage, y + height, color.getRGB());
        Color notificationColor = ColorUtil.applyOpacity(this.getNotificationType().getColor(), 70.0f);
        Color textColor = ColorUtil.applyOpacity(Color.WHITE, 80.0f);
        FontManager.icontestFont35.drawString(this.getNotificationType().getIcon(), x + 3.0f, y + FontManager.icontestFont35.getMiddleOfBox(height), notificationColor.getRGB());
        FontManager.font20.drawString(this.getDescription(), x + 2.8f + (float)FontManager.icontestFont35.getStringWidth(this.getNotificationType().getIcon()) + 2.0f, y + 8.0f, textColor.getRGB());
    }

    public void drawXylitol(float x, float y, float width, float height) {
        Color notificationColor = ColorUtil.applyOpacity(this.getNotificationType().getColor(), 70.0f);
        float finalx = this.getNotificationType() == NotificationType.INFO ? x + 3.0f : x;
        RenderUtil.drawRound(x, y + height - 5.0f, x + width, height - 8.0f, 2.0f, true, new Color(243, 243, 243, 220), true, true, true, true);
        FontManager.icontestFont40.drawString(this.icon, finalx + 3.5f, y + height - 2.0f, notificationColor.getRGB());
        FontManager.font20.drawString(this.getTitle(), x + 20.0f, y + 30.0f, new Color(29, 160, 255).getRGB());
        FontManager.font16.drawString(this.getDescription(), x + 20.0f, y + 40.0f, -11514032);
    }

    public void drawSimple(float x, float y, float width, float height) {
        Color color = ColorUtil.applyOpacity(ColorUtil.interpolateColorC(Color.BLACK, this.getNotificationType().getColor(), 0.65f), 70.0f);
        float percentage = Math.min((float)this.timerUtil.getTime() / this.getTime(), 1.0f);
        Gui.drawRect(x, y, x + width, y + height, new Color(0, 0, 0, 70).getRGB());
        Gui.drawRect(x, y, x + 1.0f, y + height, color.brighter().getRGB());
        Gui.drawRect(x, y, x + width * percentage, y + height, RenderUtil.reAlpha(color.brighter(), 50).getRGB());
        Color textColor = ColorUtil.applyOpacity(Color.WHITE, 80.0f);
        FontManager.font20.drawString(this.getDescription(), x + 6.0f, y + 8.0f, textColor.getRGB());
    }

    public void blurXylitol(float x, float y, float width, float height, boolean glow) {
        Color color = ColorUtil.applyOpacity(ColorUtil.interpolateColorC(Color.BLACK, this.getNotificationType().getColor(), glow ? 0.65f : 0.0f), 70.0f);
        float percentage = Math.min((float)this.timerUtil.getTime() / this.getTime(), 1.0f);
        Gui.drawRect(x, y, x + width, y + height, Color.BLACK.getRGB());
        Gui.drawRect(x, y, x + 1.0f, y + height, HUD.color(1).getRGB());
        Gui.drawRect(x, y, x + width * percentage, y + height, color.getRGB());
        RenderUtil.resetColor();
    }

    public NotificationType getNotificationType() {
        return this.notificationType;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public float getTime() {
        return this.time;
    }

    public TimerUtil getTimerUtil() {
        return this.timerUtil;
    }

    public Animation getAnimation() {
        return this.animation;
    }

    public String getIcon() {
        return this.icon;
    }
}

