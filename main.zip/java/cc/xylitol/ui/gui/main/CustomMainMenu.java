package cc.xylitol.ui.gui.main;

import cc.xylitol.Client;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.gui.alt.GuiAltManager;
import cc.xylitol.ui.gui.main.CustomMenuButton;
import cc.xylitol.utils.render.RoundedUtil;
import cc.xylitol.utils.render.animation.Animation;
import cc.xylitol.utils.render.animation.Direction;
import cc.xylitol.utils.render.animation.impl.DecelerateAnimation;
import cc.xylitol.utils.render.animation.impl.LayeringAnimation;
import java.awt.Color;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;

public class CustomMainMenu
extends GuiScreen {
    private final float trainX;
    private final Animation displayAnimation;
    private final List<CustomMenuButton> buttons;

    public CustomMainMenu() {
        this.trainX = -this.width;
        this.displayAnimation = new DecelerateAnimation(1000, 1.0);
        this.buttons = Arrays.asList(new CustomMenuButton("Single"), new CustomMenuButton("Multi"), new CustomMenuButton("Alt"), new CustomMenuButton("Option"), new CustomMenuButton("Exit"));
    }

    @Override
    public void initGui() {
        this.displayAnimation.setDirection(Direction.FORWARDS);
        this.buttons.forEach(CustomMenuButton::initGui);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        Client.instance.wallpaperEngine.render(this.width, this.height);
        float buttonWidth = 50.0f;
        float buttonHeight = 25.0f;
        float totalButtonWidth = buttonWidth * 5.0f + 20.0f;
        int count = 0;
        FontManager.font40.drawString("Xylitol Menu.", (float)(this.width / 2) - totalButtonWidth / 2.0f - 5.0f, (float)this.height / 2.0f - buttonHeight / 2.0f - 60.0f, new Color(255, 255, 255, (int)(255.0 * this.displayAnimation.getOutput())).getRGB());
        RoundedUtil.drawRound((float)(this.width / 2) - totalButtonWidth / 2.0f - 5.0f, (float)this.height / 2.0f - buttonHeight / 2.0f - 30.0f, 280.0f, buttonHeight + 10.0f, 6.0f, new Color(32, 32, 32, (int)(200.0 * this.displayAnimation.getOutput())));
        for (CustomMenuButton button : this.buttons) {
            button.x = (float)(this.width / 2) - totalButtonWidth / 2.0f + (float)count;
            button.y = (float)this.height / 2.0f - buttonHeight / 2.0f - 25.0f;
            button.width = buttonWidth;
            button.height = buttonHeight;
            button.clickAction = () -> {
                switch (button.text) {
                    case "Single": {
                        LayeringAnimation.play(new GuiSelectWorld(this));
                        break;
                    }
                    case "Multi": {
                        LayeringAnimation.play(new GuiMultiplayer(this));
                        break;
                    }
                    case "Option": {
                        LayeringAnimation.play(new GuiOptions(this, this.mc.gameSettings));
                        break;
                    }
                    case "Alt": {
                        LayeringAnimation.play(new GuiAltManager(this));
                        break;
                    }
                    case "Exit": {
                        this.mc.shutdown();
                    }
                }
            };
            button.drawScreen(mouseX, mouseY, partialTicks);
            count = (int)((float)count + (buttonWidth + 5.0f));
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void onGuiClosed() {
        this.displayAnimation.setDirection(Direction.BACKWARDS);
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == -1) {
            this.mc.displayGuiScreen(null);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        this.buttons.forEach(button -> button.mouseClicked(mouseX, mouseY, mouseButton));
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }
}

