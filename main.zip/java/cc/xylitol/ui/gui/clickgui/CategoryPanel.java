package cc.xylitol.ui.gui.clickgui;

import cc.xylitol.Client;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.gui.clickgui.ModuleRender;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.RoundedUtil;
import cc.xylitol.utils.render.animation.AnimationUtils;
import cc.xylitol.utils.render.animation.impl.EaseBackIn;
import cc.xylitol.utils.render.animation.impl.OutputAnimation;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;
import org.lwjglx.input.Mouse;

public class CategoryPanel {
    private final Category category;
    private final OutputAnimation animation = new OutputAnimation(0);
    ArrayList<ModuleRender> moduleRenders;
    int width;
    int height;
    int moduley;
    int roundindexy;
    int xPosition;
    int yPosition;
    int animateTarget = 0;
    int alphaTarget = 0;
    int nowAlpha = 0;
    int scroll = 0;
    int targetScroll = 0;
    private boolean extended = false;

    public CategoryPanel(Category category) {
        this.category = category;
        this.moduleRenders = new ArrayList();
        for (Module m : Client.instance.moduleManager.getModsByCategory(category).stream().sorted(Comparator.comparing(Module::getName)).collect(Collectors.toList())) {
            this.moduleRenders.add(new ModuleRender(m));
        }
    }

    public void setExtended(boolean value) {
        this.extended = value;
        if (this.extended) {
            this.animateTarget = 200;
            this.alphaTarget = 255;
        } else {
            this.animateTarget = 0;
            this.alphaTarget = 0;
        }
    }

    public void drawscreen(int mousex, int mousey, int x, int y, int alpha, EaseBackIn easeBackIn) {
        int wheel;
        this.width = 100;
        this.height = 20;
        this.moduley = 0;
        this.roundindexy = 0;
        this.xPosition = x;
        this.yPosition = y;
        for (ModuleRender moduleRender : this.moduleRenders) {
            this.roundindexy += FontManager.font18.getHeight() + 7;
            if (!moduleRender.cansetvalue) continue;
            this.roundindexy += moduleRender.index;
        }
        this.animation.animate(this.animateTarget, 0.2f);
        RoundedUtil.drawRound(x, y, this.width, this.height + (int)this.animation.getOutput(), 3.0f, new Color(0, 0, 0, alpha));
        FontManager.font20.drawString(this.category.name(), x + this.width / 2 - FontManager.font20.getStringWidth(this.category.name()) / 2, y + this.height / 2 - FontManager.font20.getHeight() / 2, -1);
        this.nowAlpha = (int)AnimationUtils.animate(this.alphaTarget, this.nowAlpha, 0.1);
        RenderUtil.drawRect(x + 5, y + 19, x + this.width - 5, y + 20, new Color(255, 255, 255, this.nowAlpha).getRGB());
        if (mousex >= x && mousex <= x + this.width && mousey >= y && (double)mousey <= (double)(y + this.height) + this.animation.getOutput() && (wheel = Mouse.getDWheel()) != 0) {
            this.targetScroll = wheel > 0 ? (this.targetScroll += 15) : (this.targetScroll -= 15);
            if (this.targetScroll > 0) {
                this.targetScroll = 0;
            }
        }
        this.scroll = (int)AnimationUtils.animate(this.targetScroll, this.scroll, 0.9);
        RenderUtil.startGlScissor(x, y + 20, this.width, (int)((double)this.height + this.animation.getOutput()) - 20);
        for (ModuleRender moduleRender : this.moduleRenders) {
            moduleRender.settinganimation.animate(this.moduley, 20);
            moduleRender.draw(mousex, mousey, x, y + this.scroll, (int)moduleRender.settinganimation.getOutput());
            this.moduley += FontManager.font18.getHeight() + 7;
            if (!moduleRender.cansetvalue) continue;
            this.moduley += moduleRender.index;
        }
        RenderUtil.stopGlScissor();
    }

    public void drawshader(int x, int y) {
        RoundedUtil.drawRound(x, y, this.width, this.height + (int)this.animation.getOutput(), 3.0f, new Color(0, 0, 0, 255));
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseX >= this.xPosition && mouseX <= this.xPosition + this.width && mouseY >= this.yPosition + 20 && (double)mouseY <= (double)(this.yPosition + this.height) + this.animation.getOutput() - 3.0) {
            for (ModuleRender moduleRender : this.moduleRenders) {
                moduleRender.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }
        if (mouseX >= this.xPosition && mouseX <= this.xPosition + this.width && mouseY >= this.yPosition && mouseY <= this.yPosition + 20 && mouseButton == 1) {
            this.setExtended(!this.extended);
        }
    }

    public void keyTyped(int keyCode) {
        for (ModuleRender moduleRender : this.moduleRenders) {
            moduleRender.keyTyped(keyCode);
        }
    }
}

