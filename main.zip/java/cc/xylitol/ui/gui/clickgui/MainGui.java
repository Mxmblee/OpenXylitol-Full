package cc.xylitol.ui.gui.clickgui;

import cc.xylitol.Client;
import cc.xylitol.module.Category;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.gui.clickgui.CategoryPanel;
import cc.xylitol.utils.TimerUtil;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.animation.Direction;
import cc.xylitol.utils.render.animation.impl.EaseBackIn;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjglx.input.Keyboard;

public class MainGui
extends GuiScreen {
    private final EaseBackIn easeBackIn = new EaseBackIn(500, 1.0, 1.5f);
    private final TimerUtil timer = new TimerUtil();
    private final TimerUtil startTimer = new TimerUtil();
    private final boolean got = false;
    public int indexx;
    public int indexy;
    ArrayList<CategoryPanel> categoryPanels = new ArrayList();
    private int openIndex = 0;
    private boolean shouldDo = true;
    private boolean shouldClose = false;

    public MainGui() {
        for (Category category : Category.values()) {
            this.categoryPanels.add(new CategoryPanel(category));
        }
        this.easeBackIn.setDirection(Direction.BACKWARDS);
    }

    @Override
    public void initGui() {
        this.easeBackIn.setDirection(Direction.FORWARDS);
        this.timer.reset();
        this.startTimer.reset();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (this.easeBackIn.finished(Direction.BACKWARDS)) {
            Minecraft.getMinecraft().displayGuiScreen(null);
            return;
        }
        this.indexy = 40;
        this.indexx = 110;
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        if (this.shouldClose && this.startTimer.hasTimeElapsed((long)this.categoryPanels.size() * 50L)) {
            this.easeBackIn.setDirection(Direction.BACKWARDS);
        }
        if (!this.shouldClose || this.startTimer.hasTimeElapsed((long)this.categoryPanels.size() * 50L)) {
            RenderUtil.scaleStart((float)sr.getScaledWidth() / 2.0f, (float)sr.getScaledHeight() / 2.0f, (float)this.easeBackIn.getOutput());
        }
        for (CategoryPanel categoryPanel : this.categoryPanels) {
            categoryPanel.drawscreen(mouseX, mouseY, this.indexx, this.indexy, (int)(120.0 * this.easeBackIn.getOutput()), this.easeBackIn);
            this.indexx += 110;
        }
        if (!this.shouldClose || this.startTimer.hasTimeElapsed((long)this.categoryPanels.size() * 50L)) {
            RenderUtil.scaleEnd();
        }
        if (this.startTimer.hasTimeElapsed(500L) && this.shouldDo && this.timer.hasTimeElapsed(100L)) {
            this.categoryPanels.get(this.openIndex).setExtended(true);
            ++this.openIndex;
            if (this.openIndex == this.categoryPanels.size()) {
                this.openIndex = this.categoryPanels.size() - 1;
                this.shouldDo = false;
            }
            this.timer.reset();
        }
        if (this.shouldClose && this.timer.hasTimeElapsed(50L)) {
            this.categoryPanels.get(this.openIndex).setExtended(false);
            --this.openIndex;
            if (this.openIndex == -1) {
                this.openIndex = 0;
                this.shouldClose = false;
            }
            this.timer.reset();
        }
        String text = "\u6309\u4e0bCtrl + \u60f3\u8981\u7ed1\u5b9a\u7684\u952e\u4f4d\u6765\u7ed1\u5b9a\u6309\u952e,\u6309\u4e0bDelete\u6765\u5220\u9664\u952e\u4f4d";
        FontManager.font20.drawString(text, sr.getScaledWidth() / 2 - FontManager.font20.getStringWidth(text) / 2, sr.getScaledHeight() - FontManager.font20.getHeight() - 40, -1);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        for (CategoryPanel categoryPanel : this.categoryPanels) {
            categoryPanel.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            Client.instance.configManager.saveAllConfig();
            this.timer.reset();
            this.shouldClose = true;
            this.startTimer.reset();
        }
        for (CategoryPanel categoryPanel : this.categoryPanels) {
            categoryPanel.keyTyped(keyCode);
        }
    }

    @Override
    public void onGuiClosed() {
        Client.instance.configManager.saveAllConfig();
    }
}

