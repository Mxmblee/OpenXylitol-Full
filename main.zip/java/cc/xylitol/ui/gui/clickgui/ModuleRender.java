package cc.xylitol.ui.gui.clickgui;

import cc.xylitol.module.Module;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.utils.TimerUtil;
import cc.xylitol.utils.render.ColorUtil;
import cc.xylitol.utils.render.HSBData;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.RoundedUtil;
import cc.xylitol.utils.render.animation.AnimationUtils;
import cc.xylitol.utils.render.animation.Direction;
import cc.xylitol.utils.render.animation.impl.ContinualAnimation;
import cc.xylitol.utils.render.animation.impl.EaseBackIn;
import cc.xylitol.value.Value;
import cc.xylitol.value.impl.BoolValue;
import cc.xylitol.value.impl.ColorValue;
import cc.xylitol.value.impl.ModeValue;
import cc.xylitol.value.impl.NumberValue;
import java.awt.Color;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Arrays;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjglx.input.Mouse;

public class ModuleRender {
    public final Module m;
    final ContinualAnimation settinganimation = new ContinualAnimation();
    private final EaseBackIn hoveranimation = new EaseBackIn(200, 0.3f, 2.0f);
    public int index;
    int color;
    TimerUtil valuetimer = new TimerUtil();
    boolean cansetvalue = false;
    private int height;
    private boolean hover;
    private boolean canbind;
    private int targetAlpha = 0;
    private int nowAlpha = 0;
    private boolean openedcp;

    public ModuleRender(Module module) {
        this.m = module;
    }

    public static double round(double value, double inc) {
        if (inc == 0.0) {
            return value;
        }
        if (inc == 1.0) {
            return Math.round(value);
        }
        double halfOfInc = inc / 2.0;
        double floored = Math.floor(value / inc) * inc;
        if (value >= floored + halfOfInc) {
            return new BigDecimal(Math.ceil(value / inc) * inc).doubleValue();
        }
        return new BigDecimal(floored).doubleValue();
    }

    public void draw(int mouseX, int mouseY, int x, int y, int moduley) {
        this.height = 20;
        this.color = this.m.getState() ? Color.PINK.getRGB() : -1;
        this.hover = RenderUtil.isHovering(
                (float)(x + 5),
                (float)(y + this.height / 2 - FontManager.font18.getHeight() / 2 + 20 + moduley),
                (float)FontManager.font18.getStringWidth(this.m.name),
                (float)FontManager.font18.getHeight(),
                mouseX,
                mouseY
        );
        if (this.hover) {
            this.hoveranimation.setDirection(Direction.FORWARDS);
            this.canbind = true;
            this.targetAlpha = 255;
        } else {
            this.hoveranimation.setDirection(Direction.BACKWARDS);
            this.canbind = false;
            this.targetAlpha = 100;
        }

        if (this.cansetvalue) {
            this.targetAlpha = 255;
        }

        FontManager.font18
                .drawString(
                        this.m.name,
                        (float)((double)x + 5.0 * (1.0 + this.hoveranimation.getOutput())),
                        (float)(y + this.height / 2 - FontManager.font18.getHeight() / 2 + 20 + moduley),
                        this.color
                );
        this.nowAlpha = (int)AnimationUtils.animate(this.targetAlpha, this.nowAlpha, 0.1);
        RoundedUtil.drawRound(
                x + 90, y + this.height / 2 - FontManager.font18.getHeight() / 2 + 20 + moduley, 5, 5, 4.0F, new Color(255, 255, 255, this.nowAlpha)
        );
        if (this.cansetvalue) {
            this.index = 0;
            int numberindex = 0;
            int addition = 0;
            RoundedUtil.drawRound(
                    x,
                    y + this.height / 2 - FontManager.font18.getHeight() / 2 + 20 + moduley + FontManager.font18.getHeight(),
                    100,
                    this.index,
                    0.0F,
                    new Color(0, 0, 0, 100)
            );

            for(Value value : this.m.getValues()) {
                if (value instanceof NumberValue) {
                    DecimalFormat df = new DecimalFormat("#.#");
                    double d = Double.parseDouble(
                            df.format(
                                    (((Number)value.getValue()).doubleValue() - ((NumberValue)value).getMin())
                                            / (((NumberValue)value).getMax() - ((NumberValue)value).getMin())
                            )
                    );
                    double present = 80.0 * d;
                    value.numberAnim.animate(present, 0.1F);
                    FontManager.font14
                            .drawString(
                                    value.getName() + " " + value.getValue(),
                                    (float)(x + 10),
                                    (float)(
                                            y
                                                    + this.height / 2
                                                    - FontManager.font14.getHeight() / 2
                                                    + 20
                                                    + moduley
                                                    + FontManager.font14.getHeight()
                                                    + 8
                                                    + numberindex * 15
                                                    + addition
                                                    - FontManager.font14.getHeight()
                                                    + 8
                                    ),
                                    -1
                            );
                    RoundedUtil.drawRound(
                            (float)(x + 10),
                            (float)(
                                    y
                                            + this.height / 2
                                            - FontManager.font18.getHeight() / 2
                                            + 20
                                            + moduley
                                            + FontManager.font18.getHeight()
                                            + 8
                                            + numberindex * 15
                                            + addition
                                            + 10
                            ),
                            80.0F,
                            3.0F,
                            1.0F,
                            new Color(0, 0, 0, 130)
                    );
                    RoundedUtil.drawRound(
                            (float)(x + 10),
                            (float)(
                                    y
                                            + this.height / 2
                                            - FontManager.font18.getHeight() / 2
                                            + 20
                                            + moduley
                                            + FontManager.font18.getHeight()
                                            + 8
                                            + numberindex * 15
                                            + addition
                                            + 10
                            ),
                            (float)((int)value.numberAnim.getOutput()),
                            3.0F,
                            1.0F,
                            Color.PINK
                    );
                    if (RenderUtil.isHovering(
                            (float)(x + 10),
                            (float)(
                                    y
                                            + this.height / 2
                                            - FontManager.font18.getHeight() / 2
                                            + 20
                                            + moduley
                                            + FontManager.font18.getHeight()
                                            + 8
                                            + numberindex * 15
                                            + addition
                                            + 5
                            ),
                            80.0F,
                            9.0F,
                            mouseX,
                            mouseY
                    )
                            && Mouse.isButtonDown(0)) {
                        double num = Math.max(
                                ((NumberValue)value).getMin(),
                                Math.min(
                                        ((NumberValue)value).getMax(),
                                        round(
                                                (double)(mouseX - (x + 10)) * (((NumberValue)value).getMax() - ((NumberValue)value).getMin()) / 80.0
                                                        + ((NumberValue)value).getMin(),
                                                ((NumberValue)value).getInc()
                                        )
                                )
                        );
                        num = (double)Math.round(num * (1.0 / ((NumberValue)value).getInc())) / (1.0 / ((NumberValue)value).getInc());
                        value.setValue(num);
                    }

                    ++numberindex;
                    addition += 10;
                }

                this.index += 16;
                if (value instanceof BoolValue) {
                    boolean hover = RenderUtil.isHovering(
                            (float)(x + 5),
                            (float)(
                                    y
                                            + this.height / 2
                                            - FontManager.font14.getHeight() / 2
                                            + 20
                                            + moduley
                                            + FontManager.font14.getHeight()
                                            + 8
                                            + numberindex * 15
                                            + addition
                                            - FontManager.font14.getHeight()
                                            + 8
                            ),
                            100.0F,
                            5.0F,
                            mouseX,
                            mouseY
                    );
                    FontManager.font14
                            .drawString(
                                    value.getName(),
                                    (float)(x + 10),
                                    (float)(
                                            y
                                                    + this.height / 2
                                                    - FontManager.font14.getHeight() / 2
                                                    + 20
                                                    + moduley
                                                    + FontManager.font14.getHeight()
                                                    + 8
                                                    + numberindex * 15
                                                    + addition
                                                    - FontManager.font14.getHeight()
                                                    + 8
                                    ),
                                    -1
                            );
                    if (hover && Mouse.isButtonDown(0) && this.valuetimer.hasTimeElapsed(300L)) {
                        value.setValue(!(Boolean)value.getValue());
                        this.valuetimer.reset();
                    }

                    if (hover) {
                        value.easeBackIn.setDirection(Direction.FORWARDS);
                    } else {
                        value.easeBackIn.setDirection(Direction.BACKWARDS);
                    }

                    RoundedUtil.drawRound(
                            (float)((double)(x + FontManager.font14.getStringWidth(value.getName())) + 15.0 * (1.0 + value.easeBackIn.getOutput())),
                            (float)(
                                    y
                                            + this.height / 2
                                            - FontManager.font14.getHeight() / 2
                                            + 20
                                            + moduley
                                            + FontManager.font14.getHeight()
                                            + 8
                                            + numberindex * 15
                                            + addition
                                            - FontManager.font14.getHeight()
                                            + 8
                            ),
                            5.0F,
                            5.0F,
                            1.0F,
                            new Color(255, 170, 178, 130)
                    );
                    if ((Boolean) value.getValue()) {
                        value.decelerateAnimation.setDirection(Direction.FORWARDS);
                    } else {
                        value.decelerateAnimation.setDirection(Direction.BACKWARDS);
                    }

                    if ((Boolean)value.getValue()) {
                        FontManager.other14
                                .drawString(
                                        "v",
                                        (float)((double)(x + FontManager.font14.getStringWidth(value.getName())) + 14.0 * (1.0 + value.easeBackIn.getOutput())),
                                        (float)(
                                                y
                                                        + this.height / 2
                                                        - FontManager.other14.getHeight() / 2
                                                        + 20
                                                        + moduley
                                                        + FontManager.other14.getHeight()
                                                        + 8
                                                        + numberindex * 15
                                                        + addition
                                                        - FontManager.other14.getHeight()
                                                        + 8
                                        ),
                                        ColorUtil.applyOpacity(new Color(-1), (float)value.decelerateAnimation.getOutput()).getRGB()
                                );
                    }

                    ++numberindex;
                }

                if (value instanceof ModeValue) {
                    ModeValue modeValue = (ModeValue)value;
                    FontManager.font14
                            .drawString(
                                    value.getName(),
                                    (float)(x + 10),
                                    (float)(
                                            y
                                                    + this.height / 2
                                                    - FontManager.font14.getHeight() / 2
                                                    + 24
                                                    + moduley
                                                    + FontManager.font14.getHeight()
                                                    + 8
                                                    + numberindex * 15
                                                    + addition
                                                    - FontManager.font14.getHeight()
                                    ),
                                    -1
                            );
                    RoundedUtil.drawRound(
                            (float)(x + 10),
                            (float)(
                                    y
                                            + this.height / 2
                                            - FontManager.font14.getHeight() / 2
                                            + 20
                                            + moduley
                                            + FontManager.font14.getHeight()
                                            + 14
                                            + numberindex * 15
                                            + addition
                            ),
                            80.0F,
                            8.0F,
                            3.0F,
                            new Color(255, 170, 178, 130)
                    );
                    GlStateManager.resetColor();
                    if (RenderUtil.isHovering(
                            (float)(x + 10),
                            (float)(
                                    y
                                            + this.height / 2
                                            - FontManager.font14.getHeight() / 2
                                            + 20
                                            + moduley
                                            + FontManager.font14.getHeight()
                                            + 14
                                            + numberindex * 15
                                            + addition
                            ),
                            80.0F,
                            8.0F,
                            mouseX,
                            mouseY
                    )
                            && Mouse.isButtonDown(0)
                            && this.valuetimer.hasTimeElapsed(200L)) {
                        if (Arrays.asList(modeValue.getModes()).indexOf(modeValue.getValue()) < modeValue.getModes().length - 1) {
                            value.setValue(modeValue.getModes()[Arrays.asList(modeValue.getModes()).indexOf(value.getValue()) + 1]);
                        } else {
                            value.setValue(modeValue.getModes()[0]);
                        }

                        this.valuetimer.reset();
                    }

                    FontManager.font14
                            .drawString(
                                    ((ModeValue)value).getModeAsString(),
                                    (float)(x + 10 + 40 - FontManager.font16.getStringWidth(((ModeValue)value).getModeAsString()) / 2),
                                    (float)(
                                            y
                                                    + this.height / 2
                                                    - FontManager.font18.getHeight() / 2
                                                    + 20
                                                    + moduley
                                                    + FontManager.font18.getHeight()
                                                    + 12
                                                    + numberindex * 15
                                                    + addition
                                    )
                                            + 6.0F
                                            - (float)(FontManager.font16.getHeight() / 2)
                                            + 2.0F,
                                    -1
                            );
                    ++numberindex;
                    addition += 6;
                }

                if (value instanceof ColorValue) {
                    boolean hover = RenderUtil.isHovering(
                            (float)(x + 10),
                            (float)(
                                    y
                                            + this.height / 2
                                            - FontManager.font14.getHeight() / 2
                                            + 20
                                            + moduley
                                            + FontManager.font14.getHeight()
                                            + 14
                                            + numberindex * 15
                                            + addition
                            ),
                            11.0F,
                            11.0F,
                            mouseX,
                            mouseY
                    );
                    ColorValue setting = (ColorValue)value;
                    Color valColor = setting.getColorC();
                    HSBData data = new HSBData(valColor);
                    float[] hsba = new float[]{data.getHue(), data.getSaturation(), data.getBrightness(), (float)setting.getColorC().getAlpha()};
                    RoundedUtil.drawRound(
                            x + 10,
                            y
                                    + this.height / 2
                                    - FontManager.font14.getHeight() / 2
                                    + 20
                                    + moduley
                                    + FontManager.font14.getHeight()
                                    + 14
                                    + numberindex * 15
                                    + addition,
                            11,
                            11,
                            3.0F,
                            setting.getColorC()
                    );
                    FontManager.font14
                            .drawString(
                                    setting.getName(),
                                    (float)(x + 10),
                                    (float)(
                                            y
                                                    + this.height / 2
                                                    - FontManager.font14.getHeight() / 2
                                                    + 24
                                                    + moduley
                                                    + FontManager.font14.getHeight()
                                                    + 8
                                                    + numberindex * 15
                                                    + addition
                                                    - FontManager.font14.getHeight()
                                    ),
                                    -1,
                                    false
                            );
                    if (hover && Mouse.isButtonDown(0) && this.valuetimer.hasTimeElapsed(300L)) {
                        this.openedcp = !this.openedcp;
                        this.valuetimer.reset();
                    }

                    if (this.openedcp) {
                        GlStateManager.pushMatrix();
                        GlStateManager.translate(
                                6.0F,
                                (float)(
                                        this.height / 2
                                                - FontManager.font14.getHeight() / 2
                                                + 20
                                                + moduley
                                                + FontManager.font14.getHeight()
                                                + 14
                                                + numberindex * 15
                                                + addition
                                ),
                                6.0F
                        );
                        Gui.drawRect3(x + 10 + 3, (float)y + 8.5F + 3.0F, 61.0, 61.0, new Color(0, 0, 0).getRGB());
                        Gui.drawRect3(
                                x + 10, (double)((float)y + 8.5F) + 3.5, 60.0, 60.0, this.getColor(Color.getHSBColor(hsba[0], 1.0F, 1.0F)).getRGB()
                        );
                        RenderUtil.drawHorizontalGradientSideways(
                                x + 10, (double)((float)y + 8.5F) + 3.5, 60.0, 60.0, this.getColor(Color.getHSBColor(hsba[0], 0.0F, 1.0F)).getRGB(), 15
                        );
                        RenderUtil.drawVerticalGradientSideways(
                                x + 10, (double)((float)y + 8.5F) + 3.5, 60.0, 60.0, 15, this.getColor(Color.getHSBColor(hsba[0], 1.0F, 0.0F)).getRGB()
                        );
                        Gui.drawRect3(
                                (double)((float)(x + 10) + hsba[1] * 60.0F) - 0.5,
                                (double)((float)y + 8.5F) + 3.5 + (double)((1.0F - hsba[2]) * 60.0F) - 0.5,
                                1.5,
                                1.5,
                                new Color(0, 0, 0).getRGB()
                        );
                        Gui.drawRect3(
                                (float)(x + 10) + hsba[1] * 60.0F,
                                (double)((float)y + 8.5F) + 3.5 + (double)((1.0F - hsba[2]) * 60.0F),
                                0.5,
                                0.5,
                                this.getColor(valColor).getRGB()
                        );
                        boolean onSB = RenderUtil.isHovering(
                                (float)(x + 13),
                                (float)y + 8.5F + 3.0F,
                                61.0F,
                                61.0F,
                                mouseX,
                                mouseY
                                        - (
                                        this.height / 2
                                                - FontManager.font14.getHeight() / 2
                                                + 20
                                                + moduley
                                                + FontManager.font14.getHeight()
                                                + 14
                                                + numberindex * 15
                                                + addition
                                )
                        );
                        if (onSB && Mouse.isButtonDown(0)) {
                            data.setSaturation(Math.min(Math.max((float)(mouseX - (x + 13) - 3) / 60.0F, 0.0F), 1.0F));
                            data.setBrightness(
                                    1.0F
                                            - Math.min(
                                            Math.max(
                                                    (
                                                            (float)(
                                                                    mouseY
                                                                            - (
                                                                            this.height / 2
                                                                                    - FontManager.font14.getHeight() / 2
                                                                                    + 20
                                                                                    + moduley
                                                                                    + FontManager.font14.getHeight()
                                                                                    + 14
                                                                                    + numberindex * 15
                                                                                    + addition
                                                                    )
                                                                            - y
                                                            )
                                                                    + 8.5F
                                                                    - 3.0F
                                                                    - 16.0F
                                                    )
                                                            / 60.0F,
                                                    0.0F
                                            ),
                                            1.0F
                                    )
                            );
                            setting.setColor(data.getAsColor().getRGB());
                        }

                        Gui.drawRect3(x + 10 + 67, (float)y + 8.5F + 3.0F, 10.0, 61.0, new Color(0, 0, 0).getRGB());

                        for(float f = 0.0F; f < 5.0F; ++f) {
                            Color lasCol = Color.getHSBColor(f / 5.0F, 1.0F, 1.0F);
                            Color tarCol = Color.getHSBColor(Math.min(f + 1.0F, 5.0F) / 5.0F, 1.0F, 1.0F);
                            RenderUtil.drawVerticalGradientSideways(
                                    (double)(x + 10) + 67.5,
                                    (double)((float)y + 8.5F) + 3.5 + (double)(f * 12.0F),
                                    9.0,
                                    12.0,
                                    this.getColor(lasCol).getRGB(),
                                    this.getColor(tarCol).getRGB()
                            );
                        }

                        Gui.drawRect3((double)(x + 10) + 67.5, (float)y + 8.5F + 2.0F + hsba[0] * 60.0F, 9.0, 2.0, new Color(0, 0, 0).getRGB());
                        Gui.drawRect3(
                                (double)(x + 10) + 67.5, (double)((float)y + 8.5F) + 2.5 + (double)(hsba[0] * 60.0F), 9.0, 1.0, new Color(204, 198, 255).getRGB()
                        );
                        boolean onHue = RenderUtil.isHovering(
                                (float)(x + 10 + 67),
                                (float)y + 8.5F + 3.0F,
                                10.0F,
                                61.0F,
                                mouseX - 6,
                                mouseY
                                        - (
                                        this.height / 2
                                                - FontManager.font14.getHeight() / 2
                                                + 20
                                                + moduley
                                                + FontManager.font14.getHeight()
                                                + 14
                                                + numberindex * 15
                                                + addition
                                )
                        );
                        if (onHue && Mouse.isButtonDown(0)) {
                            data.setHue(
                                    Math.min(
                                            Math.max(
                                                    (
                                                            (float)(
                                                                    mouseY
                                                                            - (
                                                                            this.height / 2
                                                                                    - FontManager.font14.getHeight() / 2
                                                                                    + 20
                                                                                    + moduley
                                                                                    + FontManager.font14.getHeight()
                                                                                    + 14
                                                                                    + numberindex * 15
                                                                                    + addition
                                                                    )
                                                                            - y
                                                            )
                                                                    + 8.5F
                                                                    - 3.0F
                                                                    - 16.0F
                                                    )
                                                            / 60.0F,
                                                    0.0F
                                            ),
                                            1.0F
                                    )
                            );
                            setting.setColor(data.getAsColor().getRGB());
                        }

                        GlStateManager.popMatrix();
                    }

                    ++numberindex;
                    addition += 12;
                }
            }

            this.index += addition;
        } else {
            for(Value<?> value : this.m.getValues()) {
                if (value instanceof NumberValue) {
                    value.numberAnim.setNow(0);
                }
            }
        }
    }

    private Color getColor(Color color) {
        return RenderUtil.reAlpha(color, (int)((float) color.getAlpha()));
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (this.hover && mouseButton == 0) {
            this.m.toggle();
        }
        if (this.hover && mouseButton == 1 && this.m.getValues().size() > 0) {
            this.cansetvalue = !this.cansetvalue;
        }
    }

    public void keyTyped(int keyCode) {
    }
}

