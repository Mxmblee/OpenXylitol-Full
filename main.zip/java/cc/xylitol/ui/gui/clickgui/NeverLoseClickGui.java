package cc.xylitol.ui.gui.clickgui;

import cc.xylitol.Client;
import cc.xylitol.config.ConfigManager;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.module.impl.render.HUD;
import cc.xylitol.ui.font.FontManager;
import cc.xylitol.ui.font.RapeMasterFontManager;
import cc.xylitol.ui.gui.clickgui.InputField;
import cc.xylitol.ui.hud.notification.NotificationManager;
import cc.xylitol.ui.hud.notification.NotificationType;
import cc.xylitol.utils.render.GradientUtil;
import cc.xylitol.utils.render.HSBData;
import cc.xylitol.utils.render.MaskUtil;
import cc.xylitol.utils.render.Rectangle;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.RoundedUtil;
import cc.xylitol.utils.render.StencilUtil;
import cc.xylitol.utils.render.animation.AnimationUtils;
import cc.xylitol.utils.render.shader.ShaderElement;
import cc.xylitol.value.Value;
import cc.xylitol.value.impl.BoolValue;
import cc.xylitol.value.impl.ColorValue;
import cc.xylitol.value.impl.ModeValue;
import cc.xylitol.value.impl.NumberValue;
import cc.xylitol.value.impl.TextValue;
import java.awt.Color;
import java.awt.Desktop;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.lang3.StringUtils;
import org.lwjglx.input.Keyboard;
import org.lwjglx.input.Mouse;
import org.lwjglx.opengl.Display;
import top.fl0wowp4rty.phantomshield.api.User;

public class NeverLoseClickGui
extends GuiScreen {
    public static NeverLoseClickGui INSTANCE = new NeverLoseClickGui();
    private short[] date;
    public float x = 4.0f;
    public float y = 20.0f;
    public float width = 520.0f;
    public final float height = 420.0f;
    public float search = 300.0f;
    public float visibleAnimation;
    private boolean quitting = false;
    private boolean dragging;
    private float dragX;
    private float dragY;
    public int wheel = Mouse.hasWheel() ? Mouse.getDWheel() * 2 : 0;
    private List<Module> leftModules = new CopyOnWriteArrayList<Module>();
    private List<Module> rightModules = new CopyOnWriteArrayList<Module>();
    private List[] lists = new List[0];
    public NumberFormat nf = new DecimalFormat("0000");
    private Category.Pages current = Category.Pages.COMBAT;
    private NumberValue currentSliding = null;
    private Value<?> dropdownItem;
    private TextValue currentEditing;
    private Rectangle protectArea;
    private final InputField searchTextField = new InputField(FontManager.font16);
    private boolean searching = false;
    private final float[] moduleWheel = new float[]{0.0f, 0.0f};
    private float alphaAnimate = 10.0f;
    private String tooltip = null;
    private final float offsetY = 0.0f;
    private boolean mouseDown = false;
    private final ArrayList<ItemStack> itemStacks = new ArrayList();
    private float scrollAni;
    private float CscrollAni;
    private static RapeMasterFontManager font;
    private float scrollY;
    private float CscrollY;

    public NeverLoseClickGui() {
        INSTANCE = this;
        this.dropdownItem = null;
        this.protectArea = null;
        this.init();
    }

    public void init() {
        font = FontManager.museo18;
        for (Item item : Item.itemRegistry) {
            this.itemStacks.add(new ItemStack(item));
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        float width;
        this.tooltip = null;
        this.visibleAnimation = AnimationUtils.animateSmooth(this.visibleAnimation, this.quitting ? 0.0f : 100.0f, 0.2f);
        if (this.quitting) {
            this.currentEditing = null;
            if (Display.isActive() && !this.mc.inGameHasFocus) {
                this.mc.inGameHasFocus = true;
                this.mc.mouseHelper.grabMouseCursor();
            }
            if (Math.round(this.visibleAnimation) <= 2) {
                this.mc.displayGuiScreen(null);
            }
        }
        if (!Mouse.isButtonDown(0) && this.dragging) {
            this.dragging = false;
        }
        if (this.dragging) {
            this.x = (float)mouseX - this.dragX;
            this.y = (float)mouseY - this.dragY;
        }
        if (!this.quitting) {
            ShaderElement.addBlurTask(() -> RoundedUtil.drawRound(this.x, this.y, this.width, 420.0f, 6.0f, true, new Color(255, 255, 255)));
            RoundedUtil.drawRound(this.x, this.y, this.width, 420.0f, 6.0f, false, new Color(255, 255, 255, 200));
        }
        this.width = (width = (float)Math.max(FontManager.bold38.getStringWidth(Client.name.toUpperCase()), FontManager.bold38.getStringWidth("NOVOLINE"))) > (float)FontManager.bold38.getStringWidth("NOVOLINE") ? AnimationUtils.animateSmooth(this.width, 520.0f + width - (float)FontManager.bold38.getStringWidth("NOVOLINE"), 0.5f) : AnimationUtils.animateSmooth(this.width, 520.0f, 0.5f);
        FontManager.bold38.drawCenteredString(Client.name.toUpperCase(), (float)((double)this.x + 7.7 + (double)(width / 2.0f)), this.y + 12.0f, this.getColor(new Color(51, 51, 51)).getRGB());
        float pageY = 44.0f;
        MaskUtil.defineMask();
        RenderUtil.drawRectWH(this.x, this.y + pageY - 4.0f, width + 10.0f, 344.0, -1);
        MaskUtil.finishDefineMask();
        MaskUtil.drawOnMask();
        float sb = 0.0f;
        for (Category pageManager : Category.values()) {
            sb += 12.0f;
            for (Category.Pages ignored : pageManager.getSubPages()) {
                sb += 26.0f;
            }
            sb += 4.0f;
        }
        this.CscrollY = Math.max(this.CscrollY, -sb + 344.0f);
        if (RenderUtil.isHovering(this.x, this.y + pageY, width + 10.0f, 340.0f, mouseX, mouseY)) {
            this.CscrollAni = AnimationUtils.animateSmooth(this.CscrollAni, this.CscrollY, 0.3f);
        } else {
            this.CscrollY = this.CscrollAni;
        }
        pageY += this.CscrollAni;
        pageY += 12.0f;
        for (Category.Pages cate : Category.Pages.values()) {
            String head = StringUtils.left(cate.name(), 1);
            String display = cate.name().substring(1);
            if (cate == this.current) {
                RoundedUtil.drawRound(this.x + 8.0f, this.y + pageY, width, 16.0f, 4.0f, true, this.getColor(221, 220, 220));
            }
            float finalPageY = pageY;
            cate.animation.draw(() -> RoundedUtil.drawRound(this.x + 8.0f, this.y + finalPageY, width, 16.0f, 4.0f, true, this.getColor(7, 50, 74, 230)));
            try {
                RenderUtil.drawImage(new ResourceLocation("xylitol/images/" + cate.name().toLowerCase() + ".png"), this.x + 10.0f, this.y + pageY + 2.0f, 12.0, 12.0, this.getColor(3, 168, 245).getRGB());
            }
            catch (Exception ignored) {
                ignored.printStackTrace();
            }
            String text = head + display.toLowerCase();
            text = text.replaceAll("_", " ");
            if (cate.gradient) {
                float finalPageY1 = pageY;
                String finalText = text;
                GlStateManager.pushMatrix();
                GradientUtil.applyGradientHorizontal(this.x + 26.0f, this.y + finalPageY1 + 4.5f, font.getStringWidth(text), font.getHeight(), Math.round(this.visibleAnimation / 100.0f), this.getColor(HUD.color(1)), this.getColor(HUD.color(89)), () -> {
                    GlStateManager.enableAlpha();
                    GlStateManager.alphaFunc(516, 0.0f);
                    font.drawString(finalText, this.x + 26.0f, this.y + finalPageY1 + 4.5f, this.getColor(255, 255, 255).getRGB());
                });
                GlStateManager.popMatrix();
            } else {
                font.drawString(text, this.x + 26.0f, this.y + pageY + 5.0f, this.getColor(38, 38, 38).getRGB());
            }
            pageY += 26.0f;
        }
        MaskUtil.resetMask();
        StencilUtil.initStencilToWrite();
        RoundedUtil.drawRound(this.x, this.y, this.width, 420.0f, 6.0f, true, this.getColor(255, 255, 255));
        StencilUtil.readStencilBuffer(1);
        ShaderElement.addBlurTask(() -> RenderUtil.drawRectWH(this.x + width + 8.0f + 8.0f, this.y, this.width - width - 16.0f, 420.0, this.getColor(255, 255, 255).getRGB()));
        RenderUtil.drawRectWH(this.x + width + 8.0f + 8.0f, this.y, this.width - width, 420.0, this.getColor(240, 239, 238, 200).getRGB());
        Gui.drawRect(this.x + width + 8.0f + 8.0f, this.y + 40.0f, this.x + this.width, this.y + 41.0f, this.getColor(217, 217, 217).getRGB());
        StencilUtil.endStencilBuffer();
        if (this.current == Category.Pages.CONFIGS) {
            boolean hovered = RenderUtil.isHovering(this.x + width + 16.0f + 4.0f, this.y + 10.0f, 89.0f, 20.0f, mouseX, mouseY);
            RoundedUtil.drawRoundOutline(this.x + width + 16.0f + 4.0f, this.y + 10.0f, 89.0f, 20.0f, 4.0f, 0.1f, this.getColor(217, 217, 217), hovered ? this.getColor(new Color(-16734222)) : this.getColor(217, 217, 217));
            font.drawCenteredString("Create Config", this.x + width + 16.0f + 4.0f + 44.5f, this.y + 17.0f, this.getColor(0, 0, 0).getRGB());
            boolean hovered2 = RenderUtil.isHovering(this.x + width + 16.0f + 96.0f, this.y + 10.0f, 89.0f, 20.0f, mouseX, mouseY);
            RoundedUtil.drawRoundOutline(this.x + width + 16.0f + 96.0f, this.y + 10.0f, 89.0f, 20.0f, 4.0f, 0.1f, this.getColor(217, 217, 217), hovered2 ? this.getColor(new Color(-16734222)) : this.getColor(217, 217, 217));
            font.drawCenteredString("Open directory", this.x + width + 16.0f + 96.0f + 44.5f, this.y + 17.0f, this.getColor(0, 0, 0).getRGB());
        } else {
            RoundedUtil.drawRoundOutline(this.x + width + 16.0f + 10.0f, this.y + 10.0f, this.search, 20.0f, 4.0f, 0.1f, this.getColor(242, 241, 240), this.getColor(217, 217, 217));
            if (!this.searching) {
                RenderUtil.drawImage(new ResourceLocation("xylitol/images/search.png"), this.x + width + 16.0f + 10.0f + 3.0f, this.y + 13.0f, 14.0, 14.0, this.getColor(150, 150, 150, 100).getRGB());
            }
            this.searchTextField.setBackgroundText("Press CTRL+F to search with in gui..");
            this.searchTextField.setDrawingLine(false);
            this.searchTextField.setxPosition(this.x + width + 16.0f + 10.0f + 3.0f + (float)(this.searching ? 0 : 16));
            this.searchTextField.setyPosition(this.y + 13.0f);
            this.searchTextField.setWidth(this.search);
            this.searchTextField.setHeight(20.0f);
            this.searchTextField.setDrawingBackground(false);
            this.searchTextField.drawTextBox(mouseX, mouseY);
        }
        StencilUtil.initStencilToWrite();
        RenderUtil.drawRectWH(this.x, this.y + 45.0f, this.width, 374.0, this.getColor(201, 201, 201).getRGB());
        StencilUtil.readStencilBuffer(1);
        int n = this.wheel = Mouse.hasWheel() ? Mouse.getDWheel() * 12 : 0;
        if (this.current.module) {
            float left = this.render(this.leftModules, this.x + width + 24.0f, mouseX, mouseY);
            float right = this.render(this.rightModules, this.x + width + 24.0f + 198.0f, mouseX, mouseY);
            float[] nextWheel = RenderUtil.getNextWheelPosition(this.wheel, this.moduleWheel, this.y + 10.0f, this.y + 290.0f, Math.max(left, right), 0.0f, RenderUtil.isHovering(this.x + 120.0f, this.y + 40.0f, this.width - 120.0f, this.height - 40.0f, mouseX, mouseY));
            this.moduleWheel[0] = nextWheel[0];
            this.moduleWheel[1] = Math.max(left, right) > this.height ? Math.max(nextWheel[1], -Math.max(left, right) + this.height - 60.0f) : nextWheel[1];
        } else if (this.current == Category.Pages.CONFIGS) {
            Client styles = Client.instance;
            float configY = this.y + 40.0f + 8.0f + 14.0f + this.scrollAni;
            FontManager.font16.drawString("- My Items", this.x + width + 16.0f + 6.0f, configY - 14.0f, this.getColor(77, 77, 77).getRGB());
            float naotan = styles.getConfigManager().getConfigs().size() * 42;
            if (naotan > this.height - 60.0f) {
                this.scrollY = Math.max(this.scrollY, -naotan + this.height - 60.0f);
                if (RenderUtil.isHovering(this.x + width + 16.0f, 0.0f, 370.0f, 420.0f, mouseX, mouseY)) {
                    this.scrollAni = AnimationUtils.animateSmooth(this.scrollAni, this.scrollY * 2.0f, 0.2f);
                } else {
                    this.scrollY = this.scrollAni;
                }
            }
            for (String config : styles.getConfigManager().getConfigs()) {
                RoundedUtil.drawRoundOutline(this.x + width + 16.0f + 6.0f, configY, 370.0f, 36.0f, 4.0f, 0.1f, this.getColor(230, 230, 230), this.getColor(217, 217, 217));
                FontManager.font18.drawString(config, this.x + width + 16.0f + 12.0f, configY + 6.0f, this.getColor(0, 0, 0).getRGB());
                FontManager.font18.drawString(EnumChatFormatting.GRAY + "Modified: " + EnumChatFormatting.RESET + "2077/7/7 " + EnumChatFormatting.GRAY + "Author: " + EnumChatFormatting.RESET + "null", this.x + width + 16.0f + 12.0f, configY + 8.0f + 12.0f, this.getColor(3, 146, 214).getRGB());
                boolean fuck = RenderUtil.isHovering(this.x + width + 16.0f + 6.0f + 290.0f - 6.0f, configY + 8.0f, 76.0f, 20.0f, mouseX, mouseY);
                if ("modules.json".equals(config)) {
                    RoundedUtil.drawRoundOutline(this.x + width + 16.0f + 6.0f + 290.0f - 6.0f, configY + 8.0f, 76.0f, 20.0f, 4.0f, 0.1f, this.getColor(217, 217, 217), fuck ? this.getColor(new Color(-16734222)) : this.getColor(217, 217, 217));
                    RenderUtil.drawImage(new ResourceLocation("xylitol/images/save.png"), this.x + width + 16.0f + 6.0f + 290.0f + 10.0f, configY + 8.0f + 2.0f, 16.0, 16.0, this.getColor(201, 201, 201).getRGB());
                    FontManager.font16.drawString("Save", this.x + width + 16.0f + 6.0f + 290.0f + 30.0f, configY + 8.0f + 8.0f, this.getColor(201, 201, 201).getRGB());
                } else {
                    RoundedUtil.drawRound(this.x + width + 16.0f + 6.0f + 290.0f - 6.0f, configY + 8.0f, 76.0f, 20.0f, 4.0f, false, fuck ? this.getColor(new Color(-16734222)) : this.getColor(new Color(1933999)));
                    RenderUtil.drawImage(new ResourceLocation("xylitol/images/read.png"), this.x + width + 16.0f + 6.0f + 290.0f + 10.0f, configY + 8.0f + 2.0f, 16.0, 16.0, fuck ? -1 : this.getColor(201, 201, 201).getRGB());
                    FontManager.font16.drawString("Load", this.x + width + 16.0f + 6.0f + 290.0f + 30.0f, configY + 8.0f + 8.0f, fuck ? -1 : this.getColor(201, 201, 201).getRGB());
                }
                configY += 42.0f;
            }
        }
        StencilUtil.endStencilBuffer();
        RenderUtil.drawRectWH(this.x, this.y + 420.0f - 30.0f, width + 16.0f, 0.5, this.getColor(217, 217, 217).getRGB());
        RenderUtil.drawCircleCGUI(this.x + 16.0f, this.y + 420.0f - 15.0f, 26.0f, this.getColor(20, 20, 20).getRGB());
        GlStateManager.disableTexture2D();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        GlStateManager.enableTexture2D();
        GlStateManager.disableTexture2D();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        RenderUtil.drawCircleCGUI(this.x + 16.0f, this.y + 420.0f - 15.0f, 26.0f, -1);
        GlStateManager.disableTexture2D();
        font.drawString(Client.instance.user, this.x + 34.0f, this.y + 420.0f - 30.0f + 6.0f, this.getColor(0, 0, 0).getRGB());
        font.drawString(EnumChatFormatting.GRAY + "Till: ", this.x + 34.0f, this.y + 420.0f - 30.0f + 18.0f, this.getColor(3, 168, 245).getRGB());
        font.drawString("idk", this.x + 34.0f + (float)font.getStringWidth("Till: "), this.y + 420.0f - 30.0f + 18.0f, this.getColor(3, 168, 245).getRGB());
        this.alphaAnimate = AnimationUtils.animateSmooth(this.alphaAnimate, 180.0f, 0.4f);
        if (this.dropdownItem != null && this.protectArea != null) {
            if (this.dropdownItem instanceof ModeValue) {
                ModeValue property = (ModeValue)this.dropdownItem;
                property.animation = AnimationUtils.animateSmooth(property.animation, 255.0f, 0.5f);
                RoundedUtil.drawRound(this.protectArea.getX(), this.protectArea.getY(), this.protectArea.getWidth(), this.protectArea.getHeight() + 1.0f, 4.0f, this.getColor(RenderUtil.reAlpha(new Color(240, 240, 240), (int)property.animation)));
                int buttonY = 0;
                for (String s : property.getModes()) {
                    font.drawString(s, this.protectArea.getX() + 3.0f, this.protectArea.getY() + (float)buttonY + 6.0f, !property.is(s) ? this.getColor(RenderUtil.reAlpha(new Color(77, 77, 77), (int)property.animation)).getRGB() : this.getColor(RenderUtil.reAlpha(new Color(0, 0, 0), (int)property.animation)).getRGB());
                    buttonY += 14;
                }
            }
            if (this.dropdownItem instanceof ColorValue) {
                ColorValue cp = (ColorValue)this.dropdownItem;
                Color valColor = cp.getColorC();
                HSBData hsbData = new HSBData(valColor);
                float[] hsba = new float[]{hsbData.getHue(), hsbData.getSaturation(), hsbData.getBrightness(), hsbData.getAlpha()};
                RoundedUtil.drawRoundOutline(this.protectArea.getX(), this.protectArea.getY(), this.protectArea.getWidth(), this.protectArea.getHeight() + 1.0f, 2.0f, 0.1f, this.getColor(5, 16, 26), this.getColor(217, 217, 217));
                RenderUtil.drawRectWH(this.protectArea.getX() + 3.0f, this.protectArea.getY() + 3.0f, 61.0, 61.0, this.getColor(0, 0, 0).getRGB());
                RenderUtil.drawRectWH((double)this.protectArea.getX() + 3.5, (double)this.protectArea.getY() + 3.5, 60.0, 60.0, this.getColor(Color.getHSBColor(hsba[0], 1.0f, 1.0f)).getRGB());
                RenderUtil.drawHGradientRect((double)this.protectArea.getX() + 3.5, (double)this.protectArea.getY() + 3.5, 60.0, 60.0, this.getColor(Color.getHSBColor(hsba[0], 0.0f, 1.0f)).getRGB(), 15);
                RenderUtil.drawVGradientRect((double)this.protectArea.getX() + 3.5, (double)this.protectArea.getY() + 3.5, 60.0, 60.0, 15, this.getColor(Color.getHSBColor(hsba[0], 1.0f, 0.0f)).getRGB());
                RenderUtil.drawRectWH((double)this.protectArea.getX() + 3.5 + (double)(hsba[1] * 60.0f) - 0.5, (double)this.protectArea.getY() + 3.5 + (double)((1.0f - hsba[2]) * 60.0f) - 0.5, 1.5, 1.5, this.getColor(0, 0, 0).getRGB());
                RenderUtil.drawRectWH((double)this.protectArea.getX() + 3.5 + (double)(hsba[1] * 60.0f), (double)this.protectArea.getY() + 3.5 + (double)((1.0f - hsba[2]) * 60.0f), 0.5, 0.5, this.getColor(valColor).getRGB());
                boolean onSB = RenderUtil.isHovering(this.protectArea.getX() + 3.0f, this.protectArea.getY() + 3.0f, 61.0f, 61.0f, mouseX, mouseY);
                if (onSB && Mouse.isButtonDown(0)) {
                    hsbData.setSaturation(Math.min(Math.max(((float)mouseX - this.protectArea.getX() - 3.0f) / 60.0f, 0.0f), 1.0f));
                    hsbData.setBrightness(1.0f - Math.min(Math.max(((float)mouseY - this.protectArea.getY() - 3.0f) / 60.0f, 0.0f), 1.0f));
                    cp.setColor(hsbData.getAsColor().getRGB());
                }
                RenderUtil.drawRectWH(this.protectArea.getX() + 67.0f, this.protectArea.getY() + 3.0f, 10.0, 61.0, this.getColor(0, 0, 0).getRGB());
                for (float f = 0.0f; f < 5.0f; f += 1.0f) {
                    Color lasCol = Color.getHSBColor(f / 5.0f, 1.0f, 1.0f);
                    Color tarCol = Color.getHSBColor(Math.min(f + 1.0f, 5.0f) / 5.0f, 1.0f, 1.0f);
                    RenderUtil.drawVGradientRect((double)this.protectArea.getX() + 67.5, (double)this.protectArea.getY() + 3.5 + (double)(f * 12.0f), 9.0, 12.0, this.getColor(lasCol).getRGB(), this.getColor(tarCol).getRGB());
                }
                RenderUtil.drawRectWH((double)this.protectArea.getX() + 67.5, this.protectArea.getY() + 2.0f + hsba[0] * 60.0f, 9.0, 2.0, this.getColor(0, 0, 0).getRGB());
                RenderUtil.drawRectWH((double)this.protectArea.getX() + 67.5, (double)this.protectArea.getY() + 2.5 + (double)(hsba[0] * 60.0f), 9.0, 1.0, this.getColor(204, 198, 255).getRGB());
                boolean onHue = RenderUtil.isHovering(this.protectArea.getX() + 67.0f, this.protectArea.getY() + 3.0f, 10.0f, 61.0f, mouseX, mouseY);
                if (onHue && Mouse.isButtonDown(0)) {
                    hsbData.setHue(Math.min(Math.max(((float)mouseY - this.protectArea.getY() - 3.0f) / 60.0f, 0.0f), 1.0f));
                    cp.setColor(hsbData.getAsColor().getRGB());
                    cp.setRainbowEnabled(false);
                }
                if (cp.isAlphaChangeable()) {
                    RenderUtil.drawRectWH(this.protectArea.getX() + 3.0f, this.protectArea.getY() + 67.0f, 61.0, 9.0, this.getColor(0, 0, 0).getRGB());
                    for (int xPosition = 0; xPosition < 30; ++xPosition) {
                        for (int yPosition = 0; yPosition < 4; ++yPosition) {
                            RenderUtil.drawRectWH((double)this.protectArea.getX() + 3.5 + (double)(xPosition * 2), (double)this.protectArea.getY() + 67.5 + (double)(yPosition * 2), 2.0, 2.0, yPosition % 2 == 0 == (xPosition % 2 == 0) ? this.getColor(255, 255, 255).getRGB() : this.getColor(190, 190, 190).getRGB());
                        }
                    }
                    RenderUtil.drawHGradientRect((double)this.protectArea.getX() + 3.5, (double)this.protectArea.getY() + 67.5, 60.0, 8.0, 15, this.getColor(Color.getHSBColor(hsba[0], 1.0f, 1.0f)).getRGB());
                    RenderUtil.drawRectWH((double)this.protectArea.getX() + 2.5 + (double)(hsba[3] * 60.0f), (double)this.protectArea.getY() + 67.5, 2.0, 8.0, this.getColor(0, 0, 0).getRGB());
                    RenderUtil.drawRectWH(this.protectArea.getX() + 3.0f + hsba[3] * 60.0f, (double)this.protectArea.getY() + 67.5, 1.0, 8.0, this.getColor(204, 198, 255).getRGB());
                    boolean onAlpha = RenderUtil.isHovering(this.protectArea.getX() + 3.0f, this.protectArea.getY() + 67.0f, 61.0f, 9.0f, mouseX, mouseY);
                    if (onAlpha && Mouse.isButtonDown(0)) {
                        hsbData.setAlpha(Math.min(Math.max(((float)mouseX - this.protectArea.getX() - 3.0f) / 60.0f, 0.0f), 1.0f));
                    }
                }
            }
        }
        if (this.tooltip != null && !this.tooltip.isEmpty()) {
            ShaderElement.addBlurTask(() -> RoundedUtil.drawRound(mouseX + 6, mouseY + 6, font.getStringWidth(this.findLongestString(this.tooltip.split("\n"))) + 10, this.tooltip.split("\n").length * 14 + (this.tooltip.split("\n").length == 1 ? 0 : 4), 2.0f, true, new Color(10, 19, 30, 255)));
            RoundedUtil.drawRound(mouseX + 6, mouseY + 6, font.getStringWidth(this.findLongestString(this.tooltip.split("\n"))) + 10, this.tooltip.split("\n").length * 14 + (this.tooltip.split("\n").length == 1 ? 0 : 4), 2.0f, false, new Color(255, 255, 255, 30));
            RoundedUtil.drawRound(mouseX + 6, mouseY + 6, font.getStringWidth(this.findLongestString(this.tooltip.split("\n"))) + 10, this.tooltip.split("\n").length * 14 + (this.tooltip.split("\n").length == 1 ? 0 : 4), 2.0f, true, new Color(10, 19, 30, 100));
            float y = 5.0f;
            for (String s : this.tooltip.split("\n")) {
                font.drawString(s, mouseX + 6 + 4, (float)(mouseY + 6) + y, this.getColor(255, 255, 255).getRGB());
                if (this.tooltip.split("\n").length == 1) continue;
                y += 14.0f;
            }
        }
    }

    protected boolean check(double x, double y, double x2, double y2, double mouseX, double mouseY) {
        return mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2;
    }

    private boolean checkClick() {
        if (!this.mouseDown && Mouse.isButtonDown(0)) {
            this.mouseDown = true;
            return true;
        }
        return false;
    }

    public static double round(double value, double inc) {
        if (inc == 0.0) {
            return value;
        }
        if (inc == 1.0) {
            return Math.round(value);
        }
        double halfOfInc = inc / 2.0;
        double floored = Math.floor(value / inc) * inc;
        if (value >= floored + halfOfInc) {
            return new BigDecimal(Math.ceil(value / inc) * inc).doubleValue();
        }
        return new BigDecimal(floored).doubleValue();
    }

    private float render(List<Module> modules, float offset, int mouseX, int mouseY) {
        float moduleY = 0.0f + this.moduleWheel[1];
        for (Module module : modules) {
            FontManager.font16.drawString(module.getName().toUpperCase(), offset + 4.0f, this.y + 50.0f + moduleY, new Color(134, 134, 133).getRGB());
            int predictionHeight = 16;
            for (Value<?> property : module.getValues()) {
                if (!property.isAvailable()) continue;
                predictionHeight = (int)((float)predictionHeight + property.getHeight());
            }
            RoundedUtil.drawRound(offset, this.y + 46.0f + (float)FontManager.font16.getHeight() + 4.0f + moduleY, 190.0f, predictionHeight, 4.0f, false, this.getColor(128, 128, 128, 50));
            font.drawString("Enabled", offset + 4.0f, this.y + 50.0f + (moduleY += 10.0f) + 6.0f, module.getState() ? this.getColor(0, 0, 0).getRGB() : this.getColor(77, 77, 77).getRGB());
            RoundedUtil.drawRoundOutline(offset + 162.0f, 2.0f + this.y + 48.0f + moduleY + 5.0f, 23.0f, 12.0f, 6.0f, 0.1f, module.getState() ? this.getColor(3, 168, 245) : this.getColor(230, 230, 230), this.getColor(220, 220, 220));
            if (RenderUtil.isHovering(offset + 168.0f, this.y + 50.0f + moduleY + 5.0f, 16.0f, 8.0f, mouseX, mouseY)) {
                this.tooltip = "";
            }
            module.cGUIAnimation = AnimationUtils.animateSmooth(module.cGUIAnimation, module.getState() ? 10.0f : 0.0f, 0.5f);
            RenderUtil.drawImage(new ResourceLocation("xylitol/images/shadow.png"), offset + 160.0f + module.cGUIAnimation, 2.0f + this.y + 44.0f + moduleY + 9.0f, 16, 16);
            RenderUtil.drawCircleCGUI(offset + 168.0f + module.cGUIAnimation, 2.0f + this.y + 50.0f + moduleY + 9.0f, 10.0f, this.getColor(255, 255, 255).getRGB());
            if (module.getValues().size() > 0) {
                RenderUtil.drawRectWH(offset + 4.0f, this.y + 50.0f + moduleY + 18.0f, 182.0, 0.5, this.getColor(217, 217, 217).getRGB());
            }
            moduleY += 18.0f;
            for (Value<?> property : module.getValues()) {
                if (!property.isAvailable()) continue;
                if (property instanceof BoolValue) {
                    BoolValue bp = (BoolValue)property;
                    font.drawString(property.getName(), offset + 4.0f, this.y + 50.0f + moduleY + 6.0f + 2.0f, bp.get() ? this.getColor(0, 0, 0).getRGB() : this.getColor(77, 77, 77).getRGB());
                    RoundedUtil.drawRoundOutline(offset + 162.0f, 2.0f + this.y + 48.0f + moduleY + 5.0f, 23.0f, 12.0f, 6.0f, 0.1f, bp.get() ? this.getColor(3, 168, 245) : this.getColor(230, 230, 230), this.getColor(220, 220, 220));
                    property.animation = AnimationUtils.animateSmooth(property.animation, bp.get() ? 10.0f : 0.0f, 0.5f);
                    RenderUtil.drawImage(new ResourceLocation("xylitol/images/shadow.png"), offset + 160.0f + property.animation, 2.0f + this.y + 44.0f + moduleY + 9.0f, 16, 16);
                    RenderUtil.drawCircleCGUI(offset + 168.0f + property.animation, 2.0f + this.y + 50.0f + moduleY + 9.0f, 10.0f, this.getColor(255, 255, 255).getRGB());
                }
                if (property instanceof ColorValue) {
                    ColorValue cp = (ColorValue)property;
                    font.drawString(property.getName(), offset + 4.0f, this.y + 50.0f + moduleY + 6.0f + 2.0f, this.getColor(77, 77, 77).getRGB());
                    RenderUtil.drawCircleCGUI(offset + 175.0f, 2.0f + this.y + 50.0f + moduleY + 9.0f, 11.0f, this.getColor(new Color(cp.getColor())).getRGB());
                    if (this.dropdownItem == cp) {
                        this.protectArea = new Rectangle(offset + 100.0f, 2.0f + this.y + moduleY + 50.0f + 24.0f, 80.0f, cp.isAlphaChangeable() ? 80.0f : 67.0f);
                    }
                }
                if (property instanceof NumberValue) {
                    DecimalFormat df = new DecimalFormat("#.#");
                    NumberValue dp = (NumberValue)property;
                    String display = String.valueOf(dp.getValue());
                    if (display.endsWith(".0")) {
                        display = display.substring(0, display.length() - 2);
                    } else if (display.startsWith("0.")) {
                        display = "." + display.substring(2);
                    } else if (display.startsWith("-0.")) {
                        display = "-" + display.substring(2);
                    }
                    font.drawString(property.getName(), offset + 4.0f, this.y + 50.0f + moduleY + 6.0f + 2.0f, dp.sliding ? this.getColor(0, 0, 0).getRGB() : this.getColor(77, 77, 77).getRGB());
                    FontManager.font14.drawCenteredString(display, offset + 190.0f - 13.0f, 2.0f + this.y + 50.0f + moduleY + 6.0f, this.getColor(145, 166, 179).getRGB());
                    RoundedUtil.drawRound(offset + 96.0f, 2.0f + this.y + 50.0f + moduleY + 8.0f, 70.0f, 2.0f, 2.0f, true, this.getColor(255, 255, 255));
                    double ratio = (dp.getValue() - dp.getMin()) / (dp.getMax() - dp.getMin());
                    int displayLength = (int)(ratio * 70.0);
                    displayLength = Math.min(displayLength, 70);
                    dp.animatedPercentage = AnimationUtils.animateSmooth(dp.animatedPercentage, displayLength, 0.2f);
                    RoundedUtil.drawRound(offset + 92.0f, 2.0f + this.y + 50.0f + moduleY + 8.0f, dp.animatedPercentage, 2.0f, 2.0f, true, this.getColor(3, 168, 245));
                    dp.animation = AnimationUtils.animateSmooth(dp.animation, dp.sliding ? 10.0f : 8.0f, 0.2f);
                    RenderUtil.drawImage(new ResourceLocation("xylitol/images/shadow.png"), 84.0f + offset + dp.animatedPercentage, 2.0f + this.y + 42.0f + moduleY + 9.0f, 16, 16);
                    RenderUtil.drawCircleCGUI(92.0f + offset + dp.animatedPercentage, 2.0f + this.y + 50.0f + moduleY + 9.0f, dp.animation, this.getColor(3, 168, 245).getRGB());
                    if (dp.sliding) {
                        double num = Math.max(dp.getMin(), Math.min(dp.getMax(), NeverLoseClickGui.round((double)((float)mouseX - (offset + 92.0f)) * (dp.getMax() - dp.getMin()) / 70.0 + dp.getMin(), dp.getInc())));
                        num = (double)Math.round(num * (1.0 / dp.getInc())) / (1.0 / dp.getInc());
                        dp.setValue(num);
                    }
                }
                if (property instanceof ModeValue) {
                    ModeValue sp = (ModeValue)property;
                    sp.height = 24.0f;
                    font.drawString(property.getName(), offset + 4.0f, this.y + 50.0f + moduleY + 9.0f + 1.0f, this.getColor(77, 77, 77).getRGB());
                    RoundedUtil.drawRoundOutline(offset + 100.0f, this.y + 50.0f + moduleY + 3.5f, 80.0f, 16.0f, 4.0f, 0.1f, this.getColor(242, 242, 242), this.getColor(217, 217, 217));
                    MaskUtil.defineMask();
                    RoundedUtil.drawRoundOutline(offset + 100.0f, this.y + 50.0f + moduleY + 3.5f, 80.0f, 16.0f, 4.0f, 0.1f, this.getColor(242, 242, 242), this.getColor(217, 217, 217));
                    MaskUtil.finishDefineMask();
                    MaskUtil.drawOnMask();
                    try {
                        font.drawString(sp.get(), offset + 104.0f, this.y + 50.0f + moduleY + 9.0f, this.getColor(77, 77, 77).getRGB());
                    }
                    catch (Exception dp) {
                        // empty catch block
                    }
                    MaskUtil.resetMask();
                    float spmaxWidth = 0.0f;
                    for (String s : sp.getModes()) {
                        float f = font.getStringWidth(s) + 12;
                        if (!(f > spmaxWidth)) continue;
                        spmaxWidth = f;
                    }
                    if (this.dropdownItem == sp) {
                        this.protectArea = new Rectangle(offset + 100.0f, this.y + moduleY + 50.0f + 24.0f, spmaxWidth > 80.0f ? spmaxWidth : 80.0f, 14 * sp.getModes().length);
                    }
                }
                if (property instanceof TextValue) {
                    TextValue tp = (TextValue)property;
                    boolean isMe = this.currentEditing == tp;
                    font.drawString(property.getName(), offset + 4.0f, this.y + 50.0f + moduleY + 9.0f + 2.0f, this.getColor(255, 255, 255).getRGB());
                    RoundedUtil.drawRoundOutline(offset + 100.0f, this.y + 50.0f + moduleY + 3.5f, 80.0f, 18.0f, 2.0f, 0.1f, this.getColor(230, 230, 230), isMe ? this.getColor(201, 201, 201).brighter() : this.getColor(217, 217, 217));
                    MaskUtil.defineMask();
                    RoundedUtil.drawRoundOutline(offset + 100.0f, this.y + 50.0f + moduleY + 3.5f, 80.0f, 18.0f, 2.0f, 0.1f, this.getColor(230, 230, 230), isMe ? this.getColor(201, 201, 201).brighter() : this.getColor(217, 217, 217));
                    MaskUtil.finishDefineMask();
                    MaskUtil.drawOnMask();
                    font.drawString(tp.get() + (isMe ? "_" : ""), offset + 104.0f, this.y + 50.0f + moduleY + 9.0f, this.getColor(77, 77, 77).getRGB());
                    RenderUtil.drawRectWH(offset + 104.0f, this.y + 50.0f + moduleY + 9.0f, font.getStringWidth(tp.getSelectedString()), font.getHeight(), this.getColor(255, 255, 255, 100).getRGB());
                    MaskUtil.resetMask();
                }
                moduleY += property.getHeight();
                List<Value<?>> visible = new ArrayList(module.getValues());
                visible.removeIf(Value::isHidden);
                if (visible.indexOf(property) == visible.size() - 1) continue;
                RenderUtil.drawRectWH(offset + 4.0f, this.y + 50.0f + moduleY, 182.0, 0.5, this.getColor(217, 217, 217).getRGB());
            }
            moduleY += 4.0f;
        }
        return moduleY - this.moduleWheel[1];
    }

    public void setQuitting(boolean quitting) {
        this.quitting = quitting;
    }

    public boolean isOpened() {
        return !this.quitting;
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        try {
            Client.instance.configManager.saveAllConfig();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        this.dropdownItem = null;
        this.searching = false;
        this.quitting = false;
    }

    @Override
    public void handleMouseInput() throws IOException {
        this.scrollY += (float)Mouse.getEventDWheel();
        if (this.scrollY >= 0.0f) {
            this.scrollY = 0.0f;
        }
        this.CscrollY += (float)Mouse.getEventDWheel();
        if (this.CscrollY >= 0.0f) {
            this.CscrollY = 0.0f;
        }
        int i = Mouse.getEventX() * new ScaledResolution(this.mc).getScaledWidth() / this.mc.displayWidth;
        int j = new ScaledResolution(this.mc).getScaledHeight() - Mouse.getEventY() * new ScaledResolution(this.mc).getScaledHeight() / this.mc.displayHeight - 1;
        super.handleMouseInput();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_RETURN && this.searching) {
            return;
        }
        if (keyCode == Keyboard.KEY_ESCAPE) {
            this.mc.displayGuiScreen(null);
        }
        if (GuiScreen.isKeyComboCtrlF(keyCode)) {
            boolean bl = this.searching = !this.searching;
            if (this.searching) {
                this.lists = new List[]{this.leftModules, this.rightModules};
                this.searchTextField.setText("");
            } else {
                this.leftModules = this.lists[0];
                this.rightModules = this.lists[1];
                this.resetModuleList();
            }
            return;
        }
        if (this.currentEditing != null) {
            try {
                if (keyCode == Keyboard.KEY_BACK && !this.currentEditing.get().isEmpty()) {
                    this.currentEditing.setValue(!this.currentEditing.getSelectedString().isEmpty() ? "" : this.currentEditing.get().substring(0, this.currentEditing.get().length() - 1));
                    this.currentEditing.setSelectedString("");
                    return;
                }
                if (GuiScreen.isKeyComboCtrlA(keyCode)) {
                    this.currentEditing.setSelectedString(this.currentEditing.get());
                    return;
                }
                if (GuiScreen.isKeyComboCtrlC(keyCode)) {
                    GuiScreen.setClipboardString(this.currentEditing.getSelectedString());
                    return;
                }
                if (GuiScreen.isKeyComboCtrlV(keyCode)) {
                    if (this.currentEditing.getSelectedString().isEmpty() && (this.currentEditing.get() + GuiScreen.getClipboardString()).length() > 22) {
                        this.currentEditing.setSelectedString("");
                        return;
                    }
                    this.currentEditing.setValue(!this.currentEditing.getSelectedString().isEmpty() ? GuiScreen.getClipboardString() : this.currentEditing.get() + GuiScreen.getClipboardString());
                    this.currentEditing.setSelectedString("");
                    return;
                }
                if (GuiScreen.isCtrlKeyDown()) {
                    return;
                }
                if (keyCode == Keyboard.KEY_ESCAPE) {
                    this.currentEditing.setSelectedString("");
                    this.currentEditing = null;
                    return;
                }
                if (this.currentEditing.get().length() > 22) {
                    return;
                }
                this.currentEditing.setValue(!this.currentEditing.getSelectedString().isEmpty() ? ChatAllowedCharacters.filterAllowedCharacters(String.valueOf(typedChar)) : this.currentEditing.get() + ChatAllowedCharacters.filterAllowedCharacters(String.valueOf(typedChar)));
                this.currentEditing.setSelectedString("");
                return;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (this.searching) {
            this.searchTextField.setFocused(true);
            this.searchTextField.keyTyped(typedChar, keyCode);
            this.resetModuleList();
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    private Color getColor(int r, int g, int b) {
        return RenderUtil.reAlpha(new Color(r, g, b), Math.round(this.visibleAnimation / 100.0f * 255.0f));
    }

    private Color getColor(int r, int g, int b, int a) {
        return RenderUtil.reAlpha(new Color(r, g, b), Math.round(this.visibleAnimation / 100.0f * (float)a));
    }

    private Color getColor(Color color) {
        return RenderUtil.reAlpha(color, Math.round(this.visibleAnimation / 100.0f * (float)color.getAlpha()));
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        if (this.currentSliding != null) {
            this.currentSliding.sliding = false;
            this.currentSliding = null;
        }
    }

    public String findLongestString(String[] strArray) {
        String longestString = "";
        for (String str : strArray) {
            if (font.getStringWidth(str) <= font.getStringWidth(longestString)) continue;
            longestString = str;
        }
        return longestString;
    }

    @Override
    public void initGui() {
        this.date = User.INSTANCE.getExpiredDate();
        super.initGui();
        this.resetModuleList();
    }

    private void click(List<Module> modules, float offset, int mouseX, int mouseY, int mouseButton) {
        float moduleY = 0.0f + this.moduleWheel[1];
        for (Module module : modules) {
            if (RenderUtil.isHovering(offset + 4.0f, this.y + 50.0f + (moduleY += 10.0f) + 4.0f, 184.0f, 12.0f, mouseX, mouseY)) {
                if (mouseButton == 0) {
                    module.toggle();
                }
                return;
            }
            moduleY += 18.0f;
            for (Value<?> property : module.getValues()) {
                if (property.isHidden()) continue;
                if (property instanceof BoolValue) {
                    BoolValue bp = (BoolValue)property;
                    if (RenderUtil.isHovering(offset + 4.0f, this.y + 50.0f + moduleY + 5.0f, 184.0f, 12.0f, mouseX, mouseY) && mouseButton == 0) {
                        bp.set(!bp.get());
                        return;
                    }
                }
                if (property instanceof NumberValue) {
                    NumberValue dp = (NumberValue)property;
                    if (RenderUtil.isHovering(offset + 88.0f, this.y + 50.0f + moduleY + 2.0f, 78.0f, 16.0f, mouseX, mouseY) && mouseButton == 0) {
                        dp.sliding = true;
                        this.currentSliding = dp;
                    }
                }
                if (property instanceof ModeValue) {
                    ModeValue sp = (ModeValue)property;
                    if (RenderUtil.isHovering(offset + 4.0f, this.y + 50.0f + moduleY + 6.0f, 184.0f, 18.0f, mouseX, mouseY) && mouseButton == 0) {
                        if (this.dropdownItem != property) {
                            this.dropdownItem = sp;
                            sp.animation = 100.0f;
                            this.protectArea = new Rectangle(offset + 100.0f, this.y + moduleY + 50.0f + 24.0f, 80.0f, 14 * sp.getModes().length);
                        } else {
                            this.dropdownItem = null;
                            this.protectArea = null;
                        }
                    }
                }
                if (property instanceof TextValue) {
                    TextValue tp = (TextValue)property;
                    if (RenderUtil.isHovering(offset + 4.0f, this.y + 50.0f + moduleY + 6.0f, 184.0f, 18.0f, mouseX, mouseY) && mouseButton == 0) {
                        this.currentEditing = tp;
                    } else if (this.currentEditing == tp) {
                        this.currentEditing = null;
                    }
                }
                if (property instanceof ColorValue) {
                    ColorValue cp = (ColorValue)property;
                    if (RenderUtil.isHovering((float)((double)(offset + 175.0f) - 5.5), (float)((double)(this.y + 50.0f + moduleY + 9.0f) - 5.5), 11.0f, 11.0f, mouseX, mouseY)) {
                        if (mouseButton == 0) {
                            this.dropdownItem = cp;
                            this.protectArea = new Rectangle(offset + 100.0f, this.y + moduleY + 50.0f + 24.0f, 80.0f, cp.isAlphaChangeable() ? 80.0f : 67.0f);
                        } else {
                            cp.setRainbowEnabled(!cp.isEnabledRainbow());
                        }
                    }
                }
                moduleY += property.getHeight();
            }
            moduleY += 4.0f;
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (this.dropdownItem != null && this.protectArea != null) {
            if (this.dropdownItem instanceof ModeValue) {
                ModeValue property = (ModeValue)this.dropdownItem;
                int buttonY = 0;
                String[] stringArray = property.getModes();
                int n = stringArray.length;
                for (int i = 0; i < n; ++i) {
                    String string = stringArray[i];
                    boolean isHovering = RenderUtil.isHovering(this.protectArea.getX() + 0.5f, this.protectArea.getY() + (float)buttonY + 0.5f, this.protectArea.getWidth() - 1.0f, 14.0f, mouseX, mouseY);
                    if (isHovering && mouseButton == 0) {
                        property.set(string);
                        this.dropdownItem = null;
                        this.protectArea = null;
                        return;
                    }
                    buttonY += 14;
                }
            }
            if (this.dropdownItem instanceof ColorValue) {
                if (!RenderUtil.isHovering(this.protectArea.getX(), this.protectArea.getY(), this.protectArea.getWidth(), this.protectArea.getHeight() + 1.0f, mouseX, mouseY)) {
                    this.dropdownItem = null;
                    this.protectArea = null;
                }
                return;
            }
        }
        if (!RenderUtil.isHovering(this.x, this.y, this.width, 420.0f, mouseX, mouseY)) {
            return;
        }
        float width = Math.max(FontManager.bold38.getStringWidth(Client.name.toUpperCase()), FontManager.bold38.getStringWidth("NOVOLINE"));
        if (RenderUtil.isHovering(this.x + width + 16.0f + 10.0f, this.y + 10.0f, 200.0f, 20.0f, mouseX, mouseY) && this.current != Category.Pages.CONFIGS) {
            boolean bl = this.searching = !this.searching;
            if (this.searching) {
                this.lists = new List[]{this.leftModules, this.rightModules};
                this.searchTextField.setText("");
            } else {
                this.leftModules = this.lists[0];
                this.rightModules = this.lists[1];
                this.resetModuleList();
            }
            this.searchTextField.setText("");
        }
        float pageY = 44.0f + this.CscrollAni;
        if (this.current == Category.Pages.CONFIGS) {
            boolean hovered2;
            boolean bl = RenderUtil.isHovering(this.x + width + 16.0f + 4.0f, this.y + 10.0f, 89.0f, 20.0f, mouseX, mouseY);
            if (bl) {
                this.mc.displayGuiScreen(new SavePresetScreen(this));
            }
            if (hovered2 = RenderUtil.isHovering(this.x + width + 16.0f + 96.0f, this.y + 10.0f, 89.0f, 20.0f, mouseX, mouseY)) {
                ConfigManager cfr_ignored_0 = Client.instance.configManager;
                Desktop.getDesktop().open(ConfigManager.dir);
            }
        }
        if (this.current == Category.Pages.CONFIGS) {
            Client client = Client.instance;
            float configY = this.y + 40.0f + 8.0f + 14.0f + this.scrollAni;
            for (String string : client.getConfigManager().getConfigs()) {
                boolean fuck = RenderUtil.isHovering(this.x + width + 16.0f + 6.0f + 290.0f - 6.0f, configY + 8.0f, 76.0f, 20.0f, mouseX, mouseY);
                if (fuck && mouseButton == 0) {
                    if ("modules.json".equals(string)) {
                        Client.instance.configManager.saveUserConfig(string);
                        NotificationManager.post(NotificationType.SUCCESS, "Config", "Config successfully saved.");
                    } else {
                        Client.instance.configManager.loadUserConfig(string);
                        NotificationManager.post(NotificationType.SUCCESS, "Config", "Config successfully loaded.");
                    }
                }
                configY += 42.0f;
            }
        }
        if (RenderUtil.isHovering(this.x, this.y + 44.0f, width + 10.0f, 240.0f, mouseX, mouseY)) {
            for (Category category : Category.values()) {
                pageY += 12.0f;
                for (Category.Pages cate : category.getSubPages()) {
                    if (RenderUtil.isHovering(this.x + 8.0f, this.y + pageY, width, 16.0f, mouseX, mouseY) && mouseButton == 0) {
                        if (cate != this.current) {
                            cate.animation.mouseClicked(mouseX, mouseY);
                        }
                        this.scrollAni = 0.0f;
                        this.scrollY = 0.0f;
                        this.current = cate;
                        this.dropdownItem = null;
                        this.protectArea = null;
                        this.currentEditing = null;
                        this.moduleWheel[0] = 0.0f;
                        this.moduleWheel[1] = 0.0f;
                        this.resetModuleList();
                        return;
                    }
                    pageY += 26.0f;
                }
                pageY += 4.0f;
            }
        }
        if (this.current.module && RenderUtil.isHovering(this.x + width + 16.0f + 8.0f, this.y + 40.0f, 400.0f, 400.0f, mouseX, mouseY)) {
            this.click(this.leftModules, this.x + width + 24.0f, mouseX, mouseY, mouseButton);
            this.click(this.rightModules, this.x + width + 24.0f + 198.0f, mouseX, mouseY, mouseButton);
        }
        if (mouseButton == 0 && RenderUtil.isHovering(this.x, this.y, 520.0f, 43.0f, mouseX, mouseY)) {
            this.dragX = (float)mouseX - this.x;
            this.dragY = (float)mouseY - this.y;
            this.dragging = true;
        }
    }

    public void setCurrent(Category.Pages current) {
        this.current = current;
    }

    public void resetModuleList() {
        int updateIndex;
        this.leftModules.clear();
        this.rightModules.clear();
        ArrayList<Module> allList = new ArrayList<Module>();
        if (this.searching) {
            for (Module module : Client.instance.getModuleManager().getModuleMap().values()) {
                if (!module.getName().toLowerCase().replace(" ", "").contains(this.searchTextField.getText().toLowerCase().replace(" ", ""))) continue;
                allList.add(module);
            }
        } else {
            allList.addAll(Client.instance.getModuleManager().getModsByPage(this.current));
        }
        allList.sort((o1, o2) -> o2.getValues().size() - o1.getValues().size());
        for (updateIndex = 0; updateIndex <= allList.size() - 1; updateIndex += 2) {
            this.leftModules.add(allList.get(updateIndex));
        }
        for (updateIndex = 1; updateIndex <= allList.size() - 1; updateIndex += 2) {
            this.rightModules.add(allList.get(updateIndex));
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    public static class SavePresetScreen
    extends GuiScreen {
        private final GuiScreen parent;
        private GuiTextField nameField;

        public SavePresetScreen(GuiScreen parent) {
            this.parent = parent;
        }

        @Override
        protected void keyTyped(char typedChar, int keyCode) throws IOException {
            super.keyTyped(typedChar, keyCode);
            this.nameField.textboxKeyTyped(typedChar, keyCode);
            if (keyCode == 1) {
                this.mc.displayGuiScreen(this.parent);
            }
            this.nameField.setText(this.nameField.getText().replace(" ", "").replace("#", "").replace("_NONE", ""));
        }

        @Override
        public void initGui() {
            this.nameField = new GuiTextField(0, Minecraft.getMinecraft().fontRendererObj, this.width / 2 - 100, this.height / 6 + 20, 200, 20);
            this.buttonList.add(new GuiButton(3, this.width / 2 - 100, this.height / 6 + 40 + 110, "Add"));
            this.buttonList.add(new GuiButton(4, this.width / 2 - 100, this.height / 6 + 40 + 132, "Cancel"));
        }

        @Override
        protected void actionPerformed(GuiButton button) throws IOException {
            if (button.id == 3) {
                Client.instance.configManager.saveConfig(this.nameField.getText());
                this.mc.displayGuiScreen(this.parent);
            }
            if (button.id == 4) {
                this.mc.displayGuiScreen(this.parent);
            }
        }

        @Override
        protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
            this.nameField.mouseClicked(mouseX, mouseY, mouseButton);
            super.mouseClicked(mouseX, mouseY, mouseButton);
        }

        @Override
        public void updateScreen() {
            this.nameField.updateCursorCounter();
            super.updateScreen();
        }

        @Override
        public void drawScreen(int mouseX, int mouseY, float partialTicks) {
            this.drawDefaultBackground();
            this.drawCenteredString(this.fontRendererObj, "Name", this.width / 2 - 89, this.height / 6 + 10, 0xFFFFFF);
            this.nameField.drawTextBox();
            this.drawCenteredString(this.fontRendererObj, "Adding Preset", this.width / 2, 30, 0xFFFFFF);
            super.drawScreen(mouseX, mouseY, partialTicks);
        }
    }

    public static class BindScreen
    extends GuiScreen {
        private final Module target;
        private final GuiScreen parent;

        public BindScreen(Module module, GuiScreen parent) {
            this.target = module;
            this.parent = parent;
        }

        @Override
        protected void keyTyped(char typedChar, int keyCode) throws IOException {
            super.keyTyped(typedChar, keyCode);
            if (keyCode == 1) {
                this.mc.displayGuiScreen(this.parent);
            }
            if (keyCode != 1 && keyCode != Keyboard.KEY_DELETE) {
                this.target.setKey(keyCode);
                this.mc.displayGuiScreen(this.parent);
            }
            if (keyCode == Keyboard.KEY_DELETE) {
                this.target.setKey(Keyboard.KEY_NONE);
                this.mc.displayGuiScreen(this.parent);
            }
        }

        @Override
        public void drawScreen(int mouseX, int mouseY, float partialTicks) {
            this.drawDefaultBackground();
            this.drawCenteredString(this.fontRendererObj, "Press any key to bind " + EnumChatFormatting.YELLOW + this.target.getName(), this.width / 2, 150, 0xFFFFFF);
            this.drawCenteredString(this.fontRendererObj, "Press Delete key to remove the bind.", this.width / 2, 170, 0xFFFFFF);
            super.drawScreen(mouseX, mouseY, partialTicks);
        }
    }
}

