package cc.xylitol.ui.gui.splash.utils;

import cc.xylitol.Client;
import cc.xylitol.ui.gui.splash.SplashScreen;
import cc.xylitol.ui.gui.splash.utils.AsyncContextUtils;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;

public class AsyncGLContentLoader {
    public static final int threadCount = 4;
    public static final List<LoaderThread> threads = Collections.synchronizedList(new ArrayList());
    private static final List<Runnable> preLoadTasks = Collections.synchronizedList(new ArrayList());

    public static void initLoader() {
        for (int i = 0; i < 4; ++i) {
            long subWindow = AsyncContextUtils.createSubWindow();
            LoaderThread thread = new LoaderThread(subWindow);
            thread.setName("GL Content Loader " + i);
            thread.setUncaughtExceptionHandler((t, e) -> e.printStackTrace());
            thread.setPriority(10);
            thread.start();
            threads.add(thread);
        }
        if (!preLoadTasks.isEmpty()) {
            for (Runnable r : preLoadTasks) {
                AsyncGLContentLoader.loadGLContentAsync(r);
            }
        }
        AsyncGLContentLoader.startDaemonThread();
        System.out.print("Async Content Loader Started.");
    }

    private static void startDaemonThread() {
        new Thread(() -> {
            while (true) {
                if (threads.isEmpty()) {
                    continue;
                }
                for (LoaderThread thread : threads) {
                    if (thread.tasks.isEmpty() || thread.getState() != Thread.State.WAITING) continue;
                    ConcurrentLinkedQueue<Runnable> concurrentLinkedQueue = thread.tasks;
                    synchronized (concurrentLinkedQueue) {
                        thread.tasks.notifyAll();
                    }
                }
                try {
                    Thread.sleep(5000L);
                }
                catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }, "AsyncGLContentLoader Daemon Thread").start();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void loadGLContentAsync(Runnable runnable) {
        if (SplashScreen.crashDetected && Client.instance.clientLoadFinished) {
            Minecraft.getMinecraft().addScheduledTask(runnable);
            return;
        }
        if (threads.isEmpty()) {
            preLoadTasks.add(runnable);
            return;
        }
        LoaderThread least = threads.get(0);
        for (LoaderThread thread : threads) {
            if (thread.tasks.size() < least.tasks.size()) {
                least = thread;
            }
            if (thread.tasks.isEmpty() || thread.getState() != Thread.State.WAITING) continue;
            ConcurrentLinkedQueue<Runnable> concurrentLinkedQueue = thread.tasks;
            synchronized (concurrentLinkedQueue) {
                thread.tasks.notifyAll();
            }
        }
        if (runnable == null) {
            return;
        }
        if (least.getState() == Thread.State.WAITING) {
            ConcurrentLinkedQueue<Runnable> concurrentLinkedQueue = least.tasks;
            synchronized (concurrentLinkedQueue) {
                least.tasks.notifyAll();
            }
        }
        least.tasks.add(runnable);
    }

    public static boolean isAllTasksFinished() {
        for (LoaderThread thread : threads) {
            if (thread.tasks.isEmpty()) continue;
            return false;
        }
        return true;
    }

    private static void getMaxTextureSize() {
        for (int i = 16384; i > 0; i >>= 1) {
            GL11.glTexImage2D(32868, 0, 6408, i, i, 0, 6408, 5121, (ByteBuffer)null);
            if (GL11.glGetTexLevelParameteri(32868, 0, 4096) == 0) continue;
            return;
        }
    }

    public static class LoaderThread
            extends Thread {
        public final ConcurrentLinkedQueue<Runnable> tasks = new ConcurrentLinkedQueue();
        public final long handle;

        public LoaderThread(long handle) {
            this.handle = handle;
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void run() {
            try {
                GLFW.glfwMakeContextCurrent(this.handle);
                GL.createCapabilities();
                while (Minecraft.getMinecraft().running) {
                    if (!this.tasks.isEmpty()) {
                        synchronized (SplashScreen.renderLock) {
                            final Runnable runnable = this.tasks.poll();
                            try {
                                assert runnable != null;
                                runnable.run();
                                GL11.glFlush();
                            }
                            catch (final Exception ignored) {
                                ignored.printStackTrace();
                            }
                        }
                    }
                    else {
                        synchronized (this.tasks) {
                            this.tasks.wait();
                        }
                    }
                }
            }
            catch (final Throwable $ex) {
                try {
                    throw $ex;
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
