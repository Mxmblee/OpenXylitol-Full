package cc.xylitol.ui.gui.splash.utils;

import org.lwjgl.glfw.GLFW;
import org.lwjglx.opengl.Display;

public class AsyncContextUtils {
    public static long createSubWindow() {
        GLFW.glfwWindowHint(131076, 0);
        return GLFW.glfwCreateWindow(1, 1, "SubWindow", 0L, Display.getWindow());
    }
}

