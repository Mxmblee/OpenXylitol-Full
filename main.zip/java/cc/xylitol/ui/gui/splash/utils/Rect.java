package cc.xylitol.ui.gui.splash.utils;

import cc.xylitol.ui.gui.splash.utils.RenderableEntity;
import cc.xylitol.utils.render.RenderUtil;

public class Rect
extends RenderableEntity {
    private int color;
    private RectType rectType;

    public Rect(double x, double y, double width, double height, int color, RectType type) {
        super(x, y, width, height);
        this.setColor(color);
        this.setRectType(type);
    }

    public static void draw(double x, double y, double x2, double y2, int color, RectType type) {
        if (type == RectType.EXPAND) {
            RenderUtil.drawRect(x, y, x + x2, y + y2, color);
        } else if (type == RectType.ABSOLUTE_POSITION) {
            RenderUtil.drawRect(x, y, x2, y2, color);
        }
    }

    public void draw() {
        if (this.getRectType() == RectType.EXPAND) {
            RenderUtil.drawRect(this.getX(), this.getY(), this.getX() + this.getWidth(), this.getY() + this.getHeight(), this.getColor());
        } else if (this.getRectType() == RectType.ABSOLUTE_POSITION) {
            RenderUtil.drawRect(this.getX(), this.getY(), this.getWidth(), this.getHeight(), this.getColor());
        }
    }

    public int getColor() {
        return this.color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public RectType getRectType() {
        return this.rectType;
    }

    public void setRectType(RectType rectType) {
        this.rectType = rectType;
    }

    public enum RectType {
        EXPAND,
        ABSOLUTE_POSITION

    }
}

