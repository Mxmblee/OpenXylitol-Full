package cc.xylitol.ui.gui.splash;

public class LoadingScreenRenderer {
    public void init() {
    }

    public void render(int width, int height) {
    }

    public void onGameLoadFinishedNotify() {
    }

    public boolean isLoadingScreenFinished() {
        return false;
    }
}

