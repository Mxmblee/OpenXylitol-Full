package cc.xylitol.ui.gui.splash.impl;

import cc.xylitol.ui.gui.splash.LoadingScreenRenderer;
import cc.xylitol.ui.gui.splash.utils.Image;
import cc.xylitol.ui.gui.splash.utils.Rect;
import cc.xylitol.utils.TimerUtil;
import cc.xylitol.utils.render.RenderUtil;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class GenshinImpactLoadingScreen
extends LoadingScreenRenderer {
    FadeInOutImage gs1;
    TimerUtil startTimer = new TimerUtil();
    boolean firstFrame = false;

    @Override
    public void init() {
        super.init();
        this.gs1 = new FadeInOutImage(new ResourceLocation("xylitol/gs1.png"));
    }

    @Override
    public void render(int width, int height) {
        Rect.draw(0.0, 0.0, width, height, RenderUtil.hexColor(255, 255, 255), Rect.RectType.ABSOLUTE_POSITION);
        if (!this.firstFrame) {
            this.firstFrame = true;
            this.startTimer.reset();
        }
        if (!this.startTimer.hasTimeElapsed(1000L)) {
            return;
        }
        if (!this.gs1.isFinished()) {
            this.gs1.render(width, height);
        }
    }

    @Override
    public boolean isLoadingScreenFinished() {
        return this.gs1.isFinished();
    }

    private static class FadeInOutImage {
        private final ResourceLocation img;
        float screeMaskAlpha = 0.0f;
        boolean increasing = true;
        boolean finished = false;
        boolean firstFrame = false;
        TimerUtil timer = new TimerUtil();

        public FadeInOutImage(ResourceLocation loc) {
            this.img = loc;
        }

        public void render(int width, int height) {
            if (!this.firstFrame) {
                this.firstFrame = true;
                this.timer.reset();
            }
            if (this.increasing || this.timer.hasTimeElapsed(2000L)) {
                this.screeMaskAlpha += this.increasing ? 0.003921569f : -0.003921569f;
            }
            if (!this.increasing && (double)this.screeMaskAlpha < 0.01) {
                this.finished = true;
            }
            if (this.increasing && (double)this.screeMaskAlpha > 0.99) {
                this.increasing = false;
                this.timer.reset();
            }
            GL11.glColor4f(1.0f, 1.0f, 1.0f, this.screeMaskAlpha);
            Image.draw(this.img, 0.0, 0.0, width, height, Image.Type.NoColor);
        }

        public boolean isFinished() {
            return this.finished;
        }

        public ResourceLocation getImg() {
            return this.img;
        }
    }
}

