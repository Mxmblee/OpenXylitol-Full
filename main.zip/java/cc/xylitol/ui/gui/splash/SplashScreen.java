package cc.xylitol.ui.gui.splash;

import cc.xylitol.ui.gui.splash.LoadingScreenRenderer;
import cc.xylitol.ui.gui.splash.impl.GenshinImpactLoadingScreen;
import cc.xylitol.ui.gui.splash.utils.AsyncContextUtils;
import cc.xylitol.ui.gui.splash.utils.AsyncGLContentLoader;
import cc.xylitol.ui.gui.splash.utils.Interpolations;
import cc.xylitol.ui.gui.splash.utils.Rect;
import cc.xylitol.utils.render.RenderUtil;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjglx.opengl.Display;

public class SplashScreen {
    public static final Object renderLock = new Object();
    public static final Object finishLock = new Object();
    private static Minecraft mc = Minecraft.getMinecraft();
    private static final int backgroundColor = RenderUtil.hexColor(0, 0, 0, 255);
    private static final Random random = new Random();
    private static final LoadingScreenRenderer loadingScreenRenderer = SplashScreen.getLoadingScreen();
    public static int progress = 0;
    public static String progressText = "";
    public static Thread splashThread;
    public static float alpha;
    public static boolean waiting;
    private static boolean firstFrame;
    private static Throwable threadError;
    private static int max_texture_size;
    public static boolean crashDetected;
    public static long subWindow;

    private static LoadingScreenRenderer getLoadingScreen() {
        return new GenshinImpactLoadingScreen();
    }

    public static void init() {
        subWindow = AsyncContextUtils.createSubWindow();
        GLFW.glfwMakeContextCurrent(subWindow);
        GL.createCapabilities();
        splashThread = new Thread(new Runnable(){

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void run() {
                GLFW.glfwMakeContextCurrent(Display.getWindow());
                GL.createCapabilities();
                this.initGL();
                loadingScreenRenderer.init();
                while (true) {
                    if (Display.wasResized()) {
                        this.initGL();
                    }
                    if (Display.isCloseRequested()) {
                        System.exit(0);
                    }
                    GL11.glClear(16384);
                    if (!firstFrame) {
                        firstFrame = true;
                        RenderUtil.setFrameDeltaTime(0.0);
                    }
                    Object object = renderLock;
                    synchronized (object) {
                        GlStateManager.pushAttrib();
                        Interpolations.calcFrameDelta();
                        int width = Display.getWidth();
                        int height = Display.getHeight();
                        GlStateManager.matrixMode(5889);
                        GlStateManager.loadIdentity();
                        GlStateManager.ortho(0.0, Display.getWidth(), Display.getHeight(), 0.0, 1000.0, 3000.0);
                        GlStateManager.matrixMode(5888);
                        GlStateManager.loadIdentity();
                        GlStateManager.translate(0.0f, 0.0f, -2000.0f);
                        GlStateManager.disableLighting();
                        GlStateManager.disableFog();
                        GlStateManager.disableDepth();
                        GlStateManager.enableTexture2D();
                        GlStateManager.enableAlpha();
                        GlStateManager.alphaFunc(516, 0.1f);
                        GL11.glEnable(3553);
                        loadingScreenRenderer.render(Display.getWidth(), Display.getHeight());
                        if (progress != 100) {
                            alpha = Interpolations.interpBezier(alpha * 255.0f, 0.0f, 0.1f) * 0.003921569f;
                        }
                        Rect.draw(0.0, 0.0, width, height, RenderUtil.hexColor(0, 0, 0, (int)(alpha * 255.0f)), Rect.RectType.EXPAND);
                        if (progress >= 90) {
                            RenderUtil.drawRectWH(0.0, 0.0, width, height, new Color(32, 32, 32).getRGB());
                            RenderUtil.drawLoadingCircle(width / 2, (float)height / 2.0f + 25.0f);
                        }
                        GlStateManager.enableAlpha();
                        GlStateManager.alphaFunc(516, 0.1f);
                        Display.update();
                        Display.sync(240);
                        GlStateManager.popAttrib();
                        if (waiting && loadingScreenRenderer.isLoadingScreenFinished() && AsyncGLContentLoader.isAllTasksFinished()) {
                            if (mc == null) {
                                mc = Minecraft.getMinecraft();
                            }
                            mc.displayWidth = Display.getWidth();
                            mc.displayHeight = Display.getHeight();
                            mc.resize(mc.displayWidth, mc.displayHeight);
                            GL11.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
                            GL11.glEnable(2929);
                            GL11.glDepthFunc(515);
                            GL11.glEnable(3008);
                            GL11.glAlphaFunc(516, 0.1f);
                            GLFW.glfwMakeContextCurrent(0L);
                            Object object2 = finishLock;
                            synchronized (object2) {
                                finishLock.notifyAll();
                                return;
                            }
                        }
                    }
                }
            }

            private void initGL() {
                GL11.glClearColor((float)(backgroundColor >> 16 & 0xFF) / 255.0f, (float)(backgroundColor >> 8 & 0xFF) / 255.0f, (float)(backgroundColor & 0xFF) / 255.0f, 1.0f);
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
            }
        }, "Loading Screen Thread");
        splashThread.setUncaughtExceptionHandler((t, e) -> {
            threadError = e;
        });
        splashThread.start();
        SplashScreen.checkThreadState();
    }

    private static void checkThreadState() {
        if (splashThread.getState() == Thread.State.TERMINATED || threadError != null) {
            throw new IllegalStateException("Loading Screen thread", threadError);
        }
    }

    public static void hide() {
        GlStateManager.enableTexture2D();
        GlStateManager.shadeModel(7425);
        GlStateManager.clearDepth(1.0);
        GlStateManager.enableDepth();
        GlStateManager.depthFunc(515);
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.1f);
        GlStateManager.cullFace(1029);
        GlStateManager.matrixMode(5889);
        GlStateManager.loadIdentity();
        GlStateManager.matrixMode(5888);
        SplashScreen.mc.displayWidth = Display.getWidth();
        SplashScreen.mc.displayHeight = Display.getHeight();
        mc.resize(SplashScreen.mc.displayWidth, SplashScreen.mc.displayHeight);
        GL11.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glEnable(2929);
        GL11.glDepthFunc(515);
        GL11.glEnable(3008);
        GL11.glAlphaFunc(516, 0.1f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void notifyGameLoaded() {
        block5: {
            if (crashDetected) break block5;
            loadingScreenRenderer.onGameLoadFinishedNotify();
            waiting = true;
            Object object = finishLock;
            synchronized (object) {
                try {
                    finishLock.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            try {
                Thread.sleep(500L);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            GLFW.glfwMakeContextCurrent(Display.getWindow());
            GL.createCapabilities();
            SplashScreen.hide();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void show() {
        waiting = false;
        alpha = 1.0f;
        Object object = finishLock;
        synchronized (object) {
            finishLock.notifyAll();
        }
    }

    private static int getMaxTextureSize() {
        if (max_texture_size != -1) {
            return max_texture_size;
        }
        for (int i = 16384; i > 0; i >>= 1) {
            GL11.glTexImage2D(32868, 0, 6408, i, i, 0, 6408, 5121, (ByteBuffer)null);
            if (GL11.glGetTexLevelParameteri(32868, 0, 4096) == 0) continue;
            max_texture_size = i;
            return i;
        }
        return -1;
    }

    public static void setProgress(int progress, String detail) {
        SplashScreen.progress = progress;
        progressText = detail;
        System.out.print("[Startup] " + progress + " - " + detail + "\n");
    }

    static {
        alpha = 1.0f;
        waiting = false;
        firstFrame = false;
        max_texture_size = -1;
        crashDetected = false;
    }
}

