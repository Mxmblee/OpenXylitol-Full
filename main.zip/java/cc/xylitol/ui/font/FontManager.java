package cc.xylitol.ui.font;

import cc.xylitol.Client;
import cc.xylitol.ui.font.RapeMasterFontManager;
import java.awt.Font;
import java.io.InputStream;

public class FontManager {
    private static final String locate = "express/font/";
    public static RapeMasterFontManager font10;
    public static RapeMasterFontManager font12;
    public static RapeMasterFontManager font13;
    public static RapeMasterFontManager font14;
    public static RapeMasterFontManager font15;
    public static RapeMasterFontManager font16;
    public static RapeMasterFontManager font18;
    public static RapeMasterFontManager font19;
    public static RapeMasterFontManager font20;
    public static RapeMasterFontManager font22;
    public static RapeMasterFontManager font24;
    public static RapeMasterFontManager font26;
    public static RapeMasterFontManager font28;
    public static RapeMasterFontManager font32;
    public static RapeMasterFontManager font34;
    public static RapeMasterFontManager font40;
    public static RapeMasterFontManager font42;
    public static RapeMasterFontManager font64;
    public static RapeMasterFontManager other14;
    public static RapeMasterFontManager bold18;
    public static RapeMasterFontManager bold20;
    public static RapeMasterFontManager bold26;
    public static RapeMasterFontManager bold32;
    public static RapeMasterFontManager bold12;
    public static RapeMasterFontManager bold24;
    public static RapeMasterFontManager bold38;
    public static RapeMasterFontManager bold34;
    public static RapeMasterFontManager icontestFont40;
    public static RapeMasterFontManager icontestFont35;
    public static RapeMasterFontManager icontestFont75;
    public static RapeMasterFontManager icon22;
    public static RapeMasterFontManager museo18;
    public static RapeMasterFontManager tenacitybold;
    public static RapeMasterFontManager tenacitybold18;
    public static RapeMasterFontManager tenacitybold22;
    public static RapeMasterFontManager tenacitybold34;

    public static void init() {
        font10 = FontManager.getFont("font.ttf", 10.0f);
        font12 = FontManager.getFont("font.ttf", 12.0f);
        font13 = FontManager.getFont("font.ttf", 13.0f);
        font14 = FontManager.getFont("font.ttf", 14.0f);
        font15 = FontManager.getFont("font.ttf", 15.0f);
        font16 = FontManager.getFont("font.ttf", 16.0f);
        font18 = FontManager.getFont("font.ttf", 18.0f);
        font19 = FontManager.getFont("font.ttf", 19.0f);
        font20 = FontManager.getFont("font.ttf", 20.0f);
        font22 = FontManager.getFont("font.ttf", 22.0f);
        font24 = FontManager.getFont("font.ttf", 24.0f);
        font26 = FontManager.getFont("font.ttf", 26.0f);
        font28 = FontManager.getFont("font.ttf", 28.0f);
        font32 = FontManager.getFont("font.ttf", 32.0f);
        font34 = FontManager.getFont("font.ttf", 34.0f);
        font40 = FontManager.getFont("font.ttf", 40.0f);
        font42 = FontManager.getFont("font.ttf", 42.0f);
        font64 = FontManager.getFont("font.ttf", 64.0f);
        other14 = FontManager.getFont("ico.ttf", 14.0f);
        bold26 = FontManager.getFont("bold.ttf", 26.0f);
        bold32 = FontManager.getFont("bold.ttf", 32.0f);
        bold12 = FontManager.getFont("bold.ttf", 12.0f);
        bold18 = FontManager.getFont("bold.ttf", 18.0f);
        bold20 = FontManager.getFont("bold.ttf", 20.0f);
        bold24 = FontManager.getFont("bold.ttf", 24.0f);
        bold38 = FontManager.getFont("bold.ttf", 38.0f);
        bold34 = FontManager.getFont("bold.ttf", 34.0f);
        icontestFont40 = FontManager.getFont("icont.ttf", 40.0f);
        icontestFont35 = FontManager.getFont("icont.ttf", 35.0f);
        icontestFont75 = FontManager.getFont("icont.ttf", 75.0f);
        icon22 = FontManager.getFont("iconfont.ttf", 22.0f);
        museo18 = FontManager.getFont("museo500.ttf", 18.0f);
        tenacitybold = FontManager.getFont("tenacity-bold.ttf", 20.0f);
        tenacitybold22 = FontManager.getFont("tenacity-bold.ttf", 22.0f);
        tenacitybold34 = FontManager.getFont("tenacity-bold.ttf", 34.0f);
        tenacitybold18 = FontManager.getFont("tenacity-bold.ttf", 18.0f);
    }

    private static RapeMasterFontManager getFont(String fontName, float fontSize) {
        Font font = null;
        try {
            InputStream inputStream = Client.class.getResourceAsStream("/assets/minecraft/xylitol/font/" + fontName);
            assert (inputStream != null);
            font = Font.createFont(0, inputStream);
            font = font.deriveFont(fontSize);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return new RapeMasterFontManager(font);
    }
}

