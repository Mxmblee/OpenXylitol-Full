package cc.xylitol.module;

import cc.xylitol.Client;
import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventKey;
import cc.xylitol.event.impl.events.EventRender2D;
import cc.xylitol.module.impl.combat.AntiFireBall;
import cc.xylitol.module.impl.combat.AutoWeapon;
import cc.xylitol.module.impl.combat.BackTrack;
import cc.xylitol.module.impl.combat.KillAura;
import cc.xylitol.module.impl.combat.TickBase;
import cc.xylitol.module.impl.combat.Velocity;
import cc.xylitol.module.impl.misc.AntiBot;
import cc.xylitol.module.impl.misc.AutoPlay;
import cc.xylitol.module.impl.misc.IRC;
import cc.xylitol.module.impl.misc.MemoryFix;
import cc.xylitol.module.impl.misc.OffHandAbuse;
import cc.xylitol.module.impl.misc.Protocol;
import cc.xylitol.module.impl.move.NoSlow;
import cc.xylitol.module.impl.move.TargetStrafe;
import cc.xylitol.module.impl.player.Blink;
import cc.xylitol.module.impl.player.SpeedMine;
import cc.xylitol.module.impl.render.BlockAnimation;
import cc.xylitol.module.impl.render.BlockESP;
import cc.xylitol.module.impl.render.Camera;
import cc.xylitol.module.impl.render.Chams;
import cc.xylitol.module.impl.render.ClickGUI;
import cc.xylitol.module.impl.render.ESP;
import cc.xylitol.module.impl.render.HUD;
import cc.xylitol.module.impl.render.Health;
import cc.xylitol.module.impl.render.ItemPhysics;
import cc.xylitol.module.impl.render.KillEffect;
import cc.xylitol.module.impl.render.MotionBlur;
import cc.xylitol.module.impl.render.Projectile;
import cc.xylitol.module.impl.world.AutoPearl;
import cc.xylitol.module.impl.world.Disabler;
import cc.xylitol.module.impl.world.PlayerTracker;
import cc.xylitol.module.impl.world.Scaffold;
import cc.xylitol.module.impl.world.Stuck;
import cc.xylitol.value.Value;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import top.fl0wowp4rty.phantomshield.annotations.license.RegisterLock;

@RegisterLock
public class ModuleManager {
    private final Map<String, Module> moduleMap = new HashMap<String, Module>();
    private boolean enabledNeededMod = true;

    public void init() {
        Client.instance.eventManager.register(this);
        Client.instance.hudManager.init();
        this.addModule(new KillAura());
        this.addModule(new Velocity());
        this.addModule(new NoClickDelay());
        this.addModule(new SuperKnockBack());
        this.addModule(new AutoSoup());
        this.addModule(new AutoWeapon());
        this.addModule(new AntiFireBall());
        this.addModule(new BackTrack());
        this.addModule(new TickBase());
        this.addModule(new Criticals());
        this.addModule(new Sneak());
        this.addModule(new Sprint());
        this.addModule(new Eagle());
        this.addModule(new NoWeb());
        this.addModule(new NoLiquid());
        this.addModule(new Spider());
        this.addModule(new FastLadder());
        this.addModule(new GuiMove());
        this.addModule(new NoSlow());
        this.addModule(new Speed());
        this.addModule(new TargetStrafe());
        this.addModule(new InvCleaner());
        this.addModule(new ChestStealer());
        this.addModule(new FastPlace());
        this.addModule(new Blink());
        this.addModule(new SpeedMine());
        this.addModule(new AutoTool());
        this.addModule(new Phase());
        this.addModule(new NoFall());
        this.addModule(new Disabler());
        this.addModule(new Scaffold());
        this.addModule(new ChestAura());
        this.addModule(new Stuck());
        this.addModule(new AutoPearl());
        this.addModule(new PlayerTracker());
        this.addModule(new Test());
        this.addModule(new Breaker());
        this.addModule(new Ambience());
        this.addModule(new ClickGUI());
        this.addModule(new HUD());
        this.addModule(new Chams());
        this.addModule(new BlockAnimation());
        this.addModule(new Camera());
        this.addModule(new Projectile());
        this.addModule(new Health());
        this.addModule(new XRay());
        this.addModule(new KillEffect());
        this.addModule(new ItemPhysics());
        this.addModule(new ESP());
        this.addModule(new MotionBlur());
        this.addModule(new BlockESP());
        this.addModule(new AntiBot());
        this.addModule(new Teams());
        this.addModule(new Protocol());
        this.addModule(new AutoPlay());
        this.addModule(new OffHandAbuse());
        this.addModule(new ChatBypass());
        this.addModule(new KillInsults());
        this.addModule(new MemoryFix());
        this.addModule(new IRC());
        this.addModule(new NameProtect());
        this.sortModulesByName();
    }

    public void sortModulesByName() {
        ArrayList<Map.Entry<String, Module>> entryList = new ArrayList<Map.Entry<String, Module>>(this.moduleMap.entrySet());
        entryList.sort(Comparator.comparing(entry -> entry.getValue().getName()));
        this.moduleMap.clear();
        for (Map.Entry entry2 : entryList) {
            this.moduleMap.put((String)entry2.getKey(), (Module)entry2.getValue());
        }
    }

    public void addModule(Module module) {
        for (Field field : module.getClass().getDeclaredFields()) {
            try {
                field.setAccessible(true);
                Object obj = field.get(module);
                if (!(obj instanceof Value)) continue;
                module.getValues().add((Value)obj);
            }
            catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        this.moduleMap.put(module.getClass().getSimpleName(), module);
    }

    public Map<String, Module> getModuleMap() {
        return this.moduleMap;
    }

    public <T extends Module> T getModule(Class<T> cls) {
        return cls.cast(this.moduleMap.get(cls.getSimpleName()));
    }

    public Module getModule(String name) {
        for (Module module : this.moduleMap.values()) {
            if (!module.getName().equalsIgnoreCase(name)) continue;
            return module;
        }
        return null;
    }

    public boolean haveModules(Category category, String key) {
        return this.moduleMap.values().stream().filter(module -> module.getCategory() == category).anyMatch(module -> module.getName().toLowerCase().replaceAll(" ", "").contains(key));
    }

    @EventTarget
    public void onKey(EventKey e) {
        this.moduleMap.values().stream().filter(module -> module.getKey() == e.getKey() && e.getKey() != -1).forEach(Module::toggle);
    }

    public List<Module> getModsByPage(Category.Pages m) {
        return this.moduleMap.values().stream().filter(module -> module.getCategory().pages == m).collect(Collectors.toList());
    }

    public List<Module> getModsByCategory(Category m) {
        return this.moduleMap.values().stream().filter(module -> module.getCategory() == m).collect(Collectors.toList());
    }

    @EventTarget
    private void on2DRender(EventRender2D e) {
        if (this.enabledNeededMod) {
            this.enabledNeededMod = false;
            this.moduleMap.values().stream().filter(Module::isDefaultOn).forEach(module -> module.setState(true));
        }
    }
}

