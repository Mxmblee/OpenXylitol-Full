package cc.xylitol.module;

import cc.xylitol.Client;
import cc.xylitol.module.Category;
import cc.xylitol.ui.hud.notification.NotificationManager;
import cc.xylitol.ui.hud.notification.NotificationType;
import cc.xylitol.utils.render.animation.Animation;
import cc.xylitol.utils.render.animation.Direction;
import cc.xylitol.utils.render.animation.impl.DecelerateAnimation;
import cc.xylitol.value.Value;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumChatFormatting;

public class Module {
    protected static final Minecraft mc = Minecraft.getMinecraft();
    public float cGUIAnimation = 0.0f;
    private final Animation animation = new DecelerateAnimation(250, 1.0).setDirection(Direction.BACKWARDS);
    private final List<Value<?>> values = new ArrayList();
    public String name;
    public String suffix;
    public Category category;
    public boolean state = false;
    public boolean defaultOn = false;
    public int key = -1;
    public double progress;

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
        this.suffix = "";
    }

    public void toggle() {
        this.setState(!this.state);
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        return Client.instance.moduleManager.getModule(clazz);
    }

    public boolean getState() {
        return this.state;
    }

    public void setState(boolean state) {
        if (this.state == state) {
            return;
        }
        this.state = state;
        if (Module.mc.theWorld != null) {
            Module.mc.theWorld.playSound(Module.mc.thePlayer.posX, Module.mc.thePlayer.posY, Module.mc.thePlayer.posZ, "random.click", 0.5f, state ? 0.6f : 0.5f, false);
        }
        if (state) {
            Client.instance.eventManager.register(this);
            NotificationManager.post(NotificationType.SUCCESS, "Module", "Enabled " + this.name);
            this.onEnable();
        } else {
            Client.instance.eventManager.unregister(this);
            NotificationManager.post(NotificationType.DISABLE, "Module", "Disabled " + this.name);
            this.onDisable();
        }
    }

    public void setStateSilent(boolean state) {
        if (this.state == state) {
            return;
        }
        this.state = state;
        if (Module.mc.theWorld != null) {
            Module.mc.theWorld.playSound(Module.mc.thePlayer.posX, Module.mc.thePlayer.posY, Module.mc.thePlayer.posZ, "random.click", 0.5f, state ? 0.6f : 0.5f, false);
        }
        if (state) {
            Client.instance.eventManager.register(this);
        } else {
            Client.instance.eventManager.unregister(this);
        }
    }

    public List<Value<?>> getValues() {
        return this.values;
    }

    public String getSuffix() {
        return this.suffix;
    }

    public void setSuffix(Object obj) {
        String suffix = obj.toString();
        this.suffix = suffix.isEmpty() ? suffix : String.format("\u00a7f%s\u00a77", EnumChatFormatting.GRAY + suffix);
    }

    public boolean isDefaultOn() {
        return this.defaultOn;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public double getProgress() {
        return this.progress;
    }

    public void setProgress(double progress) {
        this.progress = progress;
    }

    public String getName() {
        return this.name;
    }

    public Category getCategory() {
        return this.category;
    }

    public float getCGUIAnimation() {
        return this.cGUIAnimation;
    }

    public Animation getAnimation() {
        return this.animation;
    }
}

