package cc.xylitol.module.impl.player;

import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventHigherPacketSend;
import cc.xylitol.event.impl.events.EventTick;
import cc.xylitol.event.impl.events.EventUpdate;
import cc.xylitol.event.impl.events.EventWorldLoad;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.ui.hud.notification.NotificationManager;
import cc.xylitol.ui.hud.notification.NotificationType;
import cc.xylitol.utils.PacketUtil;
import cc.xylitol.value.impl.BoolValue;
import cc.xylitol.value.impl.ModeValue;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;

public class Blink
extends Module {
    private final LinkedList<List<Packet<?>>> packets = new LinkedList();
    public EntityOtherPlayerMP fakePlayer;
    private int ticks;
    public ModeValue modeValue = new ModeValue("Mode", new String[]{"Simple", "Slow Release", "Delay"}, "Slow Release");
    public BoolValue autoclose = new BoolValue("AutoClose", false);
    public BoolValue auraValue = new BoolValue("Aura Support", true);

    public Blink() {
        super("Blink", Category.Player);
    }

    @Override
    public void onEnable() {
        if (Blink.mc.thePlayer == null) {
            return;
        }
        this.packets.clear();
        this.packets.add(new ArrayList());
        this.ticks = 0;
        this.fakePlayer = new EntityOtherPlayerMP(Blink.mc.theWorld, Blink.mc.thePlayer.getGameProfile());
        this.fakePlayer.clonePlayer(Blink.mc.thePlayer, true);
        this.fakePlayer.copyLocationAndAnglesFrom(Blink.mc.thePlayer);
        this.fakePlayer.rotationYawHead = Blink.mc.thePlayer.rotationYawHead;
        Blink.mc.theWorld.addEntityToWorld(-1337, this.fakePlayer);
    }

    @EventTarget
    public void onWorld(EventWorldLoad event) {
        this.setState(false);
    }

    @Override
    public void onDisable() {
        this.packets.forEach(this::sendTick);
        this.packets.clear();
        try {
            if (this.fakePlayer != null) {
                Blink.mc.theWorld.removeEntity(this.fakePlayer);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @EventTarget
    public void onPacket(EventHigherPacketSend event) {
        Packet packet = event.getPacket();
        if (PacketUtil.isCPacket(packet)) {
            mc.addScheduledTask(() -> this.packets.getLast().add(packet));
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onTick(EventTick event) {
        ++this.ticks;
        this.packets.add(new ArrayList());
        switch (this.modeValue.getValue()) {
            case "Delay": {
                if (this.packets.size() <= 100) break;
                this.poll();
                break;
            }
            case "Slow Release": {
                if (this.packets.size() <= 100 && this.ticks % 5 != 0) break;
                this.poll();
            }
        }
    }

    private void poll() {
        if (this.packets.isEmpty()) {
            return;
        }
        this.sendTick(this.packets.getFirst());
        this.packets.removeFirst();
    }

    @Override
    public String getSuffix() {
        return this.modeValue.getValue();
    }

    private void sendTick(List<Packet<?>> tick) {
        tick.forEach(packet -> {
            mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(packet);
            this.handleFakePlayerPacket(packet);
        });
    }

    private void handleFakePlayerPacket(Packet<?> packet) {
        if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition) {
            C03PacketPlayer.C04PacketPlayerPosition position = (C03PacketPlayer.C04PacketPlayerPosition)packet;
            this.fakePlayer.setPositionAndRotation2(position.x, position.y, position.z, this.fakePlayer.rotationYaw, this.fakePlayer.rotationPitch, 3, true);
            this.fakePlayer.onGround = position.isOnGround();
        } else if (packet instanceof C03PacketPlayer.C05PacketPlayerLook) {
            C03PacketPlayer.C05PacketPlayerLook rotation = (C03PacketPlayer.C05PacketPlayerLook)packet;
            this.fakePlayer.setPositionAndRotation2(this.fakePlayer.posX, this.fakePlayer.posY, this.fakePlayer.posZ, rotation.getYaw(), rotation.getPitch(), 3, true);
            this.fakePlayer.onGround = rotation.isOnGround();
            this.fakePlayer.rotationYawHead = rotation.getYaw();
            this.fakePlayer.rotationYaw = rotation.getYaw();
            this.fakePlayer.rotationPitch = rotation.getPitch();
        } else if (packet instanceof C03PacketPlayer.C06PacketPlayerPosLook) {
            C03PacketPlayer.C06PacketPlayerPosLook positionRotation = (C03PacketPlayer.C06PacketPlayerPosLook)packet;
            this.fakePlayer.setPositionAndRotation2(positionRotation.x, positionRotation.y, positionRotation.z, positionRotation.getYaw(), positionRotation.getPitch(), 3, true);
            this.fakePlayer.onGround = positionRotation.isOnGround();
            this.fakePlayer.rotationYawHead = positionRotation.getYaw();
            this.fakePlayer.rotationYaw = positionRotation.getYaw();
            this.fakePlayer.rotationPitch = positionRotation.getPitch();
        } else if (packet instanceof C0BPacketEntityAction) {
            C0BPacketEntityAction action = (C0BPacketEntityAction)packet;
            if (action.getAction() == C0BPacketEntityAction.Action.START_SPRINTING) {
                this.fakePlayer.setSprinting(true);
            } else if (action.getAction() == C0BPacketEntityAction.Action.STOP_SPRINTING) {
                this.fakePlayer.setSprinting(false);
            } else if (action.getAction() == C0BPacketEntityAction.Action.START_SNEAKING) {
                this.fakePlayer.setSneaking(true);
            } else if (action.getAction() == C0BPacketEntityAction.Action.STOP_SNEAKING) {
                this.fakePlayer.setSneaking(false);
            }
        } else if (packet instanceof C0APacketAnimation) {
            C0APacketAnimation animation = (C0APacketAnimation)packet;
            this.fakePlayer.swingItem();
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (Blink.mc.thePlayer.hurtTime > 0 && this.autoclose.getValue().booleanValue()) {
            this.setState(false);
            NotificationManager.post(NotificationType.SUCCESS, "Blink", "AutoClose!", 5.0f);
        }
    }
}

