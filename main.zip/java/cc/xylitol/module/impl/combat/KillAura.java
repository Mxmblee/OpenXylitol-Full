package cc.xylitol.module.impl.combat;

import cc.xylitol.Client;
import cc.xylitol.event.annotations.EventPriority;
import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventAttack;
import cc.xylitol.event.impl.events.EventKey;
import cc.xylitol.event.impl.events.EventMotion;
import cc.xylitol.event.impl.events.EventRender3D;
import cc.xylitol.event.impl.events.EventTick;
import cc.xylitol.event.impl.events.EventUpdate;
import cc.xylitol.manager.PacketManager;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.module.impl.misc.AntiBot;
import cc.xylitol.module.impl.misc.IRC;
import cc.xylitol.module.impl.move.TargetStrafe;
import cc.xylitol.module.impl.player.Blink;
import cc.xylitol.module.impl.world.Scaffold;
import cc.xylitol.module.impl.world.Stuck;
import cc.xylitol.ui.hud.notification.NotificationManager;
import cc.xylitol.ui.hud.notification.NotificationType;
import cc.xylitol.utils.TimerUtil;
import cc.xylitol.utils.player.RotationUtil;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.animation.Animation;
import cc.xylitol.utils.render.animation.Direction;
import cc.xylitol.utils.render.animation.impl.EaseBackIn;
import cc.xylitol.value.impl.BoolValue;
import cc.xylitol.value.impl.ColorValue;
import cc.xylitol.value.impl.ModeValue;
import cc.xylitol.value.impl.NumberValue;
import com.viaversion.viarewind.protocol.protocol1_8to1_9.Protocol1_8To1_9;
import com.viaversion.viarewind.utils.PacketUtil;
import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import javax.vecmath.Vector3d;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.viamcp.fixes.AttackOrder;
import org.lwjgl.opengl.GL11;
import org.lwjglx.input.Keyboard;
import org.lwjglx.util.vector.Vector2f;
import top.fl0wowp4rty.phantomshield.annotations.Native;

public class KillAura
extends Module {
    public ModeValue priority = new ModeValue("Priority", new String[]{"Range", "Fov", "Angle", "Health"}, "Range");
    public ModeValue mode = new ModeValue("Mode", new String[]{"Single", "Switch", "Multi"}, "Single");
    public ModeValue attackMode = new ModeValue("Attack Mode", new String[]{"Pre", "Post"}, "Post");
    public ModeValue rotMode = new ModeValue("Rotation Mode", new String[]{"Normal", "HvH", "Smart"}, "HvH");
    public ModeValue abMode = new ModeValue("AutoBlock mode", new String[]{"Off", "Grim", "Key Bind", "UseItem", "Watchdog", "Watchdog 1.9+", "Fake"}, "Grim");
    public ModeValue markMode = new ModeValue("Mark mode", new String[]{"Off", "Box", "Circle", "Plat", "Exhi"}, "Box");
    public NumberValue cps = new NumberValue("CPS", 13.0, 1.0, 20.0, 1.0);
    public NumberValue range = new NumberValue("Range", 3.0, 2.0, 6.0, 0.01);
    public NumberValue blockRange = new NumberValue("Block Range", 4.0, 2.0, 6.0, 0.01);
    public NumberValue scanRange = new NumberValue("Scan Range", 5.0, 2.0, 6.0, 0.01);
    public NumberValue switchDelay = new NumberValue("Switch delay", 500.0, 0.0, 1000.0, 10.0);
    public BoolValue moveFixValue = new BoolValue("Movement Fix", true);
    public BoolValue strictValue = new BoolValue("Follow Player (Strict)", false, () -> this.moveFixValue.getValue());
    public BoolValue strictAltValue = new BoolValue("Toggle strict when alt key", false, () -> this.moveFixValue.getValue() && this.strictValue.isAvailable());
    public BoolValue rayCastValue = new BoolValue("RayCast", false);
    public BoolValue playerValue = new BoolValue("Player", true);
    public BoolValue animalValue = new BoolValue("Animal", false);
    public BoolValue mobValue = new BoolValue("Mob", false);
    public BoolValue invisibleValue = new BoolValue("Invisible", true);
    public NumberValue markAlpha = new NumberValue("MarkAlpha", 255.0, 1.0, 255.0, 1.0);
    public ColorValue markColor = new ColorValue("MarkColor", Color.RED.getRGB());
    private final TimerUtil switchTimer = new TimerUtil();
    private final TimerUtil attackTimer = new TimerUtil();
    public List<Entity> targets = new ArrayList<Entity>();
    private final Animation auraESPAnim = new EaseBackIn(300, 1.0, 1.0f);
    public static EntityLivingBase target;
    public static boolean isBlocking;
    public static boolean renderBlocking;
    private boolean blink = false;
    private boolean isPlayerBlocking = false;
    private boolean isUsingItem = false;
    private boolean canAutoBlock = false;
    private boolean canAttack = false;
    private int swordTicks = 0;
    public int index = 0;
    public TargetStrafe ts;

    public KillAura() {
        super("KillAura", Category.Combat);
    }

    public String getTag() {
        return this.mode.getValue();
    }

    private boolean heldSword() {
        return KillAura.mc.thePlayer.getHeldItem() != null && KillAura.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword;
    }

    private boolean canAttack() {
        if (KillAura.mc.currentScreen instanceof GuiContainer) {
            return false;
        }
        if (this.swordTicks == 0 && KillAura.mc.objectMouseOver.typeOfHit.equals(MovingObjectPosition.MovingObjectType.BLOCK)) {
            return !KillAura.mc.gameSettings.keyBindAttack.isKeyDown();
        }
        return true;
    }

    private boolean canAutoBlock() {
        if (!this.abMode.is("Watchdog")) {
            return false;
        }
        if (!this.heldSword()) {
            return false;
        }
        return this.swordTicks >= 3;
    }

    @Override
    public void onEnable() {
        this.switchTimer.reset();
        isBlocking = false;
        target = null;
        this.targets.clear();
        if (this.abMode.is("Watchdog")) {
            Client.instance.packetManager.blink(false, PacketManager.BlinkFlag.AUTO_BLOCK);
        }
        this.ts = this.getModule(TargetStrafe.class);
        if (isBlocking && !this.abMode.getValue().equals("Off")) {
            this.stopBlocking(true);
        }
        this.index = 0;
        this.auraESPAnim.setDirection(Direction.FORWARDS);
    }

    @Override
    public void onDisable() {
        if (this.abMode.is("Watchdog")) {
            Client.instance.packetManager.blink(false, PacketManager.BlinkFlag.AUTO_BLOCK);
        }
        this.auraESPAnim.setDirection(Direction.BACKWARDS);
        if (KillAura.mc.thePlayer == null) {
            return;
        }
        target = null;
        this.targets.clear();
        if (isBlocking && !this.abMode.getValue().equals("Off")) {
            this.stopBlocking(true);
        }
        isBlocking = false;
        this.index = 0;
    }

    @EventTarget
    public void onTick(EventTick e) {
        if (this.abMode.is("Watchdog")) {
            if (KillAura.mc.thePlayer == null) {
                return;
            }
            this.isPlayerBlocking = KillAura.mc.thePlayer.isBlocking();
            this.isUsingItem = KillAura.mc.thePlayer.isUsingItem();
            this.swordTicks = this.heldSword() ? ++this.swordTicks : 0;
            this.canAutoBlock = this.canAutoBlock();
            if (!this.canAutoBlock) {
                this.isPlayerBlocking = false;
            }
            this.canAttack = this.canAttack();
        }
    }

    @EventTarget
    @EventPriority(value=12)
    public void onKey(EventKey e) {
        if (this.getState() && e.getKey() == Keyboard.KEY_LMENU && this.moveFixValue.getValue().booleanValue() && this.strictValue.isAvailable() && this.strictAltValue.getValue().booleanValue()) {
            this.strictValue.set(!this.strictValue.getValue());
            NotificationManager.post(NotificationType.INFO, "Movement", "Set to " + (this.strictValue.getValue() ? "Strict" : "Silent") + ".");
        }
    }

    @EventTarget
    public void onR3D(EventRender3D event) {
        if (this.targets.isEmpty() || "Off".equals(this.markMode.getValue())) {
            this.auraESPAnim.setDirection(Direction.BACKWARDS);
            return;
        }
        double partialTicks = event.getPartialTicks();
        double baseX = KillAura.target.prevPosX + (KillAura.target.posX - KillAura.target.prevPosX) * partialTicks - RenderManager.renderPosX;
        double baseY = KillAura.target.prevPosY + (KillAura.target.posY - KillAura.target.prevPosY) * partialTicks - RenderManager.renderPosY;
        double baseZ = KillAura.target.prevPosZ + (KillAura.target.posZ - KillAura.target.prevPosZ) * partialTicks - RenderManager.renderPosZ;
        double tickOffsetX = (KillAura.target.posX - KillAura.target.prevPosX) * (double)event.getPartialTicks();
        double tickOffsetY = (KillAura.target.posY - KillAura.target.prevPosY) * (double)event.getPartialTicks();
        double tickOffsetZ = (KillAura.target.posZ - KillAura.target.prevPosZ) * (double)event.getPartialTicks();
        double playerMotionOffsetX = KillAura.mc.thePlayer.motionX + 0.01;
        double playerMotionOffsetY = KillAura.mc.thePlayer.motionY - 0.005;
        double playerMotionOffsetZ = KillAura.mc.thePlayer.motionZ + 0.01;
        int color = KillAura.target.hurtTime > 3 ? new Color(235, 40, 40, 35).getRGB() : new Color(150, 255, 40, 35).getRGB();
        int color2 = KillAura.target.hurtTime > 3 ? new Color(235, 40, 40, 75).getRGB() : (KillAura.target.hurtTime < 3 ? new Color(150, 255, 40, 35).getRGB() : new Color(255, 255, 255, 75).getRGB());
        this.auraESPAnim.setDirection(Direction.FORWARDS);
        for (Entity ent : this.targets) {
            AxisAlignedBB axisAlignedBB = target.getEntityBoundingBox();
            GlStateManager.pushMatrix();
            double translateX = baseX + tickOffsetX + playerMotionOffsetX;
            double translateY = baseY + tickOffsetY + playerMotionOffsetY;
            double translateZ = baseZ + tickOffsetZ + playerMotionOffsetZ;
            switch (this.markMode.getValue()) {
                case "Box": {
                    GL11.glShadeModel(7425);
                    GL11.glHint(3154, 4354);
                    KillAura.mc.entityRenderer.setupCameraTransform(KillAura.mc.timer.renderPartialTicks, 2);
                    RenderUtil.renderBoundingBox((EntityLivingBase)ent, this.markColor.getColorC(), this.markAlpha.getValue().intValue());
                    break;
                }
                case "Circle": {
                    if (KillAura.mc.thePlayer.ticksExisted <= 5 || target == null || KillAura.mc.theWorld == null) break;
                    RenderUtil.drawCircle(target, 0.66, true);
                    break;
                }
                case "Plat": {
                    GlStateManager.translate(translateX, translateY, translateZ);
                    RenderUtil.drawAxisAlignedBB(new AxisAlignedBB(axisAlignedBB.minX - KillAura.target.posX, axisAlignedBB.minY + (double)target.getEyeHeight() + 0.11 - KillAura.target.posY, axisAlignedBB.minZ - KillAura.target.posZ, axisAlignedBB.maxX - KillAura.target.posX, axisAlignedBB.maxY - 0.13 - KillAura.target.posY, axisAlignedBB.maxZ - KillAura.target.posZ), false, color);
                    break;
                }
                case "Exhi": {
                    GlStateManager.translate(translateX, translateY, translateZ);
                    AxisAlignedBB offsetBB = axisAlignedBB.offset(-KillAura.target.posX, -KillAura.target.posY, -KillAura.target.posZ).expand(0.1, 0.1, 0.1).offset(0.0, 0.1, 0.0);
                    RenderUtil.drawAxisAlignedBB(offsetBB, true, color2);
                }
            }
            RenderUtil.resetColor();
            GlStateManager.popMatrix();
        }
    }

    @EventTarget
    public void rotations(EventUpdate event) {
        if (!this.targets.isEmpty()) {
            if (this.index >= this.targets.size()) {
                this.index = 0;
            }
            target = (double)KillAura.mc.thePlayer.getClosestDistanceToEntity(this.targets.get(this.index)) <= this.range.getValue() ? (EntityLivingBase)this.targets.get(this.index) : (EntityLivingBase)this.targets.get(0);
        }
        if (target != null && (double)KillAura.mc.thePlayer.getClosestDistanceToEntity(target) <= this.range.getValue()) {
            float[] rotation = this.getRot();
            Client.instance.rotationManager.setRotation(new Vector2f(rotation[0], rotation[1]), 180.0f, !this.ts.getState() && this.moveFixValue.getValue(), this.strictValue.getValue());
        }
    }

    private float[] getRot() {
        float[] rot = RotationUtil.getHVHRotation(target, this.range.getValue());
        switch (this.rotMode.getValue()) {
            case "Normal": {
                Vector2f vec = RotationUtil.calculate(target, true, this.range.getValue(), this.range.getValue(), true, true);
                rot = new float[]{vec.x, vec.y};
                break;
            }
            case "HvH": {
                rot = RotationUtil.getHVHRotation(target, this.range.getValue());
                break;
            }
            case "Smart": {
                double yDist = KillAura.target.posY - KillAura.mc.thePlayer.posY;
                Vector3d targetPos = yDist >= 1.7 ? new Vector3d(KillAura.target.posX, KillAura.target.posY, KillAura.target.posZ) : (yDist <= -1.7 ? new Vector3d(KillAura.target.posX, KillAura.target.posY + (double)target.getEyeHeight(), KillAura.target.posZ) : new Vector3d(KillAura.target.posX, KillAura.target.posY + (double)(target.getEyeHeight() / 2.0f), KillAura.target.posZ));
                Vector2f temp = RotationUtil.getRotationFromEyeToPoint(targetPos);
                rot = new float[]{temp.getX(), temp.getY()};
            }
        }
        return rot;
    }

    @EventTarget
    @EventPriority(value=9)
    public void onUpdate(EventMotion event) {
        if (this.getModule(Blink.class).getState() && !this.getModule(Blink.class).auraValue.getValue().booleanValue() || this.getModule(Scaffold.class).getState() || this.getModule(Stuck.class).getState()) {
            return;
        }
        this.setSuffix(this.targets.size());
        if (event.isPre() && !this.mode.getValue().contains("Watchdog") && target == null) {
            this.stopBlocking(true);
        }
        if (event.isPre()) {
            if (KillAura.mc.thePlayer.isDead || KillAura.mc.thePlayer.isSpectator()) {
                return;
            }
            this.targets = this.getTargets(this.scanRange.getValue());
            if (this.targets.isEmpty()) {
                target = null;
            }
            this.sortTargets();
            if ((this.targets.size() > 1 && this.mode.getValue().equals("Switch") || this.mode.getValue().equals("Multi")) && (this.switchTimer.delay(this.switchDelay.getValue().longValue()) || this.mode.getValue().equals("Multi"))) {
                ++this.index;
                this.switchTimer.reset();
            }
            if (this.targets.size() > 1 && this.mode.getValue().equals("Single")) {
                if ((double)KillAura.mc.thePlayer.getClosestDistanceToEntity(target) > this.scanRange.getValue()) {
                    ++this.index;
                } else if (KillAura.target.isDead) {
                    ++this.index;
                }
            }
        }
    }

    @EventTarget
    @EventPriority(value=0)
    public void blockEvent(EventMotion e) {
        if (e.isPost() && this.attackMode.is("Pre") && !this.abMode.getValue().equals("Off") && !this.abMode.getValue().contains("Watchdog") && this.shouldBlock()) {
            this.doBlock();
        }
    }

    public boolean shouldAttack() {
        MovingObjectPosition movingObjectPosition = KillAura.mc.objectMouseOver;
        return (double)(KillAura.mc.thePlayer.canEntityBeSeen(target) ? KillAura.mc.thePlayer.getClosestDistanceToEntity(target) : KillAura.mc.thePlayer.getDistanceToEntity(target)) <= this.range.getValue() && (!this.rayCastValue.getValue() || !KillAura.mc.thePlayer.canEntityBeSeen(target) || this.rayCastValue.getValue() && movingObjectPosition != null && movingObjectPosition.entityHit == target);
    }

    private boolean isUsingItem() {
        return KillAura.mc.thePlayer.isUsingItem() && !this.heldSword();
    }

    public boolean shouldBlock() {
        return target != null && !this.targets.isEmpty() && (double)KillAura.mc.thePlayer.getClosestDistanceToEntity(target) <= this.blockRange.getValue();
    }

    private void attack() {
        if (this.abMode.is("Watchdog")) {
            if (this.isUsingItem()) {
                return;
            }
            if (this.isUsingItem != KillAura.mc.thePlayer.isUsingItem() || this.isPlayerBlocking != KillAura.mc.thePlayer.isBlocking()) {
                return;
            }
        }
        if (this.shouldAttack() && this.attackTimer.hasTimeElapsed(700L / (long) this.cps.getValue().intValue())) {
            Client.instance.eventManager.call(new EventAttack(target, true));
            AttackOrder.sendFixedAttackByPacket(KillAura.mc.thePlayer, target);
            Client.instance.eventManager.call(new EventAttack(target, false));
            this.attackTimer.reset();
        }
    }

    private boolean isAnyTargetInAutoBlockRange() {
        for (Entity entity : KillAura.mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityLivingBase) || !this.isValid(entity, this.scanRange.getValue()) || !((double)KillAura.mc.thePlayer.getClosestDistanceToEntity(entity) <= this.blockRange.getValue())) continue;
            return true;
        }
        return false;
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (this.abMode.is("Watchdog") && event.isPost()) {
            if (this.blink) {
                this.blink = false;
                Client.instance.packetManager.blink(true, PacketManager.BlinkFlag.AUTO_BLOCK);
            }
            return;
        }
        if (event.isPre()) {
            if (this.abMode.is("Watchdog")) {
                boolean block = false;
                if (this.canAttack && this.canAutoBlock) {
                    if (this.isAnyTargetInAutoBlockRange()) {
                        if (this.isPlayerBlocking && KillAura.mc.thePlayer.isBlocking()) {
                            this.unblock();
                        } else if (KillAura.mc.thePlayer.ticksExisted % 3 == 0) {
                            Client.instance.packetManager.blink(false, PacketManager.BlinkFlag.AUTO_BLOCK);
                            block = true;
                            this.blink = true;
                        }
                        isBlocking = true;
                        renderBlocking = true;
                    } else {
                        Client.instance.packetManager.blink(false, PacketManager.BlinkFlag.AUTO_BLOCK);
                        isBlocking = false;
                        renderBlocking = false;
                    }
                } else {
                    Client.instance.packetManager.blink(false, PacketManager.BlinkFlag.AUTO_BLOCK);
                    isBlocking = false;
                    renderBlocking = false;
                }
                if (block && !this.isPlayerBlocking && !KillAura.mc.thePlayer.isBlocking()) {
                    this.block();
                }
            }
            if (this.attackMode.is("Pre") && target != null) {
                this.attack();
            }
            if (this.abMode.is("Watchdog 1.9+") && this.shouldBlock()) {
                this.doBlock();
            }
        } else if (this.abMode.is("Watchdog 1.9+") && !this.shouldBlock()) {
            this.stopBlocking(true);
        }
        if (event.isPost() && this.attackMode.is("Post") && target != null) {
            if (!this.abMode.getValue().equals("Off") && !this.abMode.getValue().contains("Watchdog") && this.shouldBlock()) {
                this.doBlock();
            }
            this.attack();
            if (!this.abMode.getValue().equals("Off") && !this.abMode.getValue().contains("Watchdog") && this.shouldBlock()) {
                this.doBlock();
            }
        }
    }

    private void unblock() {
        if (this.isPlayerBlocking) {
            cc.xylitol.utils.PacketUtil.send(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
            KillAura.mc.thePlayer.stopUsingItem();
        }
    }

    private void block() {
        cc.xylitol.utils.PacketUtil.send(new C08PacketPlayerBlockPlacement(KillAura.mc.thePlayer.getHeldItem()));
        KillAura.mc.thePlayer.setItemInUse(KillAura.mc.thePlayer.getHeldItem(), KillAura.mc.thePlayer.getHeldItem().getMaxItemUseDuration());
    }

    public boolean isSword() {
        return Minecraft.getMinecraft().thePlayer.getCurrentEquippedItem() != null && Minecraft.getMinecraft().thePlayer.getCurrentEquippedItem().getItem() instanceof ItemSword;
    }

    private void stopBlocking(boolean render) {
        if (this.isSword() && renderBlocking) {
            switch (this.abMode.getValue()) {
                case "Key Bind": {
                    KillAura.mc.gameSettings.keyBindUseItem.pressed = false;
                    KillAura.mc.thePlayer.sendQueue.addToSendQueue(new C0EPacketClickWindow(0, 36, 0, 2, new ItemStack(Block.getBlockById(166)), (short) 0));
                    break;
                }
                case "Grim": 
                case "Watchdog 1.9+": {
                    KillAura.mc.gameSettings.keyBindUseItem.pressed = false;
                    cc.xylitol.utils.PacketUtil.sendPacketNoEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                    break;
                }
            }
            if (render) {
                renderBlocking = false;
            }
            isBlocking = false;
        }
    }

    @Native
    private void doBlock() {
        if (this.isSword() && !this.getModule(Blink.class).getState()) {
            switch (this.abMode.getValue()) {
                case "Grim": {
                    KillAura.mc.playerController.sendUseItem(KillAura.mc.thePlayer, KillAura.mc.theWorld, KillAura.mc.thePlayer.getHeldItem());
                    PacketWrapper use_0 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                    use_0.write(Type.VAR_INT, 0);
                    PacketUtil.sendToServer(use_0, Protocol1_8To1_9.class, true, true);
                    PacketWrapper use_1 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                    use_1.write(Type.VAR_INT, 1);
                    PacketUtil.sendToServer(use_1, Protocol1_8To1_9.class, true, true);
                    break;
                }
                case "Key Bind": {
                    KillAura.mc.gameSettings.keyBindUseItem.pressed = true;
                    break;
                }
                case "UseItem": {
                    KillAura.mc.playerController.sendUseItem(KillAura.mc.thePlayer, KillAura.mc.theWorld, KillAura.mc.thePlayer.getCurrentEquippedItem());
                    break;
                }
                case "Watchdog 1.9+": {
                    cc.xylitol.utils.PacketUtil.sendPacketNoEvent(new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, KillAura.mc.thePlayer.inventory.getCurrentItem(), 0.0f, 0.0f, 0.0f));
                    PacketWrapper use = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                    use.write((Type)Type.VAR_INT, (Object)1);
                    PacketUtil.sendToServer(use, Protocol1_8To1_9.class, true, true);
                }
            }
            if (!this.abMode.is("Fake")) {
                isBlocking = true;
            }
            renderBlocking = true;
        }
    }

    public List<Entity> getTargets(Double value) {
        return Minecraft.getMinecraft().theWorld.loadedEntityList.stream().filter(e -> (double)KillAura.mc.thePlayer.getClosestDistanceToEntity(e) <= value && this.isValid(e, value)).collect(Collectors.toList());
    }

    public boolean isValid(Entity entity, double range) {
        if ((double)KillAura.mc.thePlayer.getClosestDistanceToEntity(entity) > range) {
            return false;
        }
        if (entity.isInvisible() && !this.invisibleValue.getValue().booleanValue()) {
            return false;
        }
        if (!entity.isEntityAlive()) {
            return false;
        }
        if (entity == Minecraft.getMinecraft().thePlayer || entity.isDead || Minecraft.getMinecraft().thePlayer.getHealth() == 0.0f) {
            return false;
        }
        if ((entity instanceof EntityMob || entity instanceof EntityGhast || entity instanceof EntityGolem || entity instanceof EntityDragon || entity instanceof EntitySlime) && this.mobValue.getValue().booleanValue()) {
            return true;
        }
        if ((entity instanceof EntitySquid || entity instanceof EntityBat || entity instanceof EntityVillager) && this.animalValue.getValue().booleanValue()) {
            return true;
        }
        if (entity instanceof EntityAnimal && this.animalValue.getValue().booleanValue()) {
            return true;
        }
        if (AntiBot.isServerBot(entity)) {
            return false;
        }
        if (entity.getEntityId() == -8 || entity.getEntityId() == -1337) {
            return false;
        }
        if (Teams.isSameTeam(entity)) {
            return false;
        }
        if (this.getModule(IRC.class).getState() && IRC.isFriend(entity)) {
            return false;
        }
        return entity instanceof EntityPlayer && this.playerValue.getValue();
    }

    private void sortTargets() {
        if (!this.targets.isEmpty()) {
            EntityPlayerSP thePlayer = KillAura.mc.thePlayer;
            switch (this.priority.getValue()) {
                case "Range": {
                    this.targets.sort((o1, o2) -> (int)(o1.getClosestDistanceToEntity(thePlayer) - o2.getClosestDistanceToEntity(thePlayer)));
                    break;
                }
                case "Fov": {
                    this.targets.sort(Comparator.comparingDouble(o -> this.getDistanceBetweenAngles(thePlayer.rotationPitch, RotationUtil.getRotationsNeeded(o)[0])));
                    break;
                }
                case "Angle": {
                    this.targets.sort((o1, o2) -> {
                        float[] rot1 = RotationUtil.getRotationsNeeded(o1);
                        float[] rot2 = RotationUtil.getRotationsNeeded(o2);
                        return (int)(thePlayer.rotationYaw - rot1[0] - (thePlayer.rotationYaw - rot2[0]));
                    });
                    break;
                }
                case "Health": {
                    this.targets.sort((o1, o2) -> (int)(((EntityLivingBase)o1).getHealth() - ((EntityLivingBase)o2).getHealth()));
                }
            }
        }
    }

    private float getDistanceBetweenAngles(float angle1, float angle2) {
        float agl = Math.abs(angle1 - angle2) % 360.0f;
        if (agl > 180.0f) {
            agl = 0.0f;
        }
        return agl - 1.0f;
    }

    static {
        isBlocking = false;
        renderBlocking = false;
    }
}

