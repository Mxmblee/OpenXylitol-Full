package cc.xylitol.module.impl.combat;

import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventMotion;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.module.impl.combat.KillAura;
import cc.xylitol.utils.DebugUtil;
import cc.xylitol.utils.player.RaytraceUtil;
import cc.xylitol.utils.player.RotationUtil;
import cc.xylitol.value.impl.BoolValue;
import cc.xylitol.value.impl.ModeValue;
import cc.xylitol.value.impl.NumberValue;
import java.io.IOException;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Vec3;

public class TickBase
extends Module {
    public static TickBase INSTANCE;
    private final ModeValue mode = new ModeValue("Mode", new String[]{"RayCast", "Radius"}, "RayCast");
    private final NumberValue minDistance = new NumberValue("MinDistance", 3.0, 0.0, 4.0, 0.1);
    private final NumberValue maxDistance = new NumberValue("MaxDistance", 4.0, 3.0, 7.0, 0.1);
    private final ModeValue rangeMode = new ModeValue("RangeMode", new String[]{"Setting", "Smart"}, "Smart");
    private final NumberValue maxTimeValue = new NumberValue("MaxTime", 3.0, 0.0, 20.0, 1.0);
    private final NumberValue delayValue = new NumberValue("Delay", 5.0, 0.0, 20.0, 1.0);
    private final NumberValue maxHurtTimeValue = new NumberValue("TargetMaxHurtTime", 2.0, 0.0, 10.0, 1.0);
    private final BoolValue onlyKillAura = new BoolValue("OnlyKillAura", true);
    private final BoolValue auraClick = new BoolValue("AuraClick", true);
    private final BoolValue onlyPlayer = new BoolValue("OnlyPlayer", true);
    private final BoolValue debug = new BoolValue("Debug", false);
    private final BoolValue betterAnimation = new BoolValue("BetterAnimation", true);
    private final BoolValue reverseValue = new BoolValue("Reverse", false);
    private final NumberValue maxReverseRange = new NumberValue("MaxReverseRange", 2.8, 1.0, 4.0, 0.1);
    private final NumberValue minReverseRange = new NumberValue("MinReverseRange", 2.5, 1.0, 4.0, 0.1);
    private final NumberValue reverseTime = new NumberValue("ReverseStopTime", 3.0, 1.0, 10.0, 1.0);
    private final NumberValue reverseTickTime = new NumberValue("ReverseTickTime", 3.0, 0.0, 10.0, 1.0);
    private final NumberValue reverseDelay = new NumberValue("ReverseDelay", 5.0, 0.0, 20.0, 1.0);
    private final NumberValue reverseTargetMaxHurtTime = new NumberValue("ReverseTargetMaxHurtTime", 3.0, 0.0, 10.0, 1.0);
    private KillAura killAura;
    private static boolean working;
    private static boolean stopWorking;
    private static double lastNearest;
    private static int cooldown;
    private static int freezeTicks;
    private static boolean reverseFreeze;
    private static boolean firstAnimation;

    public TickBase() {
        super("TickBase", Category.Combat);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        this.killAura = this.getModule(KillAura.class);
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (event.getEventState() == EventMotion.EventState.PRE) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP thePlayer = mc.thePlayer;
        if (this.onlyKillAura.get().booleanValue() && !this.killAura.getState()) {
            return;
        }
        if (this.mode.get().equals("RayCast")) {
            Entity entity = RaytraceUtil.raycastEntity(this.maxDistance.get() + 1.0, new RaytraceUtil.IEntityFilter(){

                @Override
                public boolean canRaycast(Entity entity) {
                    return entity != null && entity instanceof EntityLivingBase && (!TickBase.this.onlyPlayer.get() || entity instanceof EntityPlayer);
                }
            });
            if (entity == null || !(entity instanceof EntityLivingBase)) {
                lastNearest = 10.0;
                return;
            }
            Vec3 vecEyes = thePlayer.getPositionEyes(1.0f);
            Vec3 predictEyes = this.rangeMode.get().equals("Smart") ? thePlayer.getPositionEyes((float)(this.maxTimeValue.get() + 1.0)) : thePlayer.getPositionEyes(3.0f);
            AxisAlignedBB entityBox = entity.getEntityBoundingBox().expands(entity.getCollisionBorderSize(), true, true);
            Vec3 box = RotationUtil.getNearestPointBB(vecEyes, entityBox);
            Vec3 box2 = RotationUtil.getNearestPointBB(predictEyes, entity instanceof EntityOtherPlayerMP ? entityBox.offset(((EntityOtherPlayerMP)entity).getOtherPlayerMPX() - entity.posX, ((EntityOtherPlayerMP)entity).getOtherPlayerMPY() - entity.posY, ((EntityOtherPlayerMP)entity).getOtherPlayerMPZ() - entity.posZ) : entityBox);
            double range = box.distanceTo(vecEyes);
            if (!this.killAura.isValid(entity, range)) {
                return;
            }
            double afterRange = box2.distanceTo(predictEyes);
            if (!working && this.reverseValue.get().booleanValue() && range <= this.maxReverseRange.get() && range >= this.minReverseRange.get() && cooldown <= 0 && (double)((EntityLivingBase)entity).hurtTime <= this.reverseTargetMaxHurtTime.get()) {
                freezeTicks = this.reverseTime.get().intValue();
                firstAnimation = false;
                reverseFreeze = true;
                return;
            }
            if (range < this.minDistance.get()) {
                stopWorking = true;
            } else if ((this.rangeMode.get().equals("Smart") && range > this.minDistance.get() && afterRange < this.minDistance.get() && afterRange < range || this.rangeMode.get().equals("Setting") && range <= this.maxDistance.get() && range < lastNearest && afterRange < range) && (double)((EntityLivingBase)entity).hurtTime <= this.maxHurtTimeValue.get()) {
                stopWorking = false;
                this.foundTarget();
            }
            lastNearest = range;
        } else {
            List<Entity> entityList = mc.theWorld.getEntitiesWithinAABBExcludingEntity(thePlayer, thePlayer.getEntityBoundingBox().expands(this.maxDistance.get() + 1.0, true, true));
            if (!entityList.isEmpty()) {
                Vec3 vecEyes = thePlayer.getPositionEyes(1.0f);
                Vec3 afterEyes = this.rangeMode.get().equals("Smart") ? thePlayer.getPositionEyes((float)(this.maxTimeValue.get() + 1.0)) : thePlayer.getPositionEyes(3.0f);
                boolean targetFound = false;
                boolean targetInRange = false;
                double nearest = 10.0;
                for (Entity entity : entityList) {
                    if (!(entity instanceof EntityLivingBase) || this.onlyPlayer.get().booleanValue() && !(entity instanceof EntityPlayer)) continue;
                    AxisAlignedBB entityBox = entity.getEntityBoundingBox().expands(entity.getCollisionBorderSize(), true, true);
                    Vec3 box = RotationUtil.getNearestPointBB(vecEyes, entityBox);
                    Vec3 box2 = RotationUtil.getNearestPointBB(afterEyes, entity instanceof EntityOtherPlayerMP ? entityBox.offset(((EntityOtherPlayerMP)entity).getOtherPlayerMPX() - entity.posX, ((EntityOtherPlayerMP)entity).getOtherPlayerMPY() - entity.posY, ((EntityOtherPlayerMP)entity).getOtherPlayerMPZ() - entity.posZ) : entityBox);
                    double range = box.distanceTo(vecEyes);
                    if (!this.killAura.isValid(entity, range)) continue;
                    double afterRange = box2.distanceTo(afterEyes);
                    if (!working && this.reverseValue.get().booleanValue() && range <= this.maxReverseRange.get() && range >= this.minReverseRange.get() && cooldown <= 0 && (double)((EntityLivingBase)entity).hurtTime <= this.reverseTargetMaxHurtTime.get()) {
                        freezeTicks = this.reverseTime.get().intValue();
                        firstAnimation = false;
                        reverseFreeze = true;
                        return;
                    }
                    if (range < this.minDistance.get()) {
                        targetInRange = true;
                        break;
                    }
                    if (range <= this.maxDistance.get() && afterRange < range && (double)((EntityLivingBase)entity).hurtTime <= this.maxHurtTimeValue.get()) {
                        targetFound = true;
                    }
                    nearest = Math.min(nearest, range);
                }
                if (targetInRange) {
                    stopWorking = true;
                } else if (targetFound && nearest < lastNearest) {
                    stopWorking = false;
                    this.foundTarget();
                }
                lastNearest = nearest;
            } else {
                lastNearest = 10.0;
            }
        }
    }

    public void foundTarget() {
        if (cooldown <= 0 && freezeTicks == 0 && this.maxTimeValue.get() != 0.0) {
            cooldown = this.delayValue.get().intValue();
            working = true;
            freezeTicks = 0;
            if (this.betterAnimation.get()) {
                firstAnimation = false;
            }

            while((double)freezeTicks <= this.maxTimeValue.get() - (double)(this.auraClick.get() ? 1 : 0) && !stopWorking) {
                ++freezeTicks;

                try {
                    mc.runTick();
                } catch (IOException var3) {
                    throw new RuntimeException(var3);
                }
            }

            if (this.debug.get()) {
                DebugUtil.log("Timer-ed");
            }

            if (this.auraClick.get()) {
                ++freezeTicks;

                try {
                    mc.runTick();
                } catch (IOException var2) {
                    throw new RuntimeException(var2);
                }

                if (this.debug.get()) {
                    DebugUtil.log("Clicked");
                }
            }

            stopWorking = false;
            working = false;
        }
    }

    public boolean handleTick() {
        if (working || freezeTicks < 0) {
            return true;
        }
        if (this.getState() && freezeTicks > 0) {
            --freezeTicks;
            return true;
        }
        if (reverseFreeze) {
            reverseFreeze = false;
            working = true;
            for (int time = this.reverseTickTime.get().intValue(); time > 0; --time) {
                try {
                    mc.runTick();
                    continue;
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            working = false;
            cooldown = this.reverseDelay.get().intValue();
        }
        if (cooldown > 0) {
            --cooldown;
        }
        return false;
    }

    public boolean freezeAnimation() {
        if (freezeTicks != 0) {
            if (!firstAnimation) {
                firstAnimation = true;
                return false;
            }
            return true;
        }
        return false;
    }

    static {
        working = false;
        stopWorking = false;
        lastNearest = 10.0;
        cooldown = 0;
        freezeTicks = 0;
        reverseFreeze = true;
        firstAnimation = true;
    }
}

