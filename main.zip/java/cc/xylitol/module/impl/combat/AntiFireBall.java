package cc.xylitol.module.impl.combat;

import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventMotion;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.utils.TimerUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.network.play.client.C02PacketUseEntity;

public class AntiFireBall
extends Module {
    public static final TimerUtil timer = new TimerUtil();

    public AntiFireBall() {
        super("AntiFireBall", Category.Combat);
    }

    @EventTarget
    public void onUpdate(EventMotion event) {
        for (Entity entity : AntiFireBall.mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityFireball) || !((double)AntiFireBall.mc.thePlayer.getDistanceToEntity(entity) < 6.0) || !timer.hasTimeElapsed(0L)) continue;
            mc.getNetHandler().getNetworkManager().sendPacket(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
            AntiFireBall.mc.thePlayer.swingItem();
        }
    }
}

