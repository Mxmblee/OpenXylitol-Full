package cc.xylitol.module.impl.combat;

import cc.xylitol.Client;
import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventAttack;
import cc.xylitol.event.impl.events.EventLivingUpdate;
import cc.xylitol.event.impl.events.EventMotion;
import cc.xylitol.event.impl.events.EventPacket;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.module.impl.combat.KillAura;
import cc.xylitol.ui.hud.notification.NotificationManager;
import cc.xylitol.ui.hud.notification.NotificationType;
import cc.xylitol.utils.PacketUtil;
import cc.xylitol.utils.TimerUtil;
import cc.xylitol.utils.player.RaytraceUtil;
import cc.xylitol.value.impl.BoolValue;
import cc.xylitol.value.impl.ModeValue;
import cc.xylitol.value.impl.NumberValue;
import javax.vecmath.Vector2d;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.WorldSettings;
import net.vialoadingbase.ViaLoadingBase;
import net.viamcp.fixes.AttackOrder;
import top.fl0wowp4rty.phantomshield.annotations.Native;

@Native
public class Velocity
extends Module {
    private final ModeValue mode = new ModeValue("Mode", new String[]{"Grim", "Watchdog", "Watchdog Ignore"}, "Grim");
    private final BoolValue flagCheckValue = new BoolValue("Flag Check", false);
    public NumberValue flagTicksValue = new NumberValue("Flag Ticks", 6.0, 0.0, 30.0, 1.0);
    public BoolValue debugMessageValue = new BoolValue("Flag Message", false);
    private final BoolValue fireCheckValue = new BoolValue("FireCheck", false);
    private final BoolValue waterCheckValue = new BoolValue("WaterCheck", false);
    private final BoolValue fallCheckValue = new BoolValue("FallCheck", false);
    private final BoolValue raycastValue = new BoolValue("Ray cast", false);
    private final BoolValue bwValue = new BoolValue("Bed wars", false);
    private final TimerUtil timer = new TimerUtil();
    private final TimerUtil flagtimer = new TimerUtil();
    public static boolean velocityOverrideSprint = false;
    private boolean velocityInput;
    private boolean grim_1_17Velocity;
    private boolean attacked;
    private double reduceXZ;
    private int flags;
    private S12PacketEntityVelocity velocityPacket;

    public Velocity() {
        super("Velocity", Category.Combat);
    }

    @Override
    public void onEnable() {
        this.velocityInput = false;
        this.attacked = false;
    }

    @EventTarget
    public void onPre(EventMotion event) {
        if (event.isPre() && this.mode.is("Watchdog")) {
            if (Velocity.mc.thePlayer.isInWater() || Velocity.mc.thePlayer.isInLava()) {
                return;
            }
            if (Velocity.mc.thePlayer.hurtTime > 8) {
                Velocity.mc.thePlayer.motionX = (double)(-MathHelper.sin(Velocity.mc.thePlayer.rotationYaw)) * 0.5;
                Velocity.mc.thePlayer.motionZ = (double)MathHelper.cos(Velocity.mc.thePlayer.rotationYaw) * 0.5;
            } else if (this.timer.hasTimeElapsed(80L)) {
            }
        }
    }

    @EventTarget
    public void onUpdate(EventLivingUpdate event) {
        this.setSuffix(this.mode.is("Grim") ? (ViaLoadingBase.getInstance().getTargetVersion().getVersion() >= 755 ? "Grim1.17+" : "Reduce") : this.mode.getValue());
        switch (this.mode.getValue()) {
            case "Grim": {
                if (this.grim_1_17Velocity) {
                    PacketUtil.sendPacketNoEvent(new C03PacketPlayer.C06PacketPlayerPosLook(Velocity.mc.thePlayer.posX, Velocity.mc.thePlayer.posY, Velocity.mc.thePlayer.posZ, Velocity.mc.thePlayer.rotationYaw, Velocity.mc.thePlayer.rotationPitch, Velocity.mc.thePlayer.onGround));
                    PacketUtil.sendPacketNoEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, new BlockPos(Velocity.mc.thePlayer).up(), EnumFacing.DOWN));
                    PacketUtil.sendPacketNoEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, new BlockPos(Velocity.mc.thePlayer).up(), EnumFacing.DOWN));
                    this.grim_1_17Velocity = false;
                }
                if (this.flagCheckValue.getValue().booleanValue() && this.flags > 0) {
                    --this.flags;
                }
                if (ViaLoadingBase.getInstance().getTargetVersion().getVersion() > 47) {
                    if (!this.velocityInput) break;
                    if (this.attacked) {
                        Velocity.mc.thePlayer.motionX *= this.reduceXZ;
                        Velocity.mc.thePlayer.motionZ *= this.reduceXZ;
                        this.attacked = false;
                    }
                    if (Velocity.mc.thePlayer.hurtTime != 0) break;
                    this.velocityInput = false;
                    break;
                }
                if (Velocity.mc.thePlayer.hurtTime <= 0 || !Velocity.mc.thePlayer.onGround) break;
                Velocity.mc.thePlayer.addVelocity(-1.3E-10, -1.3E-10, -1.3E-10);
                Velocity.mc.thePlayer.setSprinting(false);
            }
        }
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (Velocity.mc.thePlayer == null) {
            return;
        }
        Packet packet = event.getPacket();
        if (event.getPacket() instanceof S08PacketPlayerPosLook) {
            this.flagtimer.reset();
            if (this.flagCheckValue.getValue().booleanValue()) {
                this.flags = this.flagTicksValue.getValue().intValue();
                if (this.debugMessageValue.getValue().booleanValue()) {
                    NotificationManager.post(NotificationType.WARNING, "Velocity", "Flagged! Disabled Velocity 1s");
                }
            }
        }
        if (event.getPacket() instanceof S12PacketEntityVelocity) {
            if (this.mode.is("Grim")) {
                if (this.flags != 0) {
                    return;
                }
                if (Velocity.mc.thePlayer.isDead) {
                    return;
                }
                if (Velocity.mc.currentScreen instanceof GuiGameOver) {
                    return;
                }
                if (Velocity.mc.playerController.getCurrentGameType() == WorldSettings.GameType.SPECTATOR) {
                    return;
                }
                if (Velocity.mc.thePlayer.isOnLadder()) {
                    return;
                }
                if (Velocity.mc.thePlayer.isBurning() && this.fireCheckValue.getValue().booleanValue()) {
                    return;
                }
                if (Velocity.mc.thePlayer.isInWater() && this.waterCheckValue.getValue().booleanValue()) {
                    return;
                }
                if ((double)Velocity.mc.thePlayer.fallDistance > 1.5 && this.fallCheckValue.getValue().booleanValue()) {
                    return;
                }
                if (this.flagCheckValue.getValue().booleanValue() && !this.flagtimer.hasTimeElapsed(1000L)) {
                    return;
                }
                if (Velocity.mc.thePlayer.isEatingOrDrinking()) {
                    return;
                }
            }
            if (((S12PacketEntityVelocity)event.getPacket()).getEntityID() == Velocity.mc.thePlayer.getEntityId()) {
                S12PacketEntityVelocity s12 = (S12PacketEntityVelocity)event.getPacket();
                switch (this.mode.getValue()) {
                    case "Grim": {
                        EntityLivingBase target;
                        if (ViaLoadingBase.getInstance().getTargetVersion().getVersion() >= 755) {
                            event.setCancelled(true);
                            this.grim_1_17Velocity = true;
                            break;
                        }
                        double horizontalStrength = new Vector2d(s12.getMotionX(), s12.getMotionZ()).length();
                        if (horizontalStrength <= 1000.0) {
                            return;
                        }
                        this.velocityInput = true;
                        this.velocityPacket = s12;
                        this.attacked = false;
                        Entity entity = null;
                        this.reduceXZ = 1.0;
                        MovingObjectPosition result = RaytraceUtil.rayCast(Client.instance.rotationManager.lastServerRotation, 3.2, 0.0f, Velocity.mc.thePlayer, true);
                        if (result != null && result.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY) {
                            entity = result.entityHit;
                        }
                        if (entity == null && !this.raycastValue.getValue().booleanValue() && (target = KillAura.target) != null && target.getDistanceSqToEntity(Velocity.mc.thePlayer) <= 9.5) {
                            entity = KillAura.target;
                        }
                        if (entity == null) break;
                        boolean state = Velocity.mc.thePlayer.serverSprintState;
                        if (!state) {
                            PacketUtil.send(new C0BPacketEntityAction(Velocity.mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                        }
                        Client.instance.eventManager.call(new EventAttack(entity, true));
                        Client.instance.eventManager.call(new EventAttack(entity, false));
                        int count = this.bwValue.getValue() ? 6 : 12;
                        for (int i = 1; i <= count; ++i) {
                            AttackOrder.sendFixedAttackByPacket(Velocity.mc.thePlayer, entity);
                        }
                        velocityOverrideSprint = true;
                        Velocity.mc.thePlayer.serverSprintState = true;
                        Velocity.mc.thePlayer.setSprinting(true);
                        this.attacked = true;
                        this.reduceXZ = this.getMotion(this.velocityPacket);
                        break;
                    }
                    case "Watchdog": {
                        if (Velocity.mc.thePlayer.onGround) {
                            Velocity.mc.thePlayer.jump();
                        }
                        this.timer.reset();
                        break;
                    }
                    case "Watchdog Ignore": {
                        event.setCancelled(true);
                        if (!Velocity.mc.thePlayer.onGround && !((double)s12.getMotionY() / 8000.0 < 0.2) && !((double)s12.getMotionY() / 8000.0 > 0.41995)) break;
                        Velocity.mc.thePlayer.motionY = (double)s12.getMotionY() / 8000.0;
                    }
                }
            }
        }
        if (packet instanceof S27PacketExplosion && ViaLoadingBase.getInstance().getTargetVersion().getVersion() >= 755) {
            event.setCancelled(true);
            this.grim_1_17Velocity = true;
        }
    }

    private double getMotion(S12PacketEntityVelocity packetEntityVelocity) {
        double strength = new Vec3(packetEntityVelocity.getMotionX(), packetEntityVelocity.getMotionY(), packetEntityVelocity.getMotionZ()).lengthVector();
        double motionNoXZ = strength >= 20000.0 ? (Velocity.mc.thePlayer.onGround ? 0.05425 : 0.065) : (strength >= 5000.0 ? (Velocity.mc.thePlayer.onGround ? 0.01625 : 0.0452) : 0.0075);
        return motionNoXZ;
    }
}

