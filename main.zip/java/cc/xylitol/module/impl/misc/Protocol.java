package cc.xylitol.module.impl.misc;

import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.value.impl.ModeValue;

public class Protocol
extends Module {
    public static ModeValue mode = new ModeValue("Mode", new String[]{"Hyt"}, "Hyt");

    public Protocol() {
        super("Protocol", Category.Misc);
    }
}

