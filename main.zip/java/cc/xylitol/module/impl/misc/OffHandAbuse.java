package cc.xylitol.module.impl.misc;

import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventKey;
import cc.xylitol.event.impl.events.EventMotion;
import cc.xylitol.event.impl.events.EventPacket;
import cc.xylitol.event.impl.events.EventRender2D;
import cc.xylitol.event.impl.events.EventTick;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.utils.DebugUtil;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.RoundedUtil;
import cc.xylitol.utils.render.animation.AnimationUtils;
import cc.xylitol.utils.render.animation.impl.RippleAnimation;
import cc.xylitol.utils.render.shader.ShaderElement;
import com.viaversion.viarewind.protocol.protocol1_8to1_9.Protocol1_8To1_9;
import com.viaversion.viarewind.utils.PacketUtil;
import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import java.awt.Color;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.lwjglx.input.Keyboard;

public class OffHandAbuse
extends Module {
    private ItemStack offHand;
    private boolean eat = true;
    private int progress = 0;
    private boolean eating = false;
    private float x;
    private float y;
    private float width;
    private float progressRender;
    private final RippleAnimation rippleAnimation = new RippleAnimation();

    public OffHandAbuse() {
        super("OffHandAbuse", Category.Misc);
    }

    @Override
    public void onEnable() {
        DebugUtil.log("Press F switch to Off hand, Press Z switch to Eat");
    }

    @EventTarget
    public void onTick(EventKey event) {
        if (event.getKey() == Keyboard.KEY_F) {
            BlockPos playerBlock = new BlockPos(OffHandAbuse.mc.thePlayer.posX, OffHandAbuse.mc.thePlayer.posY - 1.0, OffHandAbuse.mc.thePlayer.posZ);
            ItemStack current = OffHandAbuse.mc.thePlayer.getCurrentEquippedItem();
            if (current != null || this.offHand != null) {
                OffHandAbuse.mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.SWAP_HELD_ITEMS, playerBlock, EnumFacing.UP));
                this.offHand = current;
            }
        }
        if (event.getKey() == Keyboard.KEY_Z) {
            this.eat = true;
        }
    }

    @EventTarget
    public void onUpdate(EventTick event) {
        if (this.eat) {
            this.progress = 0;
        }
        ++this.progress;
        if (this.progress > 60) {
            this.rippleAnimation.mouseClicked(this.x + 10.0f, this.y + 10.0f);
            this.eating = false;
            this.progress = 0;
        }
    }

    @EventTarget
    public void onUpdate(EventMotion event) {
        if (this.offHand != null && this.eat) {
            this.eat = false;
            PacketWrapper useItem = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
            useItem.write((Type)Type.VAR_INT, (Object)1);
            PacketUtil.sendToServer(useItem, Protocol1_8To1_9.class, true, true);
            this.eating = true;
        }
    }

    @EventTarget
    public void onRender2D(EventRender2D event) {
        if (this.offHand != null) {
            this.x = AnimationUtils.animate(!this.eating ? (float)event.getScaledResolution().getScaledWidth() / 2.0f - 91.0f - 20.0f : (float)event.getScaledResolution().getScaledWidth() / 2.0f - 42.0f, this.x, 0.5f);
            this.y = AnimationUtils.animate(!this.eating ? (float)(event.getScaledResolution().getScaledHeight() - 20) : (float)event.getScaledResolution().getScaledHeight() / 2.0f + 20.0f, this.y, 0.5f);
            this.width = AnimationUtils.animate(this.eating ? 86.0f : 20.0f, this.width, 0.5f);
            this.progressRender = AnimationUtils.animate(this.progress, this.progressRender, 0.5f);
            ShaderElement.addBlurTask(() -> RoundedUtil.drawRound(this.x - 2.0f, this.y - 2.0f, this.width, 20.0f, 4.0f, false, new Color(0, 0, 0, 255)));
            ShaderElement.addBloomTask(() -> RoundedUtil.drawRound(this.x - 2.0f, this.y - 2.0f, this.width, 20.0f, 4.0f, false, new Color(0, 0, 0, 255)));
            this.rippleAnimation.draw(() -> RoundedUtil.drawRound(this.x - 2.0f, this.y - 2.0f, this.width, 20.0f, 4.0f, false, new Color(0, 0, 0, 100)));
            RoundedUtil.drawRound(this.x - 2.0f, this.y - 2.0f, this.width, 20.0f, 4.0f, false, new Color(0, 0, 0, 100));
            if (this.eating) {
                RoundedUtil.drawRound(this.x + 20.0f, this.y + 3.0f, 60.0f, 10.0f, 4.0f, false, new Color(0, 0, 0, 60));
                RoundedUtil.drawRound(this.x + 20.0f, this.y + 3.0f, this.progressRender, 10.0f, 4.0f, false, Color.WHITE);
            }
            RenderUtil.drawItemStack(this.offHand, (int)this.x, (int)this.y);
        }
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        S2FPacketSetSlot packetSetSlot;
        if (event.getPacket() instanceof S2FPacketSetSlot && (packetSetSlot = (S2FPacketSetSlot)event.getPacket()).func_149173_d() == 45) {
            this.offHand = packetSetSlot.func_149174_e();
        }
    }
}

