package cc.xylitol.module.impl.misc;

import cc.xylitol.Client;
import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventPacket;
import cc.xylitol.event.impl.events.EventTick;
import cc.xylitol.irc.ClientType;
import cc.xylitol.irc.IPacketListener;
import cc.xylitol.irc.IRCClient;
import cc.xylitol.irc.IRCUser;
import cc.xylitol.irc.packet.Packet;
import cc.xylitol.irc.packet.Packet01Login;
import cc.xylitol.irc.packet.Packet02Chat;
import cc.xylitol.irc.packet.Packet07ChangeIGN;
import cc.xylitol.irc.packet.Packet08CustomPayload;
import cc.xylitol.irc.packet.PacketFFDisconnect;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.ui.hud.notification.NotificationManager;
import cc.xylitol.ui.hud.notification.NotificationType;
import cc.xylitol.utils.DebugUtil;
import cc.xylitol.utils.TimerUtil;
import cc.xylitol.value.impl.BoolValue;
import java.io.IOException;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.C01PacketChatMessage;
import net.minecraft.network.play.client.C02PacketUseEntity;
import top.fl0wowp4rty.phantomshield.annotations.Native;

public class IRC
extends Module {
    public static IRCClient client;
    private static final Pattern pattern;
    private final BoolValue reportUsername = new BoolValue("Share username", true);
    private String ingameName;
    private final TimerUtil timer = new TimerUtil();

    public IRC() {
        super("IRC", Category.Misc);
        client.addListener(new IPacketListener(){

            @Override
            public void handlePacket(Packet packet) {
                if (packet instanceof Packet01Login) {
                    DebugUtil.log("IRC connected.Please use !<message> to chat in IRC.");
                    DebugUtil.log("IRC\u5df2\u8fde\u63a5\u3002\u8bf7\u5728\u6d88\u606f\u524d\u52a0\u4e2a\u82f1\u6587\u53f9\u53f7(!)\u53d1\u9001IRC\u6d88\u606f\u3002\u4f8b\u5982\uff1a!\u6765\u4e70silencefix");
                    NotificationManager.post(NotificationType.SUCCESS, "IRC", "Logged in.");
                }
                if (packet instanceof Packet02Chat) {
                    IRC.this.sendMessage(((Packet02Chat)packet).getMessage());
                }
                if (packet instanceof PacketFFDisconnect) {
                    IRC.this.sendMessage("\u00a7eDisconnected: " + ((PacketFFDisconnect)packet).getReason() + ", Reconnecting...");
                }
                if (packet instanceof Packet08CustomPayload) {
                    IRC.this.handleCustomPayload((Packet08CustomPayload)packet);
                }
            }
        });
    }

    @Override
    public void onEnable() {
        this.connect();
    }

    @Native
    private void connect() {
        new Thread(() -> {
            try {
                client.connect();
                if (client.isConnected()) {
                    this.ingameName = this.getUsername();
                    client.getNetworkManager().addToSendQueue(new Packet01Login("0VrVFEoKHvKGylfm", this.ingameName));
                    client.getNetworkManager().flush();
                    NotificationManager.post(NotificationType.SUCCESS, "IRC", "Connected to the server! handshaking...");
                }
            }
            catch (IOException e) {
                DebugUtil.log("\u8fde\u63a5IRC\u670d\u52a1\u5668\u5931\u8d25\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc\u6216\u8005\u8054\u7cfb\u7ba1\u7406\u5458\uff01");
                e.printStackTrace();
            }
        }, "IRC Connect Thread").start();
    }

    private String getUsername() {
        return this.reportUsername.getValue().booleanValue() ? (IRC.mc.thePlayer == null ? mc.getSession().getUsername() : IRC.mc.thePlayer.getName()) : "";
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        int entityId;
        if (!client.isConnected()) {
            return;
        }
        if (event.getPacket() instanceof C01PacketChatMessage) {
            C01PacketChatMessage c01 = (C01PacketChatMessage)event.getPacket();
            String msg = c01.getMessage();
            if (msg.startsWith("!")) {
                event.setCancelled(true);
                client.getNetworkManager().addToSendQueue(new Packet02Chat(msg.substring(1)));
                return;
            }
            Matcher matcher = pattern.matcher(msg);
            StringBuffer sb = new StringBuffer(msg.length());
            while (matcher.find()) {
                String username = matcher.group(1);
                IRCUser user = client.getOnlineUser(username);
                String ingameName = user == null ? "" : user.getIngamename();
                String string = ingameName;
                if (ingameName.isEmpty()) {
                    ingameName = username;
                }
                matcher.appendReplacement(sb, Matcher.quoteReplacement(ingameName));
            }
            matcher.appendTail(sb);
            c01.setMessage(sb.toString());
        }
        if (client.isConnected() && event.getPacket() instanceof C02PacketUseEntity && ((C02PacketUseEntity)event.getPacket()).getAction() == C02PacketUseEntity.Action.ATTACK && IRC.isFriendId(entityId = ((C02PacketUseEntity)event.getPacket()).entityId)) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void on(EventTick e) {
        if (!client.isConnected()) {
            if (this.timer.hasTimeElapsed(30000L, true)) {
                this.connect();
                this.timer.reset();
            }
            return;
        }
        String ingameName = this.getUsername();
        if (ingameName != this.ingameName) {
            client.getNetworkManager().addToSendQueue(new Packet07ChangeIGN(ingameName));
            this.ingameName = ingameName;
        }
    }

    private void sendMessage(String message) {
        message = "\u00a7e[IRC] \u00a7r" + message;
        DebugUtil.log(message);
    }

    @Override
    public void onDisable() {
        if (client.isConnected()) {
            client.disconnect();
        }
    }

    public IRCClient getClient() {
        return client;
    }

    public static boolean isFriend(Entity entity) {
        return Arrays.stream(client.getOnlineUsers()).anyMatch(user -> user.getIngamename().equals(entity.getName()));
    }

    public static boolean isFriendId(int entityId) {
        return Arrays.stream(client.getOnlineUsers()).anyMatch(user -> user.getIngamename().equals(IRC.mc.theWorld.getEntityByID(entityId).getName()));
    }

    @Native
    private void handleCustomPayload(Packet08CustomPayload packet) {
        long uid = packet.getTargetUserid();
        ClientType clientType = packet.getTargetClient();
        if (clientType == ClientType.XYLITOL && uid == client.getOnlineUser(Client.instance.user).getUserid() && packet.getData().equals("crash_client".getBytes())) {
            mc.shutdown();
        }
    }

    static {
        pattern = Pattern.compile("\\$\\{IRC:(.+?)\\}", 8);
        if (client != null) {
            client.setDisconnetHook(DebugUtil::log);
        }
    }
}

