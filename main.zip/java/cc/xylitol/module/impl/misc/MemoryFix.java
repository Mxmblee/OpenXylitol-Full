package cc.xylitol.module.impl.misc;

import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventTick;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.utils.TimerUtil;
import cc.xylitol.value.impl.NumberValue;

public class MemoryFix
extends Module {
    private final NumberValue delay = new NumberValue("Delay", 120.0, 10.0, 600.0, 10.0);
    private final NumberValue limit = new NumberValue("Limit", 80.0, 20.0, 95.0, 1.0);
    public TimerUtil timer = new TimerUtil();

    public MemoryFix() {
        super("MemoryFix", Category.Misc);
    }

    @EventTarget
    public void onTick(EventTick event) {
        long maxMem = Runtime.getRuntime().maxMemory();
        long totalMem = Runtime.getRuntime().totalMemory();
        long freeMem = Runtime.getRuntime().freeMemory();
        long usedMem = totalMem - freeMem;
        float pct = usedMem * 100L / maxMem;
        if (this.timer.hasReached(this.delay.getValue() * 1000.0) && this.limit.getValue() <= (double)pct) {
            Runtime.getRuntime().gc();
            this.timer.reset();
        }
    }
}

