package cc.xylitol.module.impl.move;

import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventHigherPacketSend;
import cc.xylitol.event.impl.events.EventMotion;
import cc.xylitol.event.impl.events.EventSlowDown;
import cc.xylitol.event.impl.events.EventWorldLoad;
import cc.xylitol.module.Category;
import cc.xylitol.module.Module;
import cc.xylitol.module.impl.combat.KillAura;
import cc.xylitol.ui.hud.notification.NotificationManager;
import cc.xylitol.ui.hud.notification.NotificationType;
import cc.xylitol.value.impl.BoolValue;
import cc.xylitol.value.impl.ModeValue;
import com.viaversion.viarewind.protocol.protocol1_8to1_9.Protocol1_8To1_9;
import com.viaversion.viarewind.utils.PacketUtil;
import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import io.netty.buffer.Unpooled;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemBucketMilk;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.C00PacketLoginStart;
import net.minecraft.network.login.client.C01PacketEncryptionResponse;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.network.status.client.C00PacketServerQuery;
import net.minecraft.network.status.client.C01PacketPing;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.vialoadingbase.ViaLoadingBase;

public class NoSlow
extends Module {
    private boolean blinking = false;
    private final LinkedBlockingQueue<Packet<?>> packets = new LinkedBlockingQueue();
    private final ModeValue mode = new ModeValue("Mode", new String[]{"Grim", "Old Grim"}, "Grim");
    private final BoolValue food = new BoolValue("Food (Experimental)", false);
    private final BoolValue bow = new BoolValue("Bow (Experimental)", false);

    public NoSlow() {
        super("Noslow", Category.Movement);
    }

    private boolean isHoldingPotionAndSword(ItemStack stack, boolean checkSword, boolean checkPotionFood) {
        if (stack == null) {
            return false;
        }
        if (stack.getItem() instanceof ItemAppleGold && checkPotionFood) {
            return this.food.getValue();
        }
        if (stack.getItem() instanceof ItemPotion && checkPotionFood) {
            return this.food.getValue() && !ItemPotion.isSplash(stack.getMetadata());
        }
        if (stack.getItem() instanceof ItemFood && checkPotionFood) {
            return this.food.getValue();
        }
        if (stack.getItem() instanceof ItemSword && checkSword) {
            return true;
        }
        if (stack.getItem() instanceof ItemBow) {
            return this.bow.getValue();
        }
        return stack.getItem() instanceof ItemBucketMilk && checkPotionFood && this.food.getValue();
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (NoSlow.mc.thePlayer.getHeldItem() != null) {
            if (event.isPre() && NoSlow.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && NoSlow.mc.thePlayer.isUsingItem()) {
                switch (this.mode.get()) {
                    case "Grim": {
                        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(NoSlow.mc.thePlayer.inventory.currentItem % 8 + 1));
                        mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload("test", new PacketBuffer(Unpooled.buffer())));
                        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(NoSlow.mc.thePlayer.inventory.currentItem));
                        break;
                    }
                    case "Old Grim": {
                        if (KillAura.isBlocking) break;
                        mc.getNetHandler().getNetworkManager().sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(0, 0, 0), EnumFacing.DOWN));
                    }
                }
            }
            if (NoSlow.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && NoSlow.mc.thePlayer.isUsingItem() && event.isPost()) {
                switch (this.mode.get()) {
                    case "Grim": {
                        mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(NoSlow.mc.thePlayer.getHeldItem()));
                        break;
                    }
                    case "Old Grim": {
                        NoSlow.mc.playerController.sendUseItem(NoSlow.mc.thePlayer, NoSlow.mc.theWorld, NoSlow.mc.thePlayer.getHeldItem());
                        PacketWrapper use_0 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                        use_0.write((Type)Type.VAR_INT, (Object)0);
                        PacketUtil.sendToServer(use_0, Protocol1_8To1_9.class, true, true);
                        PacketWrapper use_1 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                        use_1.write((Type)Type.VAR_INT, (Object)1);
                        PacketUtil.sendToServer(use_1, Protocol1_8To1_9.class, true, true);
                    }
                }
            }
        }
    }

    @EventTarget
    public void onWorld(EventWorldLoad event) {
        this.blinking = false;
        this.packets.clear();
    }

    @EventTarget
    public void onPacketReceive(EventHigherPacketSend event) {
        Packet packet = event.getPacket();
        if (NoSlow.mc.thePlayer == null || mc.isSingleplayer()) {
            return;
        }
        if (NoSlow.mc.thePlayer.getHeldItem() != null && this.food.getValue().booleanValue() && (NoSlow.mc.thePlayer.getHeldItem().getItem() instanceof ItemFood || NoSlow.mc.thePlayer.getHeldItem().getItem() instanceof ItemPotion && !ItemPotion.isSplash(NoSlow.mc.thePlayer.getHeldItem().getMetadata()))) {
            if (packet instanceof C08PacketPlayerBlockPlacement && ((C08PacketPlayerBlockPlacement)packet).getPosition().equals(new BlockPos(-1, -1, -1))) {
                this.blinking = true;
                if (ViaLoadingBase.getInstance().getTargetVersion().getVersion() <= 47) {
                    NotificationManager.post(NotificationType.DISABLE, "No Slow", "This NoSlow only supports higher versions!", 10000.0f);
                }
            } else if (!(packet instanceof C00Handshake || packet instanceof C00PacketLoginStart || packet instanceof C00PacketServerQuery || packet instanceof C01PacketPing || packet instanceof C01PacketEncryptionResponse || !this.blinking)) {
                C07PacketPlayerDigging wrapped;
                event.setCancelled(true);
                if (packet instanceof C07PacketPlayerDigging && (wrapped = (C07PacketPlayerDigging)packet).getStatus() == C07PacketPlayerDigging.Action.RELEASE_USE_ITEM) {
                    this.blinking = false;
                    mc.getNetHandler().addToSendQueueUnregisteredNoEvent(wrapped);
                    this.packets.forEach(p -> mc.getNetHandler().addToSendQueueUnregisteredNoEvent(p));
                    this.packets.clear();
                    return;
                }
                this.packets.add(packet);
            }
        } else if (this.blinking) {
            this.blinking = false;
            mc.getNetHandler().addToSendQueueUnregisteredNoEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
            this.packets.forEach(p -> mc.getNetHandler().addToSendQueueUnregisteredNoEvent(p));
            this.packets.clear();
        }
    }

    @EventTarget
    public void onSlowDown(EventSlowDown event) {
        if (NoSlow.mc.thePlayer.isUsingItem() && this.isHoldingPotionAndSword(NoSlow.mc.thePlayer.getHeldItem(), true, true)) {
            event.setCancelled(true);
            NoSlow.mc.thePlayer.setSprinting(true);
            KeyBinding.setKeyBindState(NoSlow.mc.gameSettings.keyBindSprint.getKeyCode(), true);
        } else {
            event.setForwardMultiplier(0.2f);
            event.setStrafeMultiplier(0.2f);
        }
    }
}

