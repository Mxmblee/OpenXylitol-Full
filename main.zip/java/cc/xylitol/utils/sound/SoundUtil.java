package cc.xylitol.utils.sound;

import cc.xylitol.Client;

public final class SoundUtil {
    private static int ticksExisted;

    public static void toggleSound(boolean enable) {
        if (Client.mc.thePlayer != null && Client.mc.thePlayer.ticksExisted != ticksExisted) {
            if (enable) {
                SoundUtil.playSound("rise.toggle.enable");
            } else {
                SoundUtil.playSound("rise.toggle.disable");
            }
            ticksExisted = Client.mc.thePlayer.ticksExisted;
        }
    }

    public static void playSound(String sound) {
        SoundUtil.playSound(sound, 1.0f, 1.0f);
    }

    public static void playSound(String sound, float volume, float pitch) {
        Client.mc.theWorld.playSound(Client.mc.thePlayer.posX, Client.mc.thePlayer.posY, Client.mc.thePlayer.posZ, sound, volume, pitch, false);
    }

    private SoundUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

