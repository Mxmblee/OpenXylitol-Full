package cc.xylitol.utils;

public enum MovementFix {
    OFF("Off"),
    NORMAL("Xylitol"),
    TRADITIONAL("Traditional"),
    BACKWARDS_SPRINT("Backwards Sprint");

    String name;

    public String toString() {
        return this.name;
    }

    MovementFix(String name) {
        this.name = name;
    }
}

