package cc.xylitol.utils.render;

import cc.xylitol.event.impl.events.EventRender2D;
import cc.xylitol.utils.render.GLUtil;
import cc.xylitol.utils.render.WorldToScreenCallback;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Arrays;
import java.util.List;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;
import org.lwjglx.util.glu.GLU;

public class WorldToScreenUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final Frustum frustum = new Frustum();
    private static final IntBuffer viewport = GLAllocation.createDirectIntBuffer(16);
    private static final FloatBuffer modelView = GLAllocation.createDirectFloatBuffer(16);
    private static final FloatBuffer projection = GLAllocation.createDirectFloatBuffer(16);
    private static final FloatBuffer vector = GLAllocation.createDirectFloatBuffer(4);

    public static void onRender2D(EventRender2D event, Entity entity, WorldToScreenCallback callback) {
        ScaledResolution sr = event.getScaledResolution();
        float renderPartialTicks = event.getPartialTicks();
        GlStateManager.pushMatrix();
        GLUtil.setup2DRendering(() -> {
            double scaling = (double)sr.getScaleFactor() / Math.pow(sr.getScaleFactor(), 2.0);
            GlStateManager.scale(scaling, scaling, scaling);
            if (WorldToScreenUtils.isInViewFrustum(entity)) {
                double x = WorldToScreenUtils.interpolate(entity.lastTickPosX, entity.posX, renderPartialTicks);
                double y = WorldToScreenUtils.interpolate(entity.lastTickPosY, entity.posY, renderPartialTicks);
                double z = WorldToScreenUtils.interpolate(entity.lastTickPosZ, entity.posZ, renderPartialTicks);
                float width = entity.width - 0.15f;
                float height = entity.height + 0.15f - (entity instanceof EntityPlayer ? (entity.isSneaking() ? 0.25f : 0.0f) : 0.0f);
                AxisAlignedBB aabb = new AxisAlignedBB(x - (double)width, y, z - (double)width, x + (double)width, y + (double)height, z + (double)width);
                List<Vector3d> vectors = Arrays.asList(new Vector3d(aabb.minX, aabb.minY, aabb.minZ), new Vector3d(aabb.minX, aabb.maxY, aabb.minZ), new Vector3d(aabb.maxX, aabb.minY, aabb.minZ), new Vector3d(aabb.maxX, aabb.maxY, aabb.minZ), new Vector3d(aabb.minX, aabb.minY, aabb.maxZ), new Vector3d(aabb.minX, aabb.maxY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.minY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.maxY, aabb.maxZ));
                WorldToScreenUtils.mc.entityRenderer.setupCameraTransform(renderPartialTicks, 0);
                Vector4d position = null;
                for (Vector3d vector : vectors) {
                    vector = WorldToScreenUtils.worldToScreen(sr, vector.x - WorldToScreenUtils.mc.getRenderManager().viewerPosX, vector.y - WorldToScreenUtils.mc.getRenderManager().viewerPosY, vector.z - WorldToScreenUtils.mc.getRenderManager().viewerPosZ);
                    if (vector == null || !(vector.z >= 0.0) || !(vector.z < 1.0)) continue;
                    if (position == null) {
                        position = new Vector4d(vector.x, vector.y, vector.z, 0.0);
                    }
                    position.x = Math.min(vector.x, position.x);
                    position.y = Math.min(vector.y, position.y);
                    position.z = Math.max(vector.x, position.z);
                    position.w = Math.max(vector.y, position.w);
                }
                WorldToScreenUtils.mc.entityRenderer.setupOverlayRendering();
                if (position != null) {
                    double posX = position.x;
                    double posY = position.y;
                    double endPosX = position.z;
                    double endPosY = position.w;
                    callback.run(posX, posY, endPosX, endPosY);
                }
            }
            WorldToScreenUtils.mc.entityRenderer.setupOverlayRendering();
            GlStateManager.resetColor();
        });
        GlStateManager.popMatrix();
        GlStateManager.resetColor();
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
    }

    public static Double interpolate(double oldValue, double newValue, double interpolationValue) {
        return oldValue + (newValue - oldValue) * interpolationValue;
    }

    private static boolean isInViewFrustum(Entity entity) {
        AxisAlignedBB bb = entity.getEntityBoundingBox();
        frustum.setPosition(WorldToScreenUtils.mc.getRenderViewEntity().posX, WorldToScreenUtils.mc.getRenderViewEntity().posY, WorldToScreenUtils.mc.getRenderViewEntity().posZ);
        return frustum.isBoundingBoxInFrustum(bb) || entity.ignoreFrustumCheck;
    }

    private static Vector3d worldToScreen(ScaledResolution sr, double x, double y, double z) {
        GL11.glGetFloatv(2982, modelView);
        GL11.glGetFloatv(2983, projection);
        GL11.glGetIntegerv(2978, viewport);
        if (GLU.gluProject((float)x, (float)y, (float)z, modelView, projection, viewport, vector)) {
            return new Vector3d(vector.get(0) / (float)sr.getScaleFactor(), ((float)WorldToScreenUtils.mc.displayHeight - vector.get(1)) / (float)sr.getScaleFactor(), vector.get(2));
        }
        return null;
    }
}

