package cc.xylitol.utils.render;

import cc.xylitol.utils.TimerUtil;
import java.io.File;
import java.nio.ByteBuffer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import org.bytedeco.ffmpeg.global.avutil;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.FrameGrabber;
import org.lwjgl.opengl.GL11;

// 怎么感觉写的不如我的？不知道有多少人用的咱HyperMC的视频背景呐。
public class WallpaperEngine {
    private final TimerUtil timer = new TimerUtil();
    private int framerate;
    private int grabbedFrames;
    private int lastFrameTexID;
    private FFmpegFrameGrabber grabber;
    private Frame currentFrame;

    public void setup(File videoFile, int framerate) {
        this.framerate = framerate;
        try {
            avutil.av_log_set_level(16);
            this.grabber = FFmpegFrameGrabber.createDefault(videoFile);
            this.grabber.start();
        }
        catch (FFmpegFrameGrabber.Exception exception) {
            // empty catch block
        }
    }

    public void render(int width, int height) {
        if (this.timer.hasTimeElapsed(1000 / this.framerate, true)) {
            try {
                if (this.grabbedFrames == this.grabber.getLengthInFrames()) {
                    this.grabber.setFrameNumber(0);
                    this.grabbedFrames = 0;
                }
                this.currentFrame = this.grabber.grabImage();
                if (this.currentFrame != null) {
                    GL11.glDeleteTextures(this.lastFrameTexID);
                    int texID = GL11.glGenTextures();
                    GL11.glBindTexture(3553, texID);
                    GL11.glTexParameteri(3553, 10241, 9729);
                    GL11.glTexParameteri(3553, 10240, 9729);
                    GL11.glTexImage2D(3553, 0, 6408, this.currentFrame.imageWidth, this.currentFrame.imageHeight, 0, 32992, 5121, (ByteBuffer) this.currentFrame.image[0]);
                    this.lastFrameTexID = texID;
                    ++this.grabbedFrames;
                }
            }
            catch (FFmpegFrameGrabber.Exception exception) {
                // empty catch block
            }
        }
        GlStateManager.bindTexture(this.lastFrameTexID);
        Gui.drawModalRectWithCustomSizedTexture(0, 0, 0.0f, 0.0f, width, height, (float)width, (float)height);
    }

    public void close() {
        try {
            if (this.grabber != null) {
                this.grabber.stop();
                this.grabber.close();
            }
        }
        catch (FrameGrabber.Exception exception) {
            // empty catch block
        }
    }

    public TimerUtil getTimer() {
        return this.timer;
    }

    public int getFramerate() {
        return this.framerate;
    }

    public int getGrabbedFrames() {
        return this.grabbedFrames;
    }

    public int getLastFrameTexID() {
        return this.lastFrameTexID;
    }

    public FFmpegFrameGrabber getGrabber() {
        return this.grabber;
    }

    public Frame getCurrentFrame() {
        return this.currentFrame;
    }
}

