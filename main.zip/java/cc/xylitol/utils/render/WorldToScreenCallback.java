package cc.xylitol.utils.render;

public interface WorldToScreenCallback {
    void run(double var1, double var3, double var5, double var7);
}

