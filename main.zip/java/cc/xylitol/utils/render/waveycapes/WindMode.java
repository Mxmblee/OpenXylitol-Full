package cc.xylitol.utils.render.waveycapes;

public enum WindMode {
    NONE,
    WAVES

}

