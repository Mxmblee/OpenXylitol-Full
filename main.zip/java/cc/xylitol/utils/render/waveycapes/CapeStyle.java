package cc.xylitol.utils.render.waveycapes;

public enum CapeStyle {
    BLOCKY,
    SMOOTH

}

