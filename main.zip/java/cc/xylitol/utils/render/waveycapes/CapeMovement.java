package cc.xylitol.utils.render.waveycapes;

public enum CapeMovement {
    VANILLA,
    BASIC_SIMULATION

}

