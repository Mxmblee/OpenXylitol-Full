package cc.xylitol.utils.render.shader;

import cc.xylitol.Client;
import cc.xylitol.utils.math.MathUtils;
import cc.xylitol.utils.render.RenderUtil;
import cc.xylitol.utils.render.StencilUtil;
import cc.xylitol.utils.render.shader.ShaderElement;
import cc.xylitol.utils.render.shader.ShaderUtil;
import java.nio.FloatBuffer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.BufferUtils;

public class GaussianBlur {
    private static final ShaderUtil gaussianBlur = new ShaderUtil("xylitol/shader/gaussian.frag");
    private static Framebuffer framebuffer = new Framebuffer(1, 1, false);

    private static void setupUniforms(float dir1, float dir2, float radius) {
        gaussianBlur.setUniformi("textureIn", 0);
        gaussianBlur.setUniformf("texelSize", 1.0f / (float)Client.mc.displayWidth, 1.0f / (float)Client.mc.displayHeight);
        gaussianBlur.setUniformf("direction", dir1, dir2);
        gaussianBlur.setUniformf("radius", radius);
        FloatBuffer weightBuffer = BufferUtils.createFloatBuffer(256);
        int i = 0;
        while ((float)i <= radius) {
            weightBuffer.put(MathUtils.calculateGaussianValue(i, radius / 2.0f));
            ++i;
        }
        weightBuffer.rewind();
        OpenGlHelper.glUniform1(gaussianBlur.getUniform("weights"), weightBuffer);
    }

    public static void startBlur() {
        StencilUtil.write(false);
    }

    public static void endBlur(float radius, float compression) {
        StencilUtil.erase(true);
        framebuffer = ShaderElement.createFrameBuffer(framebuffer);
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(false);
        gaussianBlur.init();
        GaussianBlur.setupUniforms(compression, 0.0f, radius);
        RenderUtil.bindTexture(Client.mc.getFramebuffer().framebufferTexture);
        ShaderUtil.drawQuads();
        framebuffer.unbindFramebuffer();
        gaussianBlur.unload();
        Client.mc.getFramebuffer().bindFramebuffer(false);
        gaussianBlur.init();
        GaussianBlur.setupUniforms(0.0f, compression, radius);
        RenderUtil.bindTexture(GaussianBlur.framebuffer.framebufferTexture);
        ShaderUtil.drawQuads();
        gaussianBlur.unload();
        StencilUtil.dispose();
        RenderUtil.resetColor();
        GlStateManager.bindTexture(0);
    }
}

