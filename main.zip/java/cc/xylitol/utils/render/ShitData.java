package cc.xylitol.utils.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class ShitData {
    public static ItemStack axe = new ItemStack(Items.golden_axe);
    public static ItemStack ball = new ItemStack(Items.slime_ball);
    public static ItemStack apple = new ItemStack(Items.golden_apple);
    public static ItemStack effect = new ItemStack(Items.golden_apple);
    public static ItemStack strength = new ItemStack(Items.potionitem);
    public static ItemStack fireball = new ItemStack(Items.magma_cream);
    public List<ItemStack> shouldDisplay = new ArrayList<ItemStack>();
}

