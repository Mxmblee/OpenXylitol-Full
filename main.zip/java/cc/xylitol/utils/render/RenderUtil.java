package cc.xylitol.utils.render;

import cc.xylitol.Client;
import cc.xylitol.module.impl.render.HUD;
import cc.xylitol.utils.math.MathUtils;
import cc.xylitol.utils.render.GLUtil;
import cc.xylitol.utils.render.RoundedUtil;
import cc.xylitol.utils.render.StencilUtil;
import cc.xylitol.utils.render.animation.AnimationUtils;
import cc.xylitol.utils.render.shader.ShaderUtil;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Timer;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;
import org.lwjglx.opengl.Display;

public class RenderUtil {
    private static final Tessellator tessellator = Tessellator.getInstance();
    private static final WorldRenderer worldrenderer = tessellator.getWorldRenderer();
    public static int deltaTime;
    public static double ticks;
    public static long lastFrame;
    private static final Frustum FRUSTUM;
    public static final ShaderUtil roundedShader;
    private static final Map<Integer, Boolean> glCapMap;
    private static double frameDeltaTime;
    private static int lastScaledWidth;
    private static int lastScaledHeight;
    private static ScaledResolution scaledResolution;
    private static float lastGuiScale;
    private static final int[] DISPLAY_LISTS_2D;

    public static void drawAxisAlignedBB(AxisAlignedBB axisAlignedBB, boolean outline, int color) {
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glLineWidth(2.0f);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        RenderUtil.color(color);
        RenderGlobal.func_181561_a(axisAlignedBB, outline, true);
        GlStateManager.resetColor();
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
    }

    public static void connectPoints(float xOne, float yOne, float xTwo, float yTwo) {
        GL11.glPushMatrix();
        GL11.glEnable(2848);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glLineWidth(0.5f);
        GL11.glBegin(1);
        GL11.glVertex2f(xOne, yOne);
        GL11.glVertex2f(xTwo, yTwo);
        GL11.glEnd();
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(2848);
        GL11.glEnable(3553);
        GL11.glPopMatrix();
    }

    public static int colorSwitch(Color firstColor, Color secondColor, float time, int index, long timePerIndex, double speed) {
        return RenderUtil.colorSwitch(firstColor, secondColor, time, index, timePerIndex, speed, 255.0);
    }

    public static int colorSwitch(Color firstColor, Color secondColor, float time, int index, long timePerIndex, double speed, double alpha) {
        long now = (long)(speed * (double)System.currentTimeMillis() + (double)((long)index * timePerIndex));
        float redDiff = (float)(firstColor.getRed() - secondColor.getRed()) / time;
        float greenDiff = (float)(firstColor.getGreen() - secondColor.getGreen()) / time;
        float blueDiff = (float)(firstColor.getBlue() - secondColor.getBlue()) / time;
        int red = Math.round((float)secondColor.getRed() + redDiff * (float)(now % (long)time));
        int green = Math.round((float)secondColor.getGreen() + greenDiff * (float)(now % (long)time));
        int blue = Math.round((float)secondColor.getBlue() + blueDiff * (float)(now % (long)time));
        float redInverseDiff = (float)(secondColor.getRed() - firstColor.getRed()) / time;
        float greenInverseDiff = (float)(secondColor.getGreen() - firstColor.getGreen()) / time;
        float blueInverseDiff = (float)(secondColor.getBlue() - firstColor.getBlue()) / time;
        int inverseRed = Math.round((float)firstColor.getRed() + redInverseDiff * (float)(now % (long)time));
        int inverseGreen = Math.round((float)firstColor.getGreen() + greenInverseDiff * (float)(now % (long)time));
        int inverseBlue = Math.round((float)firstColor.getBlue() + blueInverseDiff * (float)(now % (long)time));
        if (now % ((long)time * 2L) < (long)time) {
            return new Color(inverseRed, inverseGreen, inverseBlue, (int)alpha).getRGB();
        }
        return new Color(red, green, blue, (int)alpha).getRGB();
    }

    public static void drawCircle(float x, float y, float radius, int color) {
        float alpha = (float)(color >> 24 & 0xFF) / 255.0f;
        float red = (float)(color >> 16 & 0xFF) / 255.0f;
        float green = (float)(color >> 8 & 0xFF) / 255.0f;
        float blue = (float)(color & 0xFF) / 255.0f;
        GL11.glColor4f(red, green, blue, alpha);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glPushMatrix();
        GL11.glLineWidth(1.0f);
        GL11.glBegin(9);
        for (int i = 0; i <= 360; ++i) {
            GL11.glVertex2d((double)x + Math.sin((double)i * Math.PI / 180.0) * (double)radius, (double)y + Math.cos((double)i * Math.PI / 180.0) * (double)radius);
        }
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable(3553);
        GL11.glDisable(2848);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static void drawPlatESP(EntityLivingBase player, Color color) {
        if (Client.mc.getRenderManager() == null || player == null) {
            return;
        }
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glLineWidth(1.8f);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GlStateManager.depthMask(true);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glDisable(3553);
        GL11.glEnable(2848);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        float partialTicks = Client.mc.timer.renderPartialTicks;
        double x = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double)partialTicks;
        double y = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double)partialTicks + (double)player.getEyeHeight() * 1.2;
        double z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double)partialTicks;
        float width = player.width;
        float height = player.height + (player.isSneaking() ? -0.2f : 0.1f);
        RenderUtil.color(color.getRGB());
        RenderUtil.drawBoundBox(new AxisAlignedBB(x - (double)width / 1.75, y, z - (double)width / 1.75, x + (double)width / 1.75, y - 0.05, z + (double)width / 1.75));
        GL11.glDisable(2848);
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glPopMatrix();
        RenderUtil.color(Color.WHITE.getRGB());
    }

    public static void setTextureFliterTypeToLinear() {
        GL11.glTexParameteri(3553, 10241, 9729);
    }

    public static Vec3 getRenderPos(double x, double y, double z) {
        Client.mc.getRenderManager();
        Client.mc.getRenderManager();
        Client.mc.getRenderManager();
        return new Vec3(x -= RenderManager.renderPosX, y -= RenderManager.renderPosY, z -= RenderManager.renderPosZ);
    }

    public static int hexColor(int red, int green, int blue) {
        return RenderUtil.hexColor(red, green, blue, 255);
    }

    public static int hexColor(int red, int green, int blue, int alpha) {
        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    public static void glVertex3D(Vec3 vector3d) {
        GL11.glVertex3d(vector3d.xCoord, vector3d.yCoord, vector3d.zCoord);
    }

    public static void end() {
        GL11.glEnd();
    }

    public static void drawBoundBox(AxisAlignedBB aa) {
        GL11.glBegin(7);
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.maxZ));
        RenderUtil.end();
        GL11.glBegin(7);
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.maxZ));
        RenderUtil.end();
        GL11.glBegin(7);
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.minZ));
        RenderUtil.end();
        GL11.glBegin(7);
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.minZ));
        RenderUtil.end();
        GL11.glBegin(7);
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.minZ));
        RenderUtil.end();
        GL11.glBegin(7);
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.minX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.minZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.maxY, aa.maxZ));
        RenderUtil.glVertex3D(RenderUtil.getRenderPos(aa.maxX, aa.minY, aa.maxZ));
        RenderUtil.end();
    }

    public static float[] getNextWheelPosition(int wheel, float[] memorize, float topY, float bottomY, float objectY, float offset, boolean updateAction) {
        float reversingOffset;
        float target = memorize[0];
        float current = memorize[1];
        if (updateAction) {
            int i;
            if (wheel > 0) {
                for (i = 0; i < 15; ++i) {
                    float f = target;
                    target = f + 1.0f;
                    if (f > 0.0f) break;
                }
                if (target > 0.0f) {
                    target = 0.0f;
                }
            } else if (wheel < 0) {
                for (i = 0; i < 15 && !(topY + (objectY - current + (target - 1.0f)) + offset < bottomY); ++i) {
                    target -= 1.0f;
                }
            }
        }
        if (objectY - current + target < (reversingOffset = bottomY - topY - offset)) {
            float diff = reversingOffset - (objectY - current + target);
            target = target + diff <= 0.0f ? (target += diff) : (target += diff - (target + diff));
        }
        current = AnimationUtils.animate(current, target, 0.2f);
        return new float[]{target, current};
    }

    public static void drawVGradientRect(double x, double y, double width, double height, int startColor, int endColor) {
        float f = (float)(startColor >> 24 & 0xFF) / 255.0f;
        float f1 = (float)(startColor >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(startColor >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(startColor & 0xFF) / 255.0f;
        float f4 = (float)(endColor >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(endColor >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(endColor >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(endColor & 0xFF) / 255.0f;
        GLUtil.setup2DRendering(() -> {
            GL11.glShadeModel(7425);
            worldrenderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
            worldrenderer.pos(x + width, y, 0.0).color(f1, f2, f3, f).endVertex();
            worldrenderer.pos(x, y, 0.0).color(f1, f2, f3, f).endVertex();
            worldrenderer.pos(x, y + height, 0.0).color(f5, f6, f7, f4).endVertex();
            worldrenderer.pos(x + width, y + height, 0.0).color(f5, f6, f7, f4).endVertex();
            tessellator.draw();
            GlStateManager.resetColor();
            GL11.glShadeModel(7424);
        });
    }

    public static void drawHGradientRect(double x, double y, double width, double height, int startColor, int endColor) {
        float f = (float)(startColor >> 24 & 0xFF) / 255.0f;
        float f1 = (float)(startColor >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(startColor >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(startColor & 0xFF) / 255.0f;
        float f4 = (float)(endColor >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(endColor >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(endColor >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(endColor & 0xFF) / 255.0f;
        GLUtil.setup2DRendering(() -> {
            GL11.glShadeModel(7425);
            worldrenderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
            worldrenderer.pos(x, y, 0.0).color(f1, f2, f3, f).endVertex();
            worldrenderer.pos(x, y + height, 0.0).color(f1, f2, f3, f).endVertex();
            worldrenderer.pos(x + width, y + height, 0.0).color(f5, f6, f7, f4).endVertex();
            worldrenderer.pos(x + width, y, 0.0).color(f5, f6, f7, f4).endVertex();
            tessellator.draw();
            GlStateManager.resetColor();
            GL11.glShadeModel(7424);
        });
    }

    public static void drawItemStack(ItemStack stack, float x, float y) {
        GL11.glPushMatrix();
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld != null) {
            RenderHelper.enableGUIStandardItemLighting();
        }
        GlStateManager.pushMatrix();
        GlStateManager.disableAlpha();
        GlStateManager.clear(256);
        GlStateManager.enableBlend();
        mc.getRenderItem().zLevel = -150.0f;
        mc.getRenderItem().renderItemAndEffectIntoGUI(stack, (int)x, (int)y);
        mc.getRenderItem().zLevel = 0.0f;
        GlStateManager.enableBlend();
        float z = 0.5f;
        GlStateManager.scale(0.5f, 0.5f, 0.5f);
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.scale(2.0f, 2.0f, 2.0f);
        GlStateManager.enableAlpha();
        GlStateManager.popMatrix();
        GL11.glPopMatrix();
    }

    public static void skeetRect(double x, double y, double x1, double y1, double size) {
        RenderUtil.rectangleBordered(x, y - 4.0, x1 + size, y1 + size, 0.5, new Color(60, 60, 60).getRGB(), new Color(10, 10, 10).getRGB());
        RenderUtil.rectangleBordered(x + 1.0, y - 3.0, x1 + size - 1.0, y1 + size - 1.0, 1.0, new Color(40, 40, 40).getRGB(), new Color(40, 40, 40).getRGB());
        RenderUtil.rectangleBordered(x + 2.5, y - 1.5, x1 + size - 2.5, y1 + size - 2.5, 0.5, new Color(40, 40, 40).getRGB(), new Color(60, 60, 60).getRGB());
        RenderUtil.rectangleBordered(x + 2.5, y - 1.5, x1 + size - 2.5, y1 + size - 2.5, 0.5, new Color(22, 22, 22).getRGB(), new Color(255, 255, 255, 0).getRGB());
    }

    public static void skeetRectSmall(double x, double y, double x1, double y1, double size) {
        RenderUtil.rectangleBordered(x + 4.35, y + 0.5, x1 + size - 84.5, y1 + size - 4.35, 0.5, new Color(48, 48, 48).getRGB(), new Color(10, 10, 10).getRGB());
        RenderUtil.rectangleBordered(x + 5.0, y + 1.0, x1 + size - 85.0, y1 + size - 5.0, 0.5, new Color(17, 17, 17).getRGB(), new Color(255, 255, 255, 0).getRGB());
    }

    public static void rectangleBordered(double x, double y, double x1, double y1, double width, int internalColor, int borderColor) {
        Gui.drawRect(x + width, y + width, x1 - width, y1 - width, internalColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        Gui.drawRect(x + width, y, x1 - width, y + width, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        Gui.drawRect(x, y, x + width, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        Gui.drawRect(x1 - width, y, x1, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        Gui.drawRect(x + width, y1 - width, x1 - width, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static void drawBorderedRect2(double x, double y, double x1, double y1, double width, int internalColor, int borderColor) {
        Gui.drawRect(x + width, y + width, x1 - width, y1 - width, internalColor);
        Gui.drawRect(x + width, y, x1 - width, y + width, borderColor);
        Gui.drawRect(x, y, x + width, y1, borderColor);
        Gui.drawRect(x1 - width, y, x1, y1, borderColor);
        Gui.drawRect(x + width, y1 - width, x1 - width, y1, borderColor);
    }

    public static void drawLoadingCircle(float x, float y) {
        for (int i = 0; i < 2; ++i) {
            int rot = (int)(System.nanoTime() / 5000000L * (long)i % 360L);
            RenderUtil.drawCircle(x, y, i * 8, rot - 180, rot);
        }
    }

    public static void drawCircle(float x, float y, float radius, int start, int end) {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        RenderUtil.glColor(Color.WHITE.getRGB());
        GL11.glEnable(2848);
        GL11.glLineWidth(3.0f);
        GL11.glBegin(3);
        for (float i = (float)end; i >= (float)start; i -= 4.0f) {
            GL11.glVertex2f((float)((double)x + Math.cos((double)i * Math.PI / 180.0) * (double)(radius * 1.001f)), (float)((double)y + Math.sin((double)i * Math.PI / 180.0) * (double)(radius * 1.001f)));
        }
        GL11.glEnd();
        GL11.glDisable(2848);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawRound(float x, float y, float width, float height, float radius, boolean blur, Color color, boolean topLeftCorner, boolean bottomLeftCorner, boolean topRightCorner, boolean bottomRightCorner) {
        GlStateManager.resetColor();
        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.0f);
        GlStateManager.blendFunc(770, 771);
        roundedShader.init();
        float alpha = (float)color.getAlpha() / 255.0f;
        RoundedUtil.setupRoundedRectUniforms(x, y, width, height, radius, roundedShader);
        roundedShader.setUniformi("blur", blur ? 1 : 0);
        roundedShader.setUniformf("color", (float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, alpha);
        roundedShader.setUniformf("corner", topLeftCorner ? 1.0f : 0.0f, bottomLeftCorner ? 1.0f : 0.0f, topRightCorner ? 1.0f : 0.0f, bottomRightCorner ? 1.0f : 0.0f);
        ShaderUtil.drawQuads(x - 1.0f, y - 1.0f, width + 2.0f, height + 2.0f);
        roundedShader.unload();
        GlStateManager.disableBlend();
    }

    public static Color tripleColor(int rgbValue, float alpha) {
        alpha = Math.min(1.0f, Math.max(0.0f, alpha));
        return new Color(rgbValue, rgbValue, rgbValue, (int)(255.0f * alpha));
    }

    public static void scissorStart(double x, double y, double width, double height) {
        GL11.glEnable(3089);
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        double scale = sr.getScaleFactor();
        double finalHeight = height * scale;
        double finalY = ((double)sr.getScaledHeight() - y) * scale;
        double finalX = x * scale;
        double finalWidth = width * scale;
        GL11.glScissor((int)finalX, (int)(finalY - finalHeight), (int)finalWidth, (int)finalHeight);
    }

    public static void scissorEnd() {
        GL11.glDisable(3089);
    }

    public static void draw2D(BlockPos blockPos, int color, int backgroundColor) {
        RenderManager renderManager = Client.mc.getRenderManager();
        double posX = (double)blockPos.getX() + 0.5 - RenderManager.renderPosX;
        double posY = (double)blockPos.getY() - RenderManager.renderPosY;
        double posZ = (double)blockPos.getZ() + 0.5 - RenderManager.renderPosZ;
        GlStateManager.pushMatrix();
        GlStateManager.translate(posX, posY, posZ);
        GlStateManager.rotate(-Client.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.scale(-0.1, -0.1, 0.1);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GlStateManager.depthMask(true);
        RenderUtil.glColor(color);
        GL11.glCallList(DISPLAY_LISTS_2D[0]);
        RenderUtil.glColor(backgroundColor);
        GL11.glCallList(DISPLAY_LISTS_2D[1]);
        GlStateManager.translate(0.0f, 9.0f, 0.0f);
        RenderUtil.glColor(color);
        GL11.glCallList(DISPLAY_LISTS_2D[2]);
        RenderUtil.glColor(backgroundColor);
        GL11.glCallList(DISPLAY_LISTS_2D[3]);
        GL11.glEnable(2929);
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GlStateManager.popMatrix();
    }

    public static void quickDrawRect(float x, float y, float x2, float y2) {
        GL11.glBegin(7);
        GL11.glVertex2d(x2, y);
        GL11.glVertex2d(x, y);
        GL11.glVertex2d(x, y2);
        GL11.glVertex2d(x2, y2);
        GL11.glEnd();
    }

    public static Color getColor(int color) {
        int f = color >> 24 & 0xFF;
        int f1 = color >> 16 & 0xFF;
        int f2 = color >> 8 & 0xFF;
        int f3 = color & 0xFF;
        return new Color(f1, f2, f3, f);
    }

    public static void renderOne() {
        StencilUtil.checkSetupFBO();
        GL11.glPushAttrib(1048575);
        GL11.glDisable(3008);
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glLineWidth(4.0f);
        GL11.glEnable(2848);
        GL11.glEnable(2960);
        GL11.glClear(1024);
        GL11.glClearStencil(15);
        GL11.glStencilFunc(512, 1, 15);
        GL11.glStencilOp(7681, 7681, 7681);
        GL11.glPolygonMode(1032, 6913);
    }

    public static void renderTwo() {
        GL11.glStencilFunc(512, 0, 15);
        GL11.glStencilOp(7681, 7681, 7681);
        GL11.glPolygonMode(1032, 6914);
    }

    public static void renderThree() {
        GL11.glStencilFunc(514, 1, 15);
        GL11.glStencilOp(7680, 7680, 7680);
        GL11.glPolygonMode(1032, 6913);
    }

    public static void renderFour(int color) {
        RenderUtil.setColor(color);
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
        GL11.glEnable(10754);
        GL11.glPolygonOffset(1.0f, -2000000.0f);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0f, 240.0f);
    }

    public static void renderFive() {
        GL11.glPolygonOffset(1.0f, 2000000.0f);
        GL11.glDisable(10754);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(2960);
        GL11.glDisable(2848);
        GL11.glHint(3154, 4352);
        GL11.glEnable(3042);
        GL11.glEnable(2896);
        GL11.glEnable(3553);
        GL11.glEnable(3008);
        GL11.glPopAttrib();
    }

    public static void setColor(int colorHex) {
        float alpha = (float)(colorHex >> 24 & 0xFF) / 255.0f;
        float red = (float)(colorHex >> 16 & 0xFF) / 255.0f;
        float green = (float)(colorHex >> 8 & 0xFF) / 255.0f;
        float blue = (float)(colorHex & 0xFF) / 255.0f;
        GL11.glColor4f(red, green, blue, alpha);
    }

    public static void drawBlockBox(BlockPos blockPos, Color color, boolean outline) {
        RenderManager renderManager = Client.mc.getRenderManager();
        Timer timer = Client.mc.timer;
        double x = (double)blockPos.getX() - RenderManager.renderPosX;
        double y = (double)blockPos.getY() - RenderManager.renderPosY;
        double z = (double)blockPos.getZ() - RenderManager.renderPosZ;
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(x, y, z, x + 1.0, y + 1.0, z + 1.0);
        Block block = Client.mc.theWorld.getBlockState(blockPos).getBlock();
        if (block != null) {
            EntityPlayerSP player = Client.mc.thePlayer;
            double posX = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double)timer.renderPartialTicks;
            double posY = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double)timer.renderPartialTicks;
            double posZ = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double)timer.renderPartialTicks;
            axisAlignedBB = block.getSelectedBoundingBox(Client.mc.theWorld, blockPos).expand(0.002f, 0.002f, 0.002f).offset(-posX, -posY, -posZ);
        }
        GL11.glBlendFunc(770, 771);
        RenderUtil.enableGlCap(3042);
        RenderUtil.disableGlCap(3553, 2929);
        GL11.glDepthMask(false);
        RenderUtil.glColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha() != 255 ? color.getAlpha() : (outline ? 26 : 35));
        RenderUtil.drawFilledBox(axisAlignedBB);
        if (outline) {
            GL11.glLineWidth(1.0f);
            RenderUtil.enableGlCap(2848);
            RenderUtil.glColor(color.getRGB());
            RenderGlobal.drawSelectionBoundingBox(axisAlignedBB);
        }
        GlStateManager.resetColor();
        GL11.glDepthMask(true);
        RenderUtil.resetCaps();
    }

    public static void glColor(int color) {
        float f = (float)(color >> 24 & 0xFF) / 255.0f;
        float f1 = (float)(color >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(color & 0xFF) / 255.0f;
        GL11.glColor4f(f1, f2, f3, f);
    }

    public static void glColor(int red, int green, int blue, int alpha) {
        GlStateManager.color((float)red / 255.0f, (float)green / 255.0f, (float)blue / 255.0f, (float)alpha / 255.0f);
    }

    public static void resetCaps() {
        glCapMap.forEach(RenderUtil::setGlState);
    }

    public static void enableGlCap(int cap) {
        RenderUtil.setGlCap(cap, true);
    }

    public static void enableGlCap(int ... caps) {
        for (int cap : caps) {
            RenderUtil.setGlCap(cap, true);
        }
    }

    public static void disableGlCap(int cap) {
        RenderUtil.setGlCap(cap, true);
    }

    public static void disableGlCap(int ... caps) {
        for (int cap : caps) {
            RenderUtil.setGlCap(cap, false);
        }
    }

    public static void setGlCap(int cap, boolean state) {
        glCapMap.put(cap, GL11.glGetBoolean(cap));
        RenderUtil.setGlState(cap, state);
    }

    public static void setGlState(int cap, boolean state) {
        if (state) {
            GL11.glEnable(cap);
        } else {
            GL11.glDisable(cap);
        }
    }

    public static void drawFilledBox(AxisAlignedBB axisAlignedBB) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        tessellator.draw();
    }

    public static void drawImage(ResourceLocation image, float x, float y, float width, float height) {
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDepthMask(false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        Client.mc.getTextureManager().bindTexture(image);
        float f = 1.0f / width;
        float f2 = 1.0f / height;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldrenderer.pos(x, y + height, 0.0).tex(0.0f * f, height * f2).endVertex();
        worldrenderer.pos(x + width, y + height, 0.0).tex(width * f, height * f2).endVertex();
        worldrenderer.pos(x + width, y, 0.0).tex(width * f, 0.0f * f2).endVertex();
        worldrenderer.pos(x, y, 0.0).tex(0.0f * f, 0.0f * f2).endVertex();
        tessellator.draw();
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
    }

    public static void drawImage(ResourceLocation image, float x, float y, int width, int height) {
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDepthMask(false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        Client.mc.getTextureManager().bindTexture(image);
        float f = 1.0f / (float)width;
        float f2 = 1.0f / (float)height;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldrenderer.pos(x, y + (float)height, 0.0).tex(0.0f * f, (float)height * f2).endVertex();
        worldrenderer.pos(x + (float)width, y + (float)height, 0.0).tex((float)width * f, (float)height * f2).endVertex();
        worldrenderer.pos(x + (float)width, y, 0.0).tex((float)width * f, 0.0f * f2).endVertex();
        worldrenderer.pos(x, y, 0.0).tex(0.0f * f, 0.0f * f2).endVertex();
        tessellator.draw();
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
    }

    public static void drawImage(ResourceLocation imageLocation, double x, double y, double width, double height, int color) {
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(770, 771);
        GlStateManager.disableAlpha();
        Client.mc.getTextureManager().bindTexture(imageLocation);
        RenderUtil.color(color);
        Gui.drawModalRectWithCustomSizedTexture((float)x, (float)y, 0.0f, 0.0f, (float)width, (float)height, (float)width, (float)height);
        GlStateManager.resetColor();
        GlStateManager.bindTexture(0);
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawImage2(ResourceLocation image, float x, float y, int width, int height, float alpha) {
        RenderUtil.setTextureFliterTypeToLinear();
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDepthMask(false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, alpha);
        Client.mc.getTextureManager().bindTexture(image);
        float f = 1.0f / (float)width;
        float f2 = 1.0f / (float)height;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldrenderer.pos(x, y + (float)height, 0.0).tex(0.0f * f, (float)height * f2).endVertex();
        worldrenderer.pos(x + (float)width, y + (float)height, 0.0).tex((float)width * f, (float)height * f2).endVertex();
        worldrenderer.pos(x + (float)width, y, 0.0).tex((float)width * f, 0.0f * f2).endVertex();
        worldrenderer.pos(x, y, 0.0).tex(0.0f * f, 0.0f * f2).endVertex();
        tessellator.draw();
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
    }

    public static void bindTexture(int texture) {
        GL11.glBindTexture(3553, texture);
    }

    public static void drawImageRound(ResourceLocation imageLocation, double x, double y, double width, double height, int color, Runnable cutMethod) {
        GlStateManager.pushMatrix();
        StencilUtil.initStencilToWrite();
        cutMethod.run();
        StencilUtil.readStencilBuffer(1);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(770, 771);
        GlStateManager.disableAlpha();
        Client.mc.getTextureManager().bindTexture(imageLocation);
        RenderUtil.color(color);
        Gui.drawModalRectWithCustomSizedTexture((float)x, (float)y, 0.0f, 0.0f, (float)width, (float)height, (float)width, (float)height);
        GlStateManager.resetColor();
        GlStateManager.bindTexture(0);
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        StencilUtil.uninitStencilBuffer();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawBigHead(float x, float y, float width, float height, AbstractClientPlayer player) {
        double offset = -(player.hurtTime * 23);
        RenderUtil.color(new Color(255, (int)(255.0 + offset), (int)(255.0 + offset)).getRGB());
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(770, 771);
        Client.mc.getTextureManager().bindTexture(player.getLocationSkin());
        Gui.drawScaledCustomSizeModalRect(x, y, 8.0f, 8.0f, 8, 8, width, height, 64.0f, 64.0f);
        GlStateManager.disableBlend();
        GlStateManager.resetColor();
    }

    public static void setSplashScreen(ScaledResolution sr, Framebuffer framebuffer) {
        framebuffer.bindFramebuffer(false);
        GlStateManager.matrixMode(5889);
        GlStateManager.loadIdentity();
        GlStateManager.ortho(0.0, sr.getScaledWidth(), sr.getScaledHeight(), 0.0, 1000.0, 3000.0);
        GlStateManager.matrixMode(5888);
        GlStateManager.loadIdentity();
        GlStateManager.translate(0.0f, 0.0f, -2000.0f);
        GlStateManager.disableLighting();
        GlStateManager.disableFog();
        GlStateManager.disableDepth();
        GlStateManager.enableTexture2D();
    }

    public static void renderSplashScreen(ScaledResolution sr, Framebuffer framebuffer) {
        GlStateManager.disableLighting();
        GlStateManager.disableFog();
        GlStateManager.disableDepth();
        GlStateManager.enableTexture2D();
        framebuffer.unbindFramebuffer();
        framebuffer.framebufferRender(sr.getScaledWidth() * sr.getScaleFactor(), sr.getScaledHeight() * sr.getScaleFactor());
    }

    public static void drawBigHeadRound(float x, float y, float width, float height, AbstractClientPlayer player) {
        StencilUtil.write(false);
        RenderUtil.renderRoundedRect(x, y, width, height, 8.0f, -1);
        StencilUtil.erase(true);
        RenderUtil.color(-1);
        RenderUtil.drawBigHead(x, y, width, height, player);
        StencilUtil.dispose();
        GlStateManager.disableBlend();
    }

    public static void drawESPRect(float left, float top, float right, float bottom, int color) {
        if (left < right) {
            float i = left;
            left = right;
            right = i;
        }
        if (top < bottom) {
            float j = top;
            top = bottom;
            bottom = j;
        }
        float f3 = (float)(color >> 24 & 0xFF) / 255.0f;
        float f = (float)(color >> 16 & 0xFF) / 255.0f;
        float f1 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f2 = (float)(color & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(f, f1, f2, f3);
        worldrenderer.begin(7, DefaultVertexFormats.POSITION);
        worldrenderer.pos(left, bottom, 0.0).endVertex();
        worldrenderer.pos(right, bottom, 0.0).endVertex();
        worldrenderer.pos(right, top, 0.0).endVertex();
        worldrenderer.pos(left, top, 0.0).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawRectBordered(double x, double y, double x1, double y1, double width, int internalColor, int borderColor) {
        RenderUtil.rectangle(x + width, y + width, x1 - width, y1 - width, internalColor);
        RenderUtil.rectangle(x + width, y, x1 - width, y + width, borderColor);
        RenderUtil.rectangle(x, y, x + width, y1, borderColor);
        RenderUtil.rectangle(x1 - width, y, x1, y1, borderColor);
        RenderUtil.rectangle(x + width, y1 - width, x1 - width, y1, borderColor);
    }

    public static void rectangle(double left, double top, double right, double bottom, int color) {
        double var5;
        if (left < right) {
            var5 = left;
            left = right;
            right = var5;
        }
        if (top < bottom) {
            var5 = top;
            top = bottom;
            bottom = var5;
        }
        float var6 = (float)(color >> 24 & 0xFF) / 255.0f;
        float var7 = (float)(color >> 16 & 0xFF) / 255.0f;
        float var8 = (float)(color >> 8 & 0xFF) / 255.0f;
        float var9 = (float)(color & 0xFF) / 255.0f;
        WorldRenderer worldRenderer = Tessellator.getInstance().getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(var7, var8, var9, var6);
        worldRenderer.begin(7, DefaultVertexFormats.POSITION);
        worldRenderer.pos(left, bottom, 0.0).endVertex();
        worldRenderer.pos(right, bottom, 0.0).endVertex();
        worldRenderer.pos(right, top, 0.0).endVertex();
        worldRenderer.pos(left, top, 0.0).endVertex();
        Tessellator.getInstance().draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static ScaledResolution getScaledResolution() {
        int displayWidth = Display.getWidth();
        int displayHeight = Display.getHeight();
        float guiScale = Client.mc.gameSettings.guiScale;
        if (displayWidth != lastScaledWidth || displayHeight != lastScaledHeight || guiScale != lastGuiScale) {
            lastScaledWidth = displayWidth;
            lastScaledHeight = displayHeight;
            lastGuiScale = guiScale;
            scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
            return scaledResolution;
        }
        return scaledResolution;
    }

    public static void renderRoundedRect(float x, float y, float width, float height, float radius, int color) {
        RenderUtil.drawGoodCircle(x + radius, y + radius, radius, color);
        RenderUtil.drawGoodCircle(x + width - radius, y + radius, radius, color);
        RenderUtil.drawGoodCircle(x + radius, y + height - radius, radius, color);
        RenderUtil.drawGoodCircle(x + width - radius, y + height - radius, radius, color);
        Gui.drawRect3(x + radius, y, width - radius * 2.0f, height, color);
        Gui.drawRect3(x, y + radius, width, height - radius * 2.0f, color);
    }

    public static void drawCircleCGUI(double x, double y, float radius, int color) {
        if (radius == 0.0f) {
            return;
        }
        float correctRadius = radius * 2.0f;
        GLUtil.setup2DRendering(() -> {
            RenderUtil.glColor(color);
            GL11.glEnable(2832);
            GL11.glHint(3153, 4354);
            GL11.glPointSize(correctRadius);
            GLUtil.setupRendering(0, () -> GL11.glVertex2d(x, y));
            GL11.glDisable(2832);
            GlStateManager.resetColor();
        });
    }

    public static void drawGoodCircle(double x, double y, float radius, int color) {
        RenderUtil.color(color);
        GLUtil.setup2DRendering(() -> {
            GL11.glEnable(2832);
            GL11.glHint(3153, 4354);
            GL11.glPointSize(radius * (float)(2 * Minecraft.getMinecraft().gameSettings.guiScale));
            GLUtil.render(0, () -> GL11.glVertex2d(x, y));
        });
    }

    public static void drawSolidBlockESP(double x, double y, double z, int color) {
        Client.mc.getRenderManager();
        double xPos = x - RenderManager.renderPosX;
        Client.mc.getRenderManager();
        double yPos = y - RenderManager.renderPosY;
        Client.mc.getRenderManager();
        double zPos = z - RenderManager.renderPosZ;
        float f = (float)(color >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(color & 0xFF) / 255.0f;
        float f4 = (float)(color >> 24 & 0xFF) / 255.0f;
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.0f);
        GL11.glColor4f(f, f2, f3, f4);
        RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(xPos, yPos, zPos, xPos + 1.0, yPos + 1.0, zPos + 1.0));
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
    }

    public static void drawOutlinedBoundingBox(AxisAlignedBB axisAlignedBB) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.begin(3, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(3, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(1, DefaultVertexFormats.POSITION);
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ).endVertex();
        worldRenderer.pos(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ).endVertex();
        tessellator.draw();
    }

    public static void drawSolidBlockESP(BlockPos pos, int color) {
        double d = pos.getX();
        Client.mc.getRenderManager();
        double xPos = d - RenderManager.renderPosX;
        double d2 = pos.getY();
        Client.mc.getRenderManager();
        double yPos = d2 - RenderManager.renderPosY;
        double d3 = pos.getZ();
        Client.mc.getRenderManager();
        double zPos = d3 - RenderManager.renderPosZ;
        double height = Client.mc.theWorld.getBlockState(pos).getBlock().getBlockBoundsMaxY() - Client.mc.theWorld.getBlockState(pos).getBlock().getBlockBoundsMinY();
        float f = (float)(color >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(color & 0xFF) / 255.0f;
        float f4 = (float)(color >> 24 & 0xFF) / 255.0f;
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.0f);
        GL11.glColor4f(f, f2, f3, f4);
        RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(xPos, yPos, zPos, xPos + 1.0, yPos + height, zPos + 1.0));
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
        GlStateManager.disableBlend();
        GL11.glPopMatrix();
    }

    public static void drawLine(BlockPos blockPos, int color) {
        Minecraft mc = Minecraft.getMinecraft();
        double d = blockPos.getX();
        mc.getRenderManager();
        double renderPosXDelta = d - RenderManager.renderPosX + 0.5;
        double d2 = blockPos.getY();
        mc.getRenderManager();
        double renderPosYDelta = d2 - RenderManager.renderPosY + 0.5;
        double d3 = blockPos.getZ();
        mc.getRenderManager();
        double renderPosZDelta = d3 - RenderManager.renderPosZ + 0.5;
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glEnable(2848);
        GL11.glDisable(2929);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glLineWidth(1.0f);
        float blockPos9 = (float)(mc.thePlayer.posX - (double)blockPos.getX());
        float blockPos7 = (float)(mc.thePlayer.posY - (double)blockPos.getY());
        float f = (float)(color >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(color & 0xFF) / 255.0f;
        float f4 = (float)(color >> 24 & 0xFF) / 255.0f;
        GL11.glColor4f(f, f2, f3, f4);
        GL11.glLoadIdentity();
        boolean previousState = mc.gameSettings.viewBobbing;
        mc.gameSettings.viewBobbing = false;
        mc.entityRenderer.orientCamera(mc.timer.renderPartialTicks);
        GL11.glBegin(3);
        GL11.glVertex3d(0.0, mc.thePlayer.getEyeHeight(), 0.0);
        GL11.glVertex3d(renderPosXDelta, renderPosYDelta, renderPosZDelta);
        GL11.glVertex3d(renderPosXDelta, renderPosYDelta, renderPosZDelta);
        GL11.glEnd();
        mc.gameSettings.viewBobbing = previousState;
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
    }

    public static void enableRender3D(boolean disableDepth) {
        if (disableDepth) {
            GL11.glDepthMask(false);
            GL11.glDisable(2929);
        }
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLineWidth(1.0f);
    }

    public static void disableRender3D(boolean enableDepth) {
        if (enableDepth) {
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
        }
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glEnable(3008);
        GL11.glDisable(2848);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static boolean isHovering(float x, float y, float width, float height, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseY >= y && (float)mouseX < x + width && (float)mouseY < y + height;
    }

    public static boolean isInViewFrustrum(Entity entity) {
        return RenderUtil.isInViewFrustrum(entity.getEntityBoundingBox()) || entity.ignoreFrustumCheck;
    }

    private static boolean isInViewFrustrum(AxisAlignedBB bb) {
        Entity current = Client.mc.getRenderViewEntity();
        FRUSTUM.setPosition(current.posX, current.posY, current.posZ);
        return FRUSTUM.isBoundingBoxInFrustum(bb);
    }

    public static void drawRoundedRect(float left, float top, float right, float bottom, float radius, int points, int color) {
        float f3 = (float)(color >> 24 & 0xFF) / 255.0f;
        float f = (float)(color >> 16 & 0xFF) / 255.0f;
        float f1 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f2 = (float)(color & 0xFF) / 255.0f;
        if (left < right) {
            float f4 = left + right;
            right = left;
            left = f4 - right;
        }
        if (top < bottom) {
            float f5 = top + bottom;
            bottom = top;
            top = f5 - bottom;
        }
        float[][] corners = new float[][]{{right + radius, top - radius, 270.0f}, {left - radius, top - radius, 360.0f}, {left - radius, bottom + radius, 90.0f}, {right + radius, bottom + radius, 180.0f}};
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.alphaFunc(516, 0.003921569f);
        GlStateManager.color(f, f1, f2, f3);
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer renderer = tessellator.getWorldRenderer();
        renderer.begin(9, DefaultVertexFormats.POSITION);
        for (float[] c : corners) {
            for (int i = 0; i <= points; ++i) {
                double anglerad = Math.PI * (double)(c[2] + (float)i * 90.0f / (float)points) / 180.0;
                renderer.pos((double)c[0] + Math.sin(anglerad) * (double)radius, (double)c[1] + Math.cos(anglerad) * (double)radius, 0.0).endVertex();
            }
        }
        tessellator.draw();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
    }

    public static void drawCircle(Entity entity, double rad, boolean shade) {
        GL11.glPushMatrix();
        GL11.glDisable(3553);
        GL11.glEnable(2848);
        GL11.glEnable(2832);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
        GL11.glHint(3153, 4354);
        GL11.glDepthMask(false);
        GlStateManager.alphaFunc(516, 0.0f);
        if (shade) {
            GL11.glShadeModel(7425);
        }
        GlStateManager.disableCull();
        GL11.glBegin(5);
        double d = MathUtils.interpolate2(entity.posX, entity.lastTickPosX, Client.mc.timer.renderPartialTicks);
        Client.mc.getRenderManager();
        double x = d - RenderManager.renderPosX;
        double d2 = MathUtils.interpolate2(entity.posY, entity.lastTickPosY, Client.mc.timer.renderPartialTicks);
        Client.mc.getRenderManager();
        double y = d2 - RenderManager.renderPosY + Math.sin((double)System.currentTimeMillis() / 200.0) + 1.0;
        double d3 = MathUtils.interpolate2(entity.posZ, entity.lastTickPosZ, Client.mc.timer.renderPartialTicks);
        Client.mc.getRenderManager();
        double z = d3 - RenderManager.renderPosZ;
        float i = 0.0f;
        while ((double)i < Math.PI * 2) {
            double vecX = x + rad * Math.cos(i);
            double vecZ = z + rad * Math.sin(i);
            Color c = HUD.color(Math.round(i * 100.0f) / 200);
            if (shade) {
                GL11.glColor4f((float)c.getRed() / 255.0f, (float)c.getGreen() / 255.0f, (float)c.getBlue() / 255.0f, 0.0f);
                GL11.glVertex3d(vecX, y - Math.cos((double)System.currentTimeMillis() / 200.0) / 2.0, vecZ);
                GL11.glColor4f((float)c.getRed() / 255.0f, (float)c.getGreen() / 255.0f, (float)c.getBlue() / 255.0f, 0.85f);
            }
            GL11.glVertex3d(vecX, y, vecZ);
            i = (float)((double)i + 0.09817477042468103);
        }
        GL11.glEnd();
        if (shade) {
            GL11.glShadeModel(7424);
        }
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GlStateManager.alphaFunc(516, 0.1f);
        GlStateManager.enableCull();
        GL11.glDisable(2848);
        GL11.glDisable(2832);
        GL11.glEnable(3042);
        GL11.glEnable(3553);
        GL11.glPopMatrix();
        GL11.glColor3f(255.0f, 255.0f, 255.0f);
    }

    public static void drawHorizontalGradientSideways(double x, double y, double width, double height, int leftColor, int rightColor) {
        GLUtil.setup2DRendering(() -> {
            GL11.glShadeModel(7425);
            GLUtil.setupRendering(7, () -> {
                RenderUtil.color(leftColor);
                GL11.glVertex2d(x, y);
                GL11.glVertex2d(x, y + height);
                RenderUtil.color(rightColor);
                GL11.glVertex2d(x + width, y + height);
                GL11.glVertex2d(x + width, y);
                GlStateManager.resetColor();
            });
            GL11.glShadeModel(7424);
        });
    }

    public static double[] getInterpolatedPosServer(Entity entity) {
        float ticks = Client.mc.timer.renderPartialTicks;
        double d0 = (double)entity.serverPosX / 32.0;
        double d2 = (double)entity.serverPosY / 32.0;
        double d3 = (double)entity.serverPosZ / 32.0;
        return new double[]{MathUtils.interpolate(entity.lastTickPosX, entity.serverPosX, ticks) - Client.mc.getRenderManager().viewerPosX, MathUtils.interpolate(entity.lastTickPosY, entity.serverPosY, ticks) - Client.mc.getRenderManager().viewerPosY, MathUtils.interpolate(entity.lastTickPosZ, entity.serverPosZ, ticks) - Client.mc.getRenderManager().viewerPosZ};
    }

    public static AxisAlignedBB getInterpolatedBoundingBoxServer(Entity entity) {
        double[] renderingEntityPos = RenderUtil.getInterpolatedPosServer(entity);
        double entityRenderWidth = (double)entity.width / 1.5;
        return new AxisAlignedBB(renderingEntityPos[0] - entityRenderWidth, renderingEntityPos[1], renderingEntityPos[2] - entityRenderWidth, renderingEntityPos[0] + entityRenderWidth, renderingEntityPos[1] + (double)entity.height + (entity.isSneaking() ? -0.3 : 0.18), renderingEntityPos[2] + entityRenderWidth).expand(0.15, 0.15, 0.15);
    }

    public static double[] getInterpolatedPos(Entity entity) {
        float ticks = Client.mc.timer.renderPartialTicks;
        return new double[]{MathUtils.interpolate(entity.lastTickPosX, entity.posX, ticks) - Client.mc.getRenderManager().viewerPosX, MathUtils.interpolate(entity.lastTickPosY, entity.posY, ticks) - Client.mc.getRenderManager().viewerPosY, MathUtils.interpolate(entity.lastTickPosZ, entity.posZ, ticks) - Client.mc.getRenderManager().viewerPosZ};
    }

    public static AxisAlignedBB getInterpolatedBoundingBox(Entity entity) {
        double[] renderingEntityPos = RenderUtil.getInterpolatedPos(entity);
        double entityRenderWidth = (double)entity.width / 1.5;
        return new AxisAlignedBB(renderingEntityPos[0] - entityRenderWidth, renderingEntityPos[1], renderingEntityPos[2] - entityRenderWidth, renderingEntityPos[0] + entityRenderWidth, renderingEntityPos[1] + (double)entity.height + (entity.isSneaking() ? -0.3 : 0.18), renderingEntityPos[2] + entityRenderWidth).expand(0.05, 0.05, 0.05);
    }

    public static void renderBoundingBoxServer(EntityLivingBase entityLivingBase, Color color, float alpha) {
        AxisAlignedBB bb = RenderUtil.getInterpolatedBoundingBoxServer(entityLivingBase);
        GlStateManager.pushMatrix();
        GLUtil.setup2DRendering();
        GLUtil.enableCaps(3042, 2832, 2881, 2848);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(3.0f);
        GL11.glColor4f((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), alpha);
        RenderUtil.color(RenderUtil.reAlpha(color, (int)alpha).getRGB());
        RenderGlobal.func_181561_a(bb, false, true);
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GLUtil.disableCaps();
        GLUtil.end2DRendering();
        GlStateManager.popMatrix();
    }

    public static void renderBoundingBox(EntityLivingBase entityLivingBase, Color color, float alpha) {
        AxisAlignedBB bb = RenderUtil.getInterpolatedBoundingBox(entityLivingBase);
        GlStateManager.pushMatrix();
        GLUtil.setup2DRendering();
        GLUtil.enableCaps(3042, 2832, 2881, 2848);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(3.0f);
        GL11.glColor4f((float)color.getRed(), (float)color.getGreen(), (float)color.getBlue(), alpha);
        RenderUtil.color(RenderUtil.reAlpha(color, (int)alpha).getRGB());
        RenderGlobal.func_181561_a(bb, false, true);
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GLUtil.disableCaps();
        GLUtil.end2DRendering();
        GlStateManager.popMatrix();
    }

    public static void drawVerticalGradientSideways(double x, double y, double width, double height, int topColor, int bottomColor) {
        GLUtil.setup2DRendering(() -> {
            GL11.glShadeModel(7425);
            GLUtil.setupRendering(7, () -> {
                RenderUtil.color(topColor);
                GL11.glVertex2d(x + width, y);
                GL11.glVertex2d(x, y);
                RenderUtil.color(bottomColor);
                GL11.glVertex2d(x, y + height);
                GL11.glVertex2d(x + width, y + height);
                GlStateManager.resetColor();
            });
            GL11.glShadeModel(7424);
        });
    }

    public static int width() {
        return new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth();
    }

    public static int height() {
        return new ScaledResolution(Minecraft.getMinecraft()).getScaledHeight();
    }

    public static void color(int color, float alpha) {
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        GlStateManager.color(r, g, b, alpha);
    }

    public static void color(int color) {
        float f = (float)(color >> 24 & 0xFF) / 255.0f;
        float f1 = (float)(color >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(color & 0xFF) / 255.0f;
        GL11.glColor4f(f1, f2, f3, f);
    }

    public static void startGlScissor(int x, int y, int width, int height) {
        Minecraft mc = Minecraft.getMinecraft();
        int scaleFactor = 1;
        int k = mc.gameSettings.guiScale;
        if (k == 0) {
            k = 1000;
        }
        while (scaleFactor < k && mc.displayWidth / (scaleFactor + 1) >= 320 && mc.displayHeight / (scaleFactor + 1) >= 240) {
            ++scaleFactor;
        }
        GL11.glPushMatrix();
        GL11.glEnable(3089);
        GL11.glScissor(x * scaleFactor, mc.displayHeight - (y + height) * scaleFactor, width * scaleFactor, height * scaleFactor);
    }

    public static void stopGlScissor() {
        GL11.glDisable(3089);
        GL11.glPopMatrix();
    }

    public static void drawRect(double left, double top, double right, double bottom, int color) {
        if (left < right) {
            double i = left;
            left = right;
            right = i;
        }
        if (top < bottom) {
            double j = top;
            top = bottom;
            bottom = j;
        }
        RenderUtil.resetColor();
        RenderUtil.setAlphaLimit(0.0f);
        GLUtil.setup2DRendering(true);
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        worldrenderer.pos(left, bottom, 0.0).color(color).endVertex();
        worldrenderer.pos(right, bottom, 0.0).color(color).endVertex();
        worldrenderer.pos(right, top, 0.0).color(color).endVertex();
        worldrenderer.pos(left, top, 0.0).color(color).endVertex();
        tessellator.draw();
        GLUtil.end2DRendering();
    }

    public static void resetColor() {
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static void drawGradientRectBordered(double left, double top, double right, double bottom, double width, int startColor, int endColor, int borderStartColor, int borderEndColor) {
        RenderUtil.drawGradientRect(left + width, top + width, right - width, bottom - width, startColor, endColor);
        RenderUtil.drawGradientRect(left + width, top, right - width, top + width, borderStartColor, borderEndColor);
        RenderUtil.drawGradientRect(left, top, left + width, bottom, borderStartColor, borderEndColor);
        RenderUtil.drawGradientRect(right - width, top, right, bottom, borderStartColor, borderEndColor);
        RenderUtil.drawGradientRect(left + width, bottom - width, right - width, bottom, borderStartColor, borderEndColor);
    }

    public static void drawGradientRect(float x, float y, float width, float height, int firstColor, int secondColor, boolean perpendicular) {
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glPushMatrix();
        GL11.glShadeModel(7425);
        GL11.glBegin(7);
        RenderUtil.color(firstColor);
        GL11.glVertex2d(width, y);
        if (perpendicular) {
            RenderUtil.color(secondColor);
        }
        GL11.glVertex2d(x, y);
        RenderUtil.color(secondColor);
        GL11.glVertex2d(x, height);
        if (perpendicular) {
            RenderUtil.color(firstColor);
        }
        GL11.glVertex2d(width, height);
        GL11.glEnd();
        GL11.glShadeModel(7424);
        GL11.glPopMatrix();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glPopMatrix();
    }

    public static void drawGradientRect(double left, double top, double right, double bottom, int startColor, int endColor) {
        GLUtil.setup2DRendering();
        GL11.glEnable(2848);
        GL11.glShadeModel(7425);
        GL11.glPushMatrix();
        GL11.glBegin(7);
        RenderUtil.color(startColor);
        GL11.glVertex2d(left, top);
        GL11.glVertex2d(left, bottom);
        RenderUtil.color(endColor);
        GL11.glVertex2d(right, bottom);
        GL11.glVertex2d(right, top);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glDisable(2848);
        GLUtil.end2DRendering();
        RenderUtil.resetColor();
    }

    public static void drawRectWH(double x, double y, double width, double height, int color) {
        RenderUtil.resetColor();
        RenderUtil.setAlphaLimit(0.0f);
        GLUtil.setup2DRendering(true);
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        worldrenderer.pos(x, y, 0.0).color(color).endVertex();
        worldrenderer.pos(x, y + height, 0.0).color(color).endVertex();
        worldrenderer.pos(x + width, y + height, 0.0).color(color).endVertex();
        worldrenderer.pos(x + width, y, 0.0).color(color).endVertex();
        tessellator.draw();
        GLUtil.end2DRendering();
    }

    public static void setAlphaLimit(float limit) {
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, (float)((double)limit * 0.01));
    }

    public static Color reAlpha(Color color, int alpha) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }

    public static void scaleStart(float x, float y, float scale) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0.0f);
        GlStateManager.scale(scale, scale, 1.0f);
        GlStateManager.translate(-x, -y, 0.0f);
    }

    public static void scaleEnd() {
        GlStateManager.popMatrix();
    }

    public static double getFrameDeltaTime() {
        return frameDeltaTime;
    }

    public static void setFrameDeltaTime(double frameDeltaTime) {
        RenderUtil.frameDeltaTime = frameDeltaTime;
    }

    static {
        ticks = 0.0;
        lastFrame = 0L;
        FRUSTUM = new Frustum();
        roundedShader = new ShaderUtil("roundedRect");
        glCapMap = new HashMap<Integer, Boolean>();
        frameDeltaTime = 0.0;
        DISPLAY_LISTS_2D = new int[4];
        for (int i = 0; i < DISPLAY_LISTS_2D.length; ++i) {
            RenderUtil.DISPLAY_LISTS_2D[i] = GL11.glGenLists(1);
        }
        GL11.glNewList(DISPLAY_LISTS_2D[0], 4864);
        RenderUtil.quickDrawRect(-7.0f, 2.0f, -4.0f, 3.0f);
        RenderUtil.quickDrawRect(4.0f, 2.0f, 7.0f, 3.0f);
        RenderUtil.quickDrawRect(-7.0f, 0.5f, -6.0f, 3.0f);
        RenderUtil.quickDrawRect(6.0f, 0.5f, 7.0f, 3.0f);
        GL11.glEndList();
        GL11.glNewList(DISPLAY_LISTS_2D[1], 4864);
        RenderUtil.quickDrawRect(-7.0f, 3.0f, -4.0f, 3.3f);
        RenderUtil.quickDrawRect(4.0f, 3.0f, 7.0f, 3.3f);
        RenderUtil.quickDrawRect(-7.3f, 0.5f, -7.0f, 3.3f);
        RenderUtil.quickDrawRect(7.0f, 0.5f, 7.3f, 3.3f);
        GL11.glEndList();
        GL11.glNewList(DISPLAY_LISTS_2D[2], 4864);
        RenderUtil.quickDrawRect(4.0f, -20.0f, 7.0f, -19.0f);
        RenderUtil.quickDrawRect(-7.0f, -20.0f, -4.0f, -19.0f);
        RenderUtil.quickDrawRect(6.0f, -20.0f, 7.0f, -17.5f);
        RenderUtil.quickDrawRect(-7.0f, -20.0f, -6.0f, -17.5f);
        GL11.glEndList();
        GL11.glNewList(DISPLAY_LISTS_2D[3], 4864);
        RenderUtil.quickDrawRect(7.0f, -20.0f, 7.3f, -17.5f);
        RenderUtil.quickDrawRect(-7.3f, -20.0f, -7.0f, -17.5f);
        RenderUtil.quickDrawRect(4.0f, -20.3f, 7.3f, -20.0f);
        RenderUtil.quickDrawRect(-7.3f, -20.3f, -4.0f, -20.0f);
        GL11.glEndList();
    }
}

