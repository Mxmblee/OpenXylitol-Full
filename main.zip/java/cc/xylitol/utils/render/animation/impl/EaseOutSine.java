package cc.xylitol.utils.render.animation.impl;

import cc.xylitol.utils.render.animation.Animation;
import cc.xylitol.utils.render.animation.Direction;

public class EaseOutSine
extends Animation {
    public EaseOutSine(int ms, double endPoint) {
        super(ms, endPoint);
    }

    public EaseOutSine(int ms, double endPoint, Direction direction) {
        super(ms, endPoint, direction);
    }

    @Override
    protected boolean correctOutput() {
        return true;
    }

    @Override
    protected double getEquation(double x) {
        return Math.sin(x * 1.5707963267948966);
    }
}

