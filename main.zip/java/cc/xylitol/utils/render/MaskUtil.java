package cc.xylitol.utils.render;

import org.lwjgl.opengl.GL11;

public class MaskUtil {
    public static void defineMask() {
        GL11.glDepthMask(true);
        GL11.glClearDepth(1.0);
        GL11.glClear(256);
        GL11.glDepthFunc(519);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glColorMask(false, false, false, false);
    }

    public static void finishDefineMask() {
        GL11.glDepthMask(false);
        GL11.glColorMask(true, true, true, true);
    }

    public static void drawOnMask() {
        GL11.glDepthFunc(514);
    }

    public static void drawOffMask() {
        GL11.glDepthFunc(517);
    }

    public static void drawMCMask() {
        GL11.glDepthFunc(515);
    }

    public static void resetMask() {
        GL11.glDepthMask(true);
        GL11.glClearDepth(1.0);
        GL11.glClear(256);
        MaskUtil.drawMCMask();
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
    }
}

