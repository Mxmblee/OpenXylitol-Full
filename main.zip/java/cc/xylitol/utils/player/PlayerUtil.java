package cc.xylitol.utils.player;

import cc.xylitol.utils.player.RotationUtil;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

public final class PlayerUtil {
    public static int getSpeedPotion() {
        return RotationUtil.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? RotationUtil.mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1 : 0;
    }

    public static Block block(double x, double y, double z) {
        return RotationUtil.mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
    }

    public static boolean colorTeam(EntityPlayer sb) {
        String targetName = sb.getDisplayName().getFormattedText().replace("\u00a7r", "");
        String clientName = RotationUtil.mc.thePlayer.getDisplayName().getFormattedText().replace("\u00a7r", "");
        return targetName.startsWith("\u00a7" + clientName.charAt(1));
    }

    public static boolean armorTeam(EntityPlayer entityPlayer) {
        if (RotationUtil.mc.thePlayer.inventory.armorInventory[3] != null && entityPlayer.inventory.armorInventory[3] != null) {
            ItemStack myHead = RotationUtil.mc.thePlayer.inventory.armorInventory[3];
            ItemArmor myItemArmor = (ItemArmor)myHead.getItem();
            ItemStack entityHead = entityPlayer.inventory.armorInventory[3];
            ItemArmor entityItemArmor = (ItemArmor)entityHead.getItem();
            if (String.valueOf(entityItemArmor.getColor(entityHead)).equals("10511680")) {
                return true;
            }
            return myItemArmor.getColor(myHead) == entityItemArmor.getColor(entityHead);
        }
        return false;
    }

    public static boolean isBlockUnder(double height) {
        return PlayerUtil.isBlockUnder(height, true);
    }

    public static boolean isBlockUnder(double height, boolean boundingBox) {
        if (boundingBox) {
            int offset = 0;
            while ((double)offset < height) {
                AxisAlignedBB bb = RotationUtil.mc.thePlayer.getEntityBoundingBox().offset(0.0, -offset, 0.0);
                if (!RotationUtil.mc.theWorld.getCollidingBoundingBoxes(RotationUtil.mc.thePlayer, bb).isEmpty()) {
                    return true;
                }
                offset += 2;
            }
        } else {
            int offset = 0;
            while ((double)offset < height) {
                if (PlayerUtil.blockRelativeToPlayer(0.0, -offset, 0.0).isFullBlock()) {
                    return true;
                }
                ++offset;
            }
        }
        return false;
    }

    public static int findSoup() {
        for (int i = 36; i < 45; ++i) {
            ItemStack itemStack = RotationUtil.mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (itemStack == null || !itemStack.getItem().equals(Items.mushroom_stew) || itemStack.stackSize <= 0 || !(itemStack.getItem() instanceof ItemFood)) continue;
            return i;
        }
        return -1;
    }

    public static boolean hasSpaceHotBar() {
        for (int i = 36; i < 45; ++i) {
            ItemStack itemStack = RotationUtil.mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (itemStack != null) continue;
            return true;
        }
        return false;
    }

    public static int findItem(int startSlot, int endSlot, Item item) {
        for (int i = startSlot; i < endSlot; ++i) {
            ItemStack stack = RotationUtil.mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (stack == null || stack.getItem() != item) continue;
            return i;
        }
        return -1;
    }

    public static Block blockRelativeToPlayer(double offsetX, double offsetY, double offsetZ) {
        return RotationUtil.mc.theWorld.getBlockState(new BlockPos(RotationUtil.mc.thePlayer).add(offsetX, offsetY, offsetZ)).getBlock();
    }

    public static boolean scoreTeam(EntityPlayer entityPlayer) {
        return RotationUtil.mc.thePlayer.isOnSameTeam(entityPlayer);
    }

    private PlayerUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

