package cc.xylitol.utils.player;

import cc.xylitol.Client;
import cc.xylitol.event.impl.events.EventMove;
import cc.xylitol.event.impl.events.EventMoveInput;
import net.minecraft.potion.Potion;
import net.minecraft.util.MathHelper;

public class MoveUtil {
    public static boolean isMoving() {
        return Client.mc.thePlayer != null && (Client.mc.thePlayer.movementInput.moveForward != 0.0f || Client.mc.thePlayer.movementInput.moveStrafe != 0.0f);
    }

    public static double speed() {
        return Math.hypot(Client.mc.thePlayer.motionX, Client.mc.thePlayer.motionZ);
    }

    public static boolean isOnGround(double height) {
        return !Client.mc.theWorld.getCollidingBoundingBoxes(Client.mc.thePlayer, Client.mc.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public static void setMotion2(double d, float f) {
        Client.mc.thePlayer.motionX = -Math.sin(Math.toRadians(f)) * d;
        Client.mc.thePlayer.motionZ = Math.cos(Math.toRadians(f)) * d;
    }

    public static void setMotion(double speed) {
        MoveUtil.setMotion(speed, Client.mc.thePlayer.rotationYaw);
    }

    public static void setMotion(double speed, float yaw) {
        double forward = Client.mc.thePlayer.movementInput.moveForward;
        double strafe = Client.mc.thePlayer.movementInput.moveStrafe;
        if (forward == 0.0 && strafe == 0.0) {
            Client.mc.thePlayer.motionX = 0.0;
            Client.mc.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            Client.mc.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            Client.mc.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
        }
    }

    public static float getDirection(float yaw) {
        return MoveUtil.getDirection(yaw, Client.mc.thePlayer.movementInput.moveForward, Client.mc.thePlayer.movementInput.moveStrafe);
    }

    public static float getDirection(float yaw, float forward, float strafe) {
        if (forward != 0.0f) {
            if (strafe < 0.0f) {
                yaw += forward < 0.0f ? 135.0f : 45.0f;
            } else if (strafe > 0.0f) {
                yaw -= forward < 0.0f ? 135.0f : 45.0f;
            } else if (strafe == 0.0f && forward < 0.0f) {
                yaw -= 180.0f;
            }
        } else if (strafe < 0.0f) {
            yaw += 90.0f;
        } else if (strafe > 0.0f) {
            yaw -= 90.0f;
        }
        return yaw;
    }

    public static void strafe(EventMove moveEvent, double speed, double direction) {
        if (!MoveUtil.isMoving()) {
            return;
        }
        Client.mc.thePlayer.motionX = -Math.sin(direction) * speed;
        moveEvent.setX(Client.mc.thePlayer.motionX);
        Client.mc.thePlayer.motionZ = Math.cos(direction) * speed;
        moveEvent.setZ(Client.mc.thePlayer.motionZ);
    }

    public static double strafe(double d) {
        if (!MoveUtil.isMoving()) {
            return Client.mc.thePlayer.rotationYaw;
        }
        double yaw = MoveUtil.getDirection1();
        Client.mc.thePlayer.motionX = (double)(-MathHelper.sin((float)yaw)) * d;
        Client.mc.thePlayer.motionZ = (double)MathHelper.cos((float)yaw) * d;
        return yaw;
    }

    public static void strafe(double speed, float yaw) {
        if (!MoveUtil.isMoving()) {
            return;
        }
        yaw = (float)Math.toRadians(yaw);
        Client.mc.thePlayer.motionX = (double)(-MathHelper.sin(yaw)) * speed;
        Client.mc.thePlayer.motionZ = (double)MathHelper.cos(yaw) * speed;
    }

    public static void jump() {
        double jumpY = Client.mc.thePlayer.getJumpUpwardsMotion();
        if (Client.mc.thePlayer.isPotionActive(Potion.jump)) {
            jumpY += (float)(Client.mc.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1) * 0.1f;
        }
        Client.mc.thePlayer.motionY = Client.mc.thePlayer.motionY = jumpY;
    }

    public static void fixMovement(EventMoveInput event, float yaw) {
        float forward = event.getForward();
        float strafe = event.getStrafe();
        double angle = MathHelper.wrapAngleTo180_double(Math.toDegrees(MoveUtil.direction(Client.mc.thePlayer.rotationYaw, forward, strafe)));
        if (forward == 0.0f && strafe == 0.0f) {
            return;
        }
        float closestForward = 0.0f;
        float closestStrafe = 0.0f;
        float closestDifference = Float.MAX_VALUE;
        for (float predictedForward = -1.0f; predictedForward <= 1.0f; predictedForward += 1.0f) {
            for (float predictedStrafe = -1.0f; predictedStrafe <= 1.0f; predictedStrafe += 1.0f) {
                double predictedAngle;
                double difference;
                if (predictedStrafe == 0.0f && predictedForward == 0.0f || !((difference = Math.abs(angle - (predictedAngle = MathHelper.wrapAngleTo180_double(Math.toDegrees(MoveUtil.direction(yaw, predictedForward, predictedStrafe)))))) < (double)closestDifference)) continue;
                closestDifference = (float)difference;
                closestForward = predictedForward;
                closestStrafe = predictedStrafe;
            }
        }
        event.setForward(closestForward);
        event.setStrafe(closestStrafe);
    }

    public static double direction(float rotationYaw, double moveForward, double moveStrafing) {
        if (moveForward < 0.0) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (moveForward < 0.0) {
            forward = -0.5f;
        } else if (moveForward > 0.0) {
            forward = 0.5f;
        }
        if (moveStrafing > 0.0) {
            rotationYaw -= 90.0f * forward;
        }
        if (moveStrafing < 0.0) {
            rotationYaw += 90.0f * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    public static double getDirection1() {
        float yaw = Client.mc.thePlayer.rotationYaw;
        if (Client.mc.thePlayer.moveForward < 0.0f) {
            yaw += 180.0f;
        }
        float forward = 1.0f;
        if (Client.mc.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (Client.mc.thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Client.mc.thePlayer.moveStrafing > 0.0f) {
            yaw -= 90.0f * forward;
        } else if (Client.mc.thePlayer.moveStrafing < 0.0f) {
            yaw += 90.0f * forward;
        }
        return Math.toRadians(yaw);
    }

    public static double direction() {
        float rotationYaw = Client.mc.thePlayer.movementYaw;
        if (Client.mc.thePlayer.moveForward < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (Client.mc.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (Client.mc.thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Client.mc.thePlayer.moveStrafing > 0.0f) {
            rotationYaw -= 70.0f * forward;
        }
        if (Client.mc.thePlayer.moveStrafing < 0.0f) {
            rotationYaw += 70.0f * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    public static void stop() {
        Client.mc.thePlayer.motionX = 0.0;
        Client.mc.thePlayer.motionZ = 0.0;
    }
}

