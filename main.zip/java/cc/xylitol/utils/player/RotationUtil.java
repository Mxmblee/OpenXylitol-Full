package cc.xylitol.utils.player;

import cc.xylitol.utils.math.Location;
import cc.xylitol.utils.math.MathUtils;
import cc.xylitol.utils.player.RaytraceUtil;
import cc.xylitol.utils.player.Rotation;
import cc.xylitol.utils.vector.Vector3d;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.apache.commons.lang3.RandomUtils;
import org.lwjglx.util.vector.Vector2f;

public class RotationUtil {
    public static Minecraft mc = Minecraft.getMinecraft();
    private float yaw;
    private float pitch;
    private static final List<Double> xzPercents = Arrays.asList(0.5, 0.4, 0.3, 0.2, 0.1, 0.0, -0.1, -0.2, -0.3, -0.4, -0.5);

    public RotationUtil(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public static Vector2f calculateSimple(Entity entity, double range, double wallRange) {
        AxisAlignedBB aabb = entity.getEntityBoundingBox().contract(-0.05, -0.05, -0.05).contract(0.05, 0.05, 0.05);
        range += 0.05;
        wallRange += 0.05;
        Vec3 eyePos = RotationUtil.mc.thePlayer.getPositionEyes(1.0f);
        Vec3 nearest = new Vec3(MathUtils.clamp(eyePos.xCoord, aabb.minX, aabb.maxX), MathUtils.clamp(eyePos.yCoord, aabb.minY, aabb.maxY), MathUtils.clamp(eyePos.zCoord, aabb.minZ, aabb.maxZ));
        Vector2f rotation = RotationUtil.toRotation(nearest, false);
        if (nearest.subtract(eyePos).lengthSquared() <= wallRange * wallRange) {
            return rotation;
        }
        MovingObjectPosition result = RaytraceUtil.rayCast(rotation, range, 0.0f, false);
        double maxRange = Math.max(wallRange, range);
        if (result != null && result.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY && result.entityHit == entity && result.hitVec.subtract(eyePos).lengthSquared() <= maxRange * maxRange) {
            return rotation;
        }
        return null;
    }

    public static Vector2f calculate(Entity entity, boolean adaptive, double range, double wallRange, boolean predict, boolean randomCenter) {
        MovingObjectPosition normalResult;
        if (RotationUtil.mc.thePlayer == null) {
            return null;
        }
        double rangeSq = range * range;
        double wallRangeSq = wallRange * wallRange;
        Vector2f simpleRotation = RotationUtil.calculateSimple(entity, range, wallRange);
        if (simpleRotation != null) {
            return simpleRotation;
        }
        Vector2f normalRotations = RotationUtil.toRotation(RotationUtil.getVec(entity), predict);
        if (!randomCenter && (normalResult = RaytraceUtil.rayCast(normalRotations, range, 0.0f, false)) != null && normalResult.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY) {
            return normalRotations;
        }
        double yStart = 1.0;
        double yEnd = 0.0;
        double yStep = -0.5;
        if (randomCenter && MathUtils.secureRandom.nextBoolean()) {
            yStart = 0.0;
            yEnd = 1.0;
            yStep = 0.5;
        }
        double yPercent = yStart;
        while (Math.abs(yEnd - yPercent) > 0.001) {
            double xzStart = 0.5;
            double xzEnd = -0.5;
            double xzStep = -0.1;
            if (randomCenter) {
                Collections.shuffle(xzPercents);
            }
            for (double xzPercent : xzPercents) {
                for (int side = 0; side <= 3; ++side) {
                    MovingObjectPosition result;
                    double xPercent = 0.0;
                    double zPercent = 0.0;
                    switch (side) {
                        case 0: {
                            xPercent = xzPercent;
                            zPercent = 0.5;
                            break;
                        }
                        case 1: {
                            xPercent = xzPercent;
                            zPercent = -0.5;
                            break;
                        }
                        case 2: {
                            xPercent = 0.5;
                            zPercent = xzPercent;
                            break;
                        }
                        case 3: {
                            xPercent = -0.5;
                            zPercent = xzPercent;
                        }
                    }
                    Vec3 Vec32 = RotationUtil.getVec(entity).add(new Vec3((entity.getEntityBoundingBox().maxX - entity.getEntityBoundingBox().minX) * xPercent, (entity.getEntityBoundingBox().maxY - entity.getEntityBoundingBox().minY) * yPercent, (entity.getEntityBoundingBox().maxZ - entity.getEntityBoundingBox().minZ) * zPercent));
                    double distanceSq = Vec32.squareDistanceTo(RotationUtil.mc.thePlayer.getPositionEyes(1.0f));
                    Rotation rotation = RotationUtil.toRotationRot(Vec32, predict);
                    rotation.fixedSensitivity(Float.valueOf(RotationUtil.mc.gameSettings.mouseSensitivity));
                    rotation.distanceSq = distanceSq;
                    if (distanceSq <= wallRangeSq && (result = RaytraceUtil.rayCast(rotation.toVec2f(), wallRange, 0.0f, true)) != null && result.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY) {
                        return rotation.toVec2f();
                    }
                    if (!(distanceSq <= rangeSq) || (result = RaytraceUtil.rayCast(rotation.toVec2f(), range, 0.0f, false)) == null || result.typeOfHit != MovingObjectPosition.MovingObjectType.ENTITY) continue;
                    return rotation.toVec2f();
                }
            }
            yPercent += yStep;
        }
        return null;
    }

    public static Vec3 getVec(Entity entity) {
        return new Vec3(entity.posX, entity.posY, entity.posZ);
    }

    public static void setVisualRotations(float yaw, float pitch) {
        RotationUtil.mc.thePlayer.rotationYawHead = RotationUtil.mc.thePlayer.renderYawOffset = yaw;
        RotationUtil.mc.thePlayer.renderPitchHead = pitch;
    }

    public static float[] getBlockPosRotation(BlockPos pos) {
        return RotationUtil.getRotationFromPosition(pos.getX(), pos.getZ(), pos.getY());
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        double xDiff = x - Minecraft.getMinecraft().thePlayer.posX;
        double zDiff = z - Minecraft.getMinecraft().thePlayer.posZ;
        double yDiff = y - Minecraft.getMinecraft().thePlayer.posY - 1.2;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static Vector2f getRotationFromEyeToPoint(javax.vecmath.Vector3d point3d) {
        return RotationUtil.calculate(new javax.vecmath.Vector3d(RotationUtil.mc.thePlayer.posX, RotationUtil.mc.thePlayer.getEntityBoundingBox().minY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), RotationUtil.mc.thePlayer.posZ), point3d);
    }

    public static Vector2f calculate(Entity entity) {
        return RotationUtil.calculate(entity.getCustomPositionVector().add(0.0, Math.max(0.0, Math.min(RotationUtil.mc.thePlayer.posY - entity.posY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), (entity.getEntityBoundingBox().maxY - entity.getEntityBoundingBox().minY) * 0.9)), 0.0));
    }

    public static Vector2f calculate(javax.vecmath.Vector3d from, javax.vecmath.Vector3d to) {
        double x = to.getX() - from.getX();
        double y = to.getY() - from.getY();
        double z = to.getZ() - from.getZ();
        double sqrt = Math.sqrt(x * x + z * z);
        float yaw = (float)Math.toDegrees(Math.atan2(z, x)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(y, sqrt)));
        return new Vector2f(yaw, Math.min(Math.max(pitch, -90.0f), 90.0f));
    }

    public static float getMoveYaw(float yaw) {
        Vector2f from = new Vector2f((float)RotationUtil.mc.thePlayer.lastTickPosX, (float)RotationUtil.mc.thePlayer.lastTickPosZ);
        Vector2f to = new Vector2f((float)RotationUtil.mc.thePlayer.posX, (float)RotationUtil.mc.thePlayer.posZ);
        Vector2f diff = new Vector2f(to.x - from.x, to.y - from.y);
        double x = diff.x;
        double z = diff.y;
        if (x != 0.0 && z != 0.0) {
            yaw = (float)Math.toDegrees((Math.atan2(-x, z) + (double)MathHelper.PI2) % (double)MathHelper.PI2);
        }
        return yaw;
    }

    public static float[] getRotationNormal(EntityLivingBase target) {
        double xDiff = target.posX - RotationUtil.mc.thePlayer.posX;
        double yDiff = target.posY + (double)(target.getEyeHeight() / 5.0f * 4.0f) - (RotationUtil.mc.thePlayer.posY + (double)RotationUtil.mc.thePlayer.getEyeHeight());
        return RotationUtil.getRotationFloat(target, xDiff, yDiff);
    }

    private static float[] getRotationFloat(EntityLivingBase target, double xDiff, double yDiff) {
        double zDiff = target.posZ - RotationUtil.mc.thePlayer.posZ;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(yDiff, dist) * 180.0 / Math.PI);
        float[] array = new float[2];
        int n = 0;
        float rotationYaw = RotationUtil.mc.thePlayer.rotationYaw;
        array[n] = rotationYaw + MathHelper.wrapAngleTo180_float(yaw - RotationUtil.mc.thePlayer.rotationYaw);
        int n3 = 1;
        float rotationPitch = RotationUtil.mc.thePlayer.rotationPitch;
        array[n3] = rotationPitch + MathHelper.wrapAngleTo180_float(pitch - RotationUtil.mc.thePlayer.rotationPitch);
        return array;
    }

    public static Vector2f calculate(Vector3d from, Vector3d to) {
        Vector3d diff = to.subtract(from);
        double distance = Math.hypot(diff.getX(), diff.getZ());
        float yaw = (float)(MathHelper.atan2(diff.getZ(), diff.getX()) * (double)MathHelper.TO_DEGREES) - 90.0f;
        float pitch = (float)(-(MathHelper.atan2(diff.getY(), distance) * (double)MathHelper.TO_DEGREES));
        return new Vector2f(yaw, pitch);
    }

    public static Vector2f calculate(Vec3 to) {
        return RotationUtil.calculate(RotationUtil.mc.thePlayer.getCustomPositionVector().add(0.0, RotationUtil.mc.thePlayer.getEyeHeight(), 0.0), new Vector3d(to.xCoord, to.yCoord, to.zCoord));
    }

    public static Vector2f calculate(Vector3d to) {
        return RotationUtil.calculate(RotationUtil.mc.thePlayer.getCustomPositionVector().add(0.0, RotationUtil.mc.thePlayer.getEyeHeight(), 0.0), to);
    }

    public static Vector2f calculate(Vector3d position, EnumFacing enumFacing) {
        double x = position.getX() + 0.5;
        double y = position.getY() + 0.5;
        double z = position.getZ() + 0.5;
        return RotationUtil.calculate(new Vector3d(x += (double)enumFacing.getDirectionVec().getX() * 0.5, y += (double)enumFacing.getDirectionVec().getY() * 0.5, z += (double)enumFacing.getDirectionVec().getZ() * 0.5));
    }

    private static float[] getRotationsByVec(Vec3 origin, Vec3 position) {
        Vec3 difference = position.subtract(origin);
        double distance = difference.flat().lengthVector();
        float yaw = (float)Math.toDegrees(Math.atan2(difference.zCoord, difference.xCoord)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(difference.yCoord, distance)));
        return new float[]{yaw, pitch};
    }

    public static float[] getRotationBlock(BlockPos pos) {
        return RotationUtil.getRotationsByVec(RotationUtil.mc.thePlayer.getPositionVector().addVector(0.0, RotationUtil.mc.thePlayer.getEyeHeight(), 0.0), new Vec3((double)pos.getX() + 0.51, (double)pos.getY() + 0.51, (double)pos.getZ() + 0.51));
    }

    public static float[] positionRotation(double posX, double posY, double posZ, float[] lastRots, float yawSpeed, float pitchSpeed, boolean random) {
        double x = posX - RotationUtil.mc.thePlayer.posX;
        double y = posY - (RotationUtil.mc.thePlayer.posY + (double)RotationUtil.mc.thePlayer.getEyeHeight());
        double z = posZ - RotationUtil.mc.thePlayer.posZ;
        float calcYaw = (float)(MathHelper.atan2(z, x) * 180.0 / Math.PI - 90.0);
        float calcPitch = (float)(-(MathHelper.atan2(y, MathHelper.sqrt_double(x * x + z * z)) * 180.0 / Math.PI));
        float yaw = RotationUtil.updateRotation(lastRots[0], calcYaw, yawSpeed);
        float pitch = RotationUtil.updateRotation(lastRots[1], calcPitch, pitchSpeed);
        if (random) {
            yaw += (float)ThreadLocalRandom.current().nextGaussian();
            pitch += (float)ThreadLocalRandom.current().nextGaussian();
        }
        return new float[]{yaw, pitch};
    }

    public static int wrapAngleToDirection(float yaw, int zones) {
        int angle = (int)((double)(yaw + (float)(360 / (2 * zones))) + 0.5) % 360;
        if (angle < 0) {
            angle += 360;
        }
        return angle / (360 / zones);
    }

    public static float getGCD() {
        return (float)(Math.pow((double)RotationUtil.mc.gameSettings.mouseSensitivity * 0.6 + 0.2, 3.0) * 1.2);
    }

    public static Vector2f getRotationFromEyeToPointOffset(Vec3 position, EnumFacing enumFacing) {
        double x = position.xCoord + 0.5;
        double y = position.yCoord + 0.5;
        double z = position.zCoord + 0.5;
        return RotationUtil.getRot(new Vec3(x += (double)enumFacing.getDirectionVec().getX() * 0.5, y += (double)enumFacing.getDirectionVec().getY() * 0.5, z += (double)enumFacing.getDirectionVec().getZ() * 0.5));
    }

    public static Vector2f getRot(Vec3 pos) {
        Vec3 vec = new Vec3(RotationUtil.mc.thePlayer.posX, RotationUtil.mc.thePlayer.getEntityBoundingBox().minY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), RotationUtil.mc.thePlayer.posZ);
        double x = pos.xCoord - vec.xCoord;
        double y = pos.yCoord - vec.yCoord;
        double z = pos.zCoord - vec.zCoord;
        double sqrt = Math.sqrt(x * x + z * z);
        float yaw = (float)Math.toDegrees(Math.atan2(z, x)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(y, sqrt)));
        return new Vector2f(yaw, Math.min(Math.max(pitch, -90.0f), 90.0f));
    }

    public static float[] getRotationsToPosition(double x, double y, double z) {
        double deltaX = x - RotationUtil.mc.thePlayer.posX;
        double deltaY = y - RotationUtil.mc.thePlayer.posY - (double)RotationUtil.mc.thePlayer.getEyeHeight();
        double deltaZ = z - RotationUtil.mc.thePlayer.posZ;
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float yaw = (float)Math.toDegrees(-Math.atan2(deltaX, deltaZ));
        float pitch = (float)Math.toDegrees(-Math.atan2(deltaY, horizontalDistance));
        return new float[]{yaw, pitch};
    }

    public static float[] getRotationsToPosition(double x, double y, double z, double targetX, double targetY, double targetZ) {
        double dx = targetX - x;
        double dy = targetY - y;
        double dz = targetZ - z;
        double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)Math.toDegrees(-Math.atan2(dx, dz));
        float pitch = (float)Math.toDegrees(-Math.atan2(dy, horizontalDistance));
        return new float[]{yaw, pitch};
    }

    public static float[] scaffoldRots(double bx, double by, double bz, float lastYaw, float lastPitch, float yawSpeed, float pitchSpeed, boolean random) {
        double x = bx - RotationUtil.mc.thePlayer.posX;
        double y = by - (RotationUtil.mc.thePlayer.posY + (double)RotationUtil.mc.thePlayer.getEyeHeight());
        double z = bz - RotationUtil.mc.thePlayer.posZ;
        float calcYaw = (float)(Math.toDegrees(MathHelper.atan2(z, x)) - 90.0);
        float calcPitch = (float)(-(MathHelper.atan2(y, MathHelper.sqrt_double(x * x + z * z)) * 180.0 / Math.PI));
        float pitch = RotationUtil.updateRotation(lastPitch, calcPitch, pitchSpeed + RandomUtils.nextFloat(0.0f, 15.0f));
        float yaw = RotationUtil.updateRotation(lastYaw, calcYaw, yawSpeed + RandomUtils.nextFloat(0.0f, 15.0f));
        if (random) {
            yaw += (float)ThreadLocalRandom.current().nextDouble(-2.0, 2.0);
            pitch += (float)ThreadLocalRandom.current().nextDouble(-0.2, 0.2);
        }
        return new float[]{yaw, pitch};
    }

    public static float[] mouseSens(float yaw, float pitch, float lastYaw, float lastPitch) {
        if ((double)RotationUtil.mc.gameSettings.mouseSensitivity == 0.5) {
            RotationUtil.mc.gameSettings.mouseSensitivity = 0.47887325f;
        }
        if (yaw == lastYaw && pitch == lastPitch) {
            return new float[]{yaw, pitch};
        }
        float f1 = RotationUtil.mc.gameSettings.mouseSensitivity * 0.6f + 0.2f;
        float f2 = f1 * f1 * f1 * 8.0f;
        int deltaX = (int)((6.667 * (double)yaw - 6.667 * (double)lastYaw) / (double)f2);
        int deltaY = (int)((6.667 * (double)pitch - 6.667 * (double)lastPitch) / (double)f2) * -1;
        float f3 = (float)deltaX * f2;
        float f4 = (float)deltaY * f2;
        yaw = (float)((double)lastYaw + (double)f3 * 0.15);
        float f5 = (float)((double)lastPitch - (double)f4 * 0.15);
        pitch = MathHelper.clamp_float(f5, -90.0f, 90.0f);
        return new float[]{yaw, pitch};
    }

    public static float rotateToYaw(float yawSpeed, float currentYaw, float calcYaw) {
        float yaw = RotationUtil.updateRotation(currentYaw, calcYaw, yawSpeed + RandomUtils.nextFloat(0.0f, 15.0f));
        double diffYaw = MathHelper.wrapAngleTo180_float(calcYaw - currentYaw);
        if ((double)(-yawSpeed) > diffYaw || diffYaw > (double)yawSpeed) {
            yaw += (float)((double)RandomUtils.nextFloat(1.0f, 2.0f) * Math.sin((double)RotationUtil.mc.thePlayer.rotationPitch * Math.PI));
        }
        if (yaw == currentYaw) {
            return currentYaw;
        }
        if ((double)RotationUtil.mc.gameSettings.mouseSensitivity == 0.5) {
            RotationUtil.mc.gameSettings.mouseSensitivity = 0.47887325f;
        }
        float f1 = RotationUtil.mc.gameSettings.mouseSensitivity * 0.6f + 0.2f;
        float f2 = f1 * f1 * f1 * 8.0f;
        int deltaX = (int)((6.667 * (double)yaw - 6.666666666666667 * (double)currentYaw) / (double)f2);
        float f3 = (float)deltaX * f2;
        yaw = (float)((double)currentYaw + (double)f3 * 0.15);
        return yaw;
    }

    public static float updateRotation(float current, float calc, float maxDelta) {
        float f = MathHelper.wrapAngleTo180_float(calc - current);
        if (f > maxDelta) {
            f = maxDelta;
        }
        if (f < -maxDelta) {
            f = -maxDelta;
        }
        return current + f;
    }

    public static float rotateToPitch(float pitchSpeed, float currentPitch, float calcPitch) {
        float pitch = RotationUtil.updateRotation(currentPitch, calcPitch, pitchSpeed + RandomUtils.nextFloat(0.0f, 15.0f));
        if (pitch != calcPitch) {
            pitch += (float)((double)RandomUtils.nextFloat(1.0f, 2.0f) * Math.sin((double)RotationUtil.mc.thePlayer.rotationYaw * Math.PI));
        }
        if ((double)RotationUtil.mc.gameSettings.mouseSensitivity == 0.5) {
            RotationUtil.mc.gameSettings.mouseSensitivity = 0.47887325f;
        }
        float f1 = RotationUtil.mc.gameSettings.mouseSensitivity * 0.6f + 0.2f;
        float f2 = f1 * f1 * f1 * 8.0f;
        int deltaY = (int)((6.667 * (double)pitch - 6.666667 * (double)currentPitch) / (double)f2) * -1;
        float f3 = (float)deltaY * f2;
        float f4 = (float)((double)currentPitch - (double)f3 * 0.15);
        pitch = MathHelper.clamp_float(f4, -90.0f, 90.0f);
        return pitch;
    }

    public static Vec3 getCenter(AxisAlignedBB bb) {
        return new Vec3(bb.minX + (bb.maxX - bb.minX) * 0.5, bb.minY + (bb.maxY - bb.minY) * 0.5, bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
    }

    public static Vector2f toRotation(Vec3 vec, boolean predict) {
        Vec3 eyesPos = new Vec3(RotationUtil.mc.thePlayer.posX, RotationUtil.mc.thePlayer.getEntityBoundingBox().minY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), RotationUtil.mc.thePlayer.posZ);
        if (predict) {
            eyesPos.addVector(RotationUtil.mc.thePlayer.motionX, RotationUtil.mc.thePlayer.motionY, RotationUtil.mc.thePlayer.motionZ);
        }
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        return new Vector2f(MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f), MathHelper.wrapAngleTo180_float((float)(-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ))))));
    }

    public static Rotation toRotationRot(Vec3 vec, boolean predict) {
        Vec3 eyesPos = new Vec3(RotationUtil.mc.thePlayer.posX, RotationUtil.mc.thePlayer.getEntityBoundingBox().minY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), RotationUtil.mc.thePlayer.posZ);
        if (predict) {
            eyesPos.addVector(RotationUtil.mc.thePlayer.motionX, RotationUtil.mc.thePlayer.motionY, RotationUtil.mc.thePlayer.motionZ);
        }
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        return new Rotation(MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f), MathHelper.wrapAngleTo180_float((float)(-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ))))));
    }

    public static float[] getRotationsNeeded(Entity target) {
        double yDist = target.posY - RotationUtil.mc.thePlayer.posY;
        Vec3 pos = yDist >= 1.7 ? new Vec3(target.posX, target.posY, target.posZ) : (yDist <= -1.7 ? new Vec3(target.posX, target.posY + (double)target.getEyeHeight(), target.posZ) : new Vec3(target.posX, target.posY + (double)(target.getEyeHeight() / 2.0f), target.posZ));
        Vec3 vec = new Vec3(RotationUtil.mc.thePlayer.posX, RotationUtil.mc.thePlayer.getEntityBoundingBox().minY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), RotationUtil.mc.thePlayer.posZ);
        double x = pos.xCoord - vec.xCoord;
        double y = pos.yCoord - vec.yCoord;
        double z = pos.zCoord - vec.zCoord;
        double sqrt = Math.sqrt(x * x + z * z);
        float yaw = (float)Math.toDegrees(Math.atan2(z, x)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(y, sqrt)));
        return new float[]{yaw, Math.min(Math.max(pitch, -90.0f), 90.0f)};
    }

    public static float[] getHVHRotation(Entity entity, double maxRange) {
        if (entity == null) {
            return null;
        }
        double diffX = entity.posX - RotationUtil.mc.thePlayer.posX;
        double diffZ = entity.posZ - RotationUtil.mc.thePlayer.posZ;
        Vec3 BestPos = RotationUtil.getNearestPointBB(RotationUtil.mc.thePlayer.getPositionEyes(1.0f), entity.getEntityBoundingBox());
        Location myEyePos = new Location(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);
        double diffY = BestPos.yCoord - myEyePos.getY();
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float[] getRotationsNeededBlock(double x, double y, double z) {
        double diffX = x + 0.5 - Minecraft.getMinecraft().thePlayer.posX;
        double diffZ = z + 0.5 - Minecraft.getMinecraft().thePlayer.posZ;
        double diffY = y + 0.5 - (Minecraft.getMinecraft().thePlayer.posY + (double)Minecraft.getMinecraft().thePlayer.getEyeHeight());
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / Math.PI);
        return new float[]{Minecraft.getMinecraft().thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - Minecraft.getMinecraft().thePlayer.rotationYaw), Minecraft.getMinecraft().thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Minecraft.getMinecraft().thePlayer.rotationPitch)};
    }

    public static Vector2f getRotations(double posX, double posY, double posZ) {
        EntityPlayerSP player = RotationUtil.mc.thePlayer;
        double x = posX - player.posX;
        double y = posY - (player.posY + (double)player.getEyeHeight());
        double z = posZ - player.posZ;
        double dist = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(y, dist) * 180.0 / Math.PI));
        return new Vector2f(yaw, pitch);
    }

    public static Vector2f getRotations(BlockPos block, EnumFacing face) {
        double x = (double)block.getX() + 0.5 - RotationUtil.mc.thePlayer.posX + (double)face.getFrontOffsetX() / 2.0;
        double z = (double)block.getZ() + 0.5 - RotationUtil.mc.thePlayer.posZ + (double)face.getFrontOffsetZ() / 2.0;
        double y = (double)block.getY() + 0.5;
        double d1 = RotationUtil.mc.thePlayer.posY + (double)RotationUtil.mc.thePlayer.getEyeHeight() - y;
        double d3 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 82.0f;
        float pitch = (float)(Math.atan2(d1, d3) * 180.0 / Math.PI);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new Vector2f(yaw, pitch);
    }

    public static Vector2f getRotationsNonLivingEntity(Entity entity) {
        return RotationUtil.getRotations(entity.posX, entity.posY + (entity.getEntityBoundingBox().maxY - entity.getEntityBoundingBox().minY) * 0.5, entity.posZ);
    }

    public static Vec3 getVectorForRotation(Vector2f rotation) {
        float yawCos = MathHelper.cos(-rotation.getX() * ((float)Math.PI / 180) - (float)Math.PI);
        float yawSin = MathHelper.sin(-rotation.getX() * ((float)Math.PI / 180) - (float)Math.PI);
        float pitchCos = -MathHelper.cos(-rotation.getY() * ((float)Math.PI / 180));
        float pitchSin = MathHelper.sin(-rotation.getY() * ((float)Math.PI / 180));
        return new Vec3(yawSin * pitchCos, pitchSin, yawCos * pitchCos);
    }

    public static Vec3 getVectorForRotation(Rotation rotation) {
        float yawCos = MathHelper.cos(-rotation.getYaw() * ((float)Math.PI / 180) - (float)Math.PI);
        float yawSin = MathHelper.sin(-rotation.getYaw() * ((float)Math.PI / 180) - (float)Math.PI);
        float pitchCos = -MathHelper.cos(-rotation.getPitch() * ((float)Math.PI / 180));
        float pitchSin = MathHelper.sin(-rotation.getPitch() * ((float)Math.PI / 180));
        return new Vec3(yawSin * pitchCos, pitchSin, yawCos * pitchCos);
    }

    public static float[] getRotations(Entity entity) {
        double pX = Minecraft.getMinecraft().thePlayer.posX;
        double pY = Minecraft.getMinecraft().thePlayer.posY + (double)Minecraft.getMinecraft().thePlayer.getEyeHeight();
        double pZ = Minecraft.getMinecraft().thePlayer.posZ;
        double eX = entity.posX;
        double eY = entity.posY + (double)(entity.height / 2.0f);
        double eZ = entity.posZ;
        double dX = pX - eX;
        double dY = pY - eY;
        double dZ = pZ - eZ;
        double dH = Math.sqrt(Math.pow(dX, 2.0) + Math.pow(dZ, 2.0));
        double yaw = Math.toDegrees(Math.atan2(dZ, dX)) + 90.0;
        double pitch = Math.toDegrees(Math.atan2(dH, dY));
        return new float[]{(float)yaw, (float)(90.0 - pitch)};
    }

    public static Vec3 getNearestPointBB(Vec3 eye, AxisAlignedBB box) {
        double[] origin = new double[]{eye.xCoord, eye.yCoord, eye.zCoord};
        double[] destMins = new double[]{box.minX, box.minY, box.minZ};
        double[] destMaxs = new double[]{box.maxX, box.maxY, box.maxZ};
        for (int i = 0; i < 3; ++i) {
            if (origin[i] > destMaxs[i]) {
                origin[i] = destMaxs[i];
                continue;
            }
            if (!(origin[i] < destMins[i])) continue;
            origin[i] = destMins[i];
        }
        return new Vec3(origin[0], origin[1], origin[2]);
    }

    public static Vector2f toRotationMisc(Vec3 vec, boolean predict) {
        Vec3 eyesPos = new Vec3(RotationUtil.mc.thePlayer.posX, RotationUtil.mc.thePlayer.getEntityBoundingBox().minY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), RotationUtil.mc.thePlayer.posZ);
        if (predict) {
            eyesPos.addVector(RotationUtil.mc.thePlayer.motionX, RotationUtil.mc.thePlayer.motionY, RotationUtil.mc.thePlayer.motionZ);
        }
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        return new Vector2f(MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f), MathHelper.wrapAngleTo180_float((float)(-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ))))));
    }

    public static float getTrajAngleSolutionLow(float d3, float d1, float velocity) {
        float g = 0.006f;
        float sqrt = velocity * velocity * velocity * velocity - g * (g * (d3 * d3) + 2.0f * d1 * (velocity * velocity));
        return (float)Math.toDegrees(Math.atan(((double)(velocity * velocity) - Math.sqrt(sqrt)) / (double)(g * d3)));
    }

    public static float getBowRot(Entity entity) {
        double diffY;
        double diffX = entity.posX - RotationUtil.mc.thePlayer.posX;
        double diffZ = entity.posZ - RotationUtil.mc.thePlayer.posZ;
        Location BestPos = new Location(entity.posX, entity.posY, entity.posZ);
        Location myEyePos = new Location(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + (double)RotationUtil.mc.thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);
        for (diffY = entity.boundingBox.minY + 0.7; diffY < entity.boundingBox.maxY - 0.1; diffY += 0.1) {
            Location location = new Location(entity.posX, diffY, entity.posZ);
            if (!(myEyePos.distanceTo(location) < myEyePos.distanceTo(BestPos))) continue;
            BestPos = new Location(entity.posX, diffY, entity.posZ);
        }
        diffY = BestPos.getY() - (Minecraft.getMinecraft().thePlayer.posY + (double)Minecraft.getMinecraft().thePlayer.getEyeHeight());
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        return yaw;
    }

    public static float getRotation(float currentRotation, float targetRotation, float maxIncrement) {
        float deltaAngle = MathHelper.wrapAngleTo180_float(targetRotation - currentRotation);
        if (deltaAngle > maxIncrement) {
            deltaAngle = maxIncrement;
        }
        if (deltaAngle < -maxIncrement) {
            deltaAngle = -maxIncrement;
        }
        return currentRotation + deltaAngle / 2.0f;
    }

    public static Vector2f resetRotation(Vector2f rotation) {
        if (rotation == null) {
            return null;
        }
        float yaw = RotationUtil.mc.thePlayer.rotationYaw;
        float pitch = RotationUtil.mc.thePlayer.rotationPitch;
        return new Vector2f(yaw, pitch);
    }

    public static Vector2f applySensitivityPatch(Vector2f rotation, Vector2f previousRotation) {
        float mouseSensitivity = (float)((double)RotationUtil.mc.gameSettings.mouseSensitivity * (1.0 + Math.random() / 1.0E7) * (double)0.6f + (double)0.2f);
        double multiplier = (double)(mouseSensitivity * mouseSensitivity * mouseSensitivity * 8.0f) * 0.15;
        float yaw = previousRotation.x + (float)((double)Math.round((double)(rotation.x - previousRotation.x) / multiplier) * multiplier);
        float pitch = previousRotation.y + (float)((double)Math.round((double)(rotation.y - previousRotation.y) / multiplier) * multiplier);
        return new Vector2f(yaw, MathHelper.clamp_float(pitch, -90.0f, 90.0f));
    }

    public static Vector2f smoothReal(Vector2f targetRotation) {
        float yaw = targetRotation.x;
        float pitch = targetRotation.y;
        float randomYaw = (float)(Math.random() * 2.0 - 1.0) / 10.0f;
        float randomPitch = (float)(Math.random() * 2.0 - 1.0) / 10.0f;
        Vector2f rotations = new Vector2f(yaw += randomYaw, pitch += randomPitch);
        yaw = MathHelper.wrapDegrees(rotations.x);
        pitch = MathHelper.clamp_float(rotations.y, -90.0f, 90.0f);
        return new Vector2f(yaw, pitch);
    }

    public static Vector2f smooth(Vector2f targetRotation) {
        float yaw = targetRotation.x;
        float pitch = targetRotation.y;
        return new Vector2f(yaw, pitch);
    }

    public static Vector2f smooth(Vector2f lastRotation, Vector2f targetRotation, double speed) {
        float yaw = targetRotation.x;
        float pitch = targetRotation.y;
        return new Vector2f(yaw, pitch);
    }

    public static Vector2f applySensitivityPatch(Vector2f rotation) {
        Vector2f previousRotation = RotationUtil.mc.thePlayer.getPreviousRotation();
        float mouseSensitivity = (float)((double)RotationUtil.mc.gameSettings.mouseSensitivity * (1.0 + Math.random() / 1.0E7) * (double)0.6f + (double)0.2f);
        double multiplier = (double)(mouseSensitivity * mouseSensitivity * mouseSensitivity * 8.0f) * 0.15;
        float yaw = previousRotation.x + (float)((double)Math.round((double)(rotation.x - previousRotation.x) / multiplier) * multiplier);
        float pitch = previousRotation.y + (float)((double)Math.round((double)(rotation.y - previousRotation.y) / multiplier) * multiplier);
        return new Vector2f(yaw, MathHelper.clamp_float(pitch, -90.0f, 90.0f));
    }

    public static float getYawDirection(float yaw, float strafe, float moveForward) {
        float rotationYaw = yaw;
        if (moveForward < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (moveForward < 0.0f) {
            forward = -0.5f;
        } else if (moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (strafe > 0.0f) {
            rotationYaw -= 90.0f * forward;
        }
        if (strafe < 0.0f) {
            rotationYaw += 90.0f * forward;
        }
        return rotationYaw;
    }

    public static float getClampRotation() {
        float rotationYaw = Minecraft.getMinecraft().thePlayer.rotationYaw;
        float n = 1.0f;
        if (Minecraft.getMinecraft().thePlayer.movementInput.moveForward < 0.0f) {
            rotationYaw += 180.0f;
            n = -0.5f;
        } else if (Minecraft.getMinecraft().thePlayer.movementInput.moveForward > 0.0f) {
            n = 0.5f;
        }
        if (Minecraft.getMinecraft().thePlayer.movementInput.moveStrafe > 0.0f) {
            rotationYaw -= 90.0f * n;
        }
        if (Minecraft.getMinecraft().thePlayer.movementInput.moveStrafe < 0.0f) {
            rotationYaw += 90.0f * n;
        }
        return rotationYaw * ((float)Math.PI / 180);
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }
}

