package cc.xylitol.value.impl;

import cc.xylitol.value.Value;

public class ModeValue
extends Value<String> {
    private final String[] modes;

    public ModeValue(String name, String[] modes, String value) {
        super(name);
        this.modes = modes;
        this.setValue(value);
    }

    public ModeValue(String name, String[] modes, String value, Value.Dependency dependenc) {
        super(name, dependenc);
        this.modes = modes;
        this.setValue(value);
    }

    public boolean is(String sb) {
        return this.getValue().equalsIgnoreCase(sb);
    }

    public String[] getModes() {
        return this.modes;
    }

    public String getModeAsString() {
        return this.getValue();
    }

    public void setMode(String mode2) {
        for (String e : this.modes) {
            if (e == null) {
                return;
            }
            if (!e.equalsIgnoreCase(mode2)) continue;
            this.setValue(e);
        }
    }

    @Override
    public String getConfigValue() {
        return this.value;
    }
}

