package cc.xylitol;

import cc.xylitol.command.CommandManager;
import cc.xylitol.config.ConfigManager;
import cc.xylitol.event.EventManager;
import cc.xylitol.irc.IRCClient;
import cc.xylitol.manager.BanManager;
import cc.xylitol.manager.BlinkManager;
import cc.xylitol.manager.FallDistanceManager;
import cc.xylitol.manager.PacketManager;
import cc.xylitol.manager.RotationManager;
import cc.xylitol.manager.SlotSpoofManager;
import cc.xylitol.module.ModuleManager;
import cc.xylitol.module.impl.misc.IRC;
import cc.xylitol.ui.gui.splash.SplashScreen;
import cc.xylitol.ui.hud.HUDManager;
import cc.xylitol.ui.hud.impl.SessionInfo;
import cc.xylitol.utils.render.WallpaperEngine;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import net.minecraft.client.Minecraft;
import net.netease.PacketProcessor;
import net.netease.chunk.WorldLoader;
import net.vialoadingbase.ViaLoadingBase;
import net.viamcp.ViaMCP;
import org.lwjglx.opengl.Display;
import sun.misc.Unsafe;
import top.fl0wowp4rty.phantomshield.annotations.Native;
import top.fl0wowp4rty.phantomshield.annotations.license.Virtualization;
import top.fl0wowp4rty.phantomshield.api.User;

@Native
public class Client {
    public static String name = "Xylitol";
    public static String version = "021424-1";
    public static Client instance;
    public String user = "";
    public EventManager eventManager;
    public ModuleManager moduleManager;
    public CommandManager commandManager;
    public ConfigManager configManager;
    public PacketManager packetManager;
    public SlotSpoofManager slotSpoofManager;
    public WallpaperEngine wallpaperEngine;
    public BlinkManager blinkManager;
    public HUDManager hudManager;
    public RotationManager rotationManager;
    public FallDistanceManager fallDistanceManager;
    public BanManager banManager;
    public String ingameName;
    public boolean clientLoadFinished = false;
    public static Minecraft mc;
    public static final Unsafe theUnsafe;

    @Virtualization
    public void init() {
        SplashScreen.setProgress(70, "Xylitol - Start");
        try {
            instance = this;
            派蒙哥我好喜欢你.派蒙哥我好崇拜你();
            System.out.println("Starting " + name + " " + version);
            SplashScreen.setProgress(90, "Xylitol - Managers");
            this.eventManager = new EventManager();
            this.moduleManager = new ModuleManager();
            this.commandManager = new CommandManager();
            this.configManager = new ConfigManager();
            this.hudManager = new HUDManager();
            this.rotationManager = new RotationManager();
            this.fallDistanceManager = new FallDistanceManager();
            this.packetManager = new PacketManager();
            this.slotSpoofManager = new SlotSpoofManager();
            this.blinkManager = new BlinkManager();
            this.banManager = new BanManager();
            IRC.client = new IRCClient(new InetSocketAddress("38.6.175.157", 54188));
            this.eventManager.register(this);
            this.eventManager.register(this.rotationManager);
            this.eventManager.register(this.fallDistanceManager);
            this.eventManager.register(this.banManager);
            this.eventManager.register(this.packetManager);
            //this.eventManager.register((Object)PacketProcessor.INSTANCE);
            this.eventManager.register(new WorldLoader());
            this.moduleManager.init();
            this.commandManager.init();
            this.configManager.loadAllConfig();
            try {
                ViaMCP.create();
                ViaMCP.INSTANCE.initAsyncSlider();
                ViaLoadingBase.getInstance().reload(ProtocolVersion.v1_12_2);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            this.wallpaperEngine = new WallpaperEngine();
            String gameDirPath = Client.mc.mcDataDir.getAbsolutePath();
            String videoFilePath = gameDirPath + File.separator + "background.mp4";
            try {
                InputStream inputStream = Client.class.getResourceAsStream("/assets/minecraft/xylitol/background.mp4");
                Files.copy(inputStream, Paths.get(videoFilePath), StandardCopyOption.REPLACE_EXISTING);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            this.wallpaperEngine.setup(new File(videoFilePath), 30);
            this.clientLoadFinished = true;
            this.user = User.INSTANCE.getUsername("Insane1337");
            Display.setTitle(name + " " + version + " - " + this.user);
            SessionInfo.startTime = (int)System.currentTimeMillis();
        }
        catch (Exception e) {
            e.printStackTrace();
            Display.destroy();
            System.exit(1);
            theUnsafe.freeMemory(114514L);
        }
    }

    public void shutdown() {
        System.out.println("Client shutdown");
        if (IRC.client.isConnected()) {
            IRC.client.disconnect();
        }
    }

    public static String getIGN() {
        return Client.mc.thePlayer == null ? mc.getSession().getUsername() : Client.mc.thePlayer.getName();
    }

    public String getUser() {
        return this.user;
    }

    public EventManager getEventManager() {
        return this.eventManager;
    }

    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }

    public CommandManager getCommandManager() {
        return this.commandManager;
    }

    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    public PacketManager getPacketManager() {
        return this.packetManager;
    }

    public SlotSpoofManager getSlotSpoofManager() {
        return this.slotSpoofManager;
    }

    public WallpaperEngine getWallpaperEngine() {
        return this.wallpaperEngine;
    }

    public BlinkManager getBlinkManager() {
        return this.blinkManager;
    }

    public HUDManager getHudManager() {
        return this.hudManager;
    }

    public RotationManager getRotationManager() {
        return this.rotationManager;
    }

    public FallDistanceManager getFallDistanceManager() {
        return this.fallDistanceManager;
    }

    public BanManager getBanManager() {
        return this.banManager;
    }

    public String getIngameName() {
        return this.ingameName;
    }

    public boolean isClientLoadFinished() {
        return this.clientLoadFinished;
    }

    static {
        mc = Minecraft.getMinecraft();
        try {
            Field f = Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            theUnsafe = (Unsafe)f.get(null);
        }
        catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException | SecurityException e) {
            throw new RuntimeException(e);
        }
    }
}

